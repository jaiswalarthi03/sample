/**
 * ADW Workbench - Visual Effects
 * Provides animations, parallax effects, and other visual enhancements
 */

/**
 * Setup parallax effects on cards
 */
function setupParallaxEffects() {
    const cards = document.querySelectorAll('.card');
    
    cards.forEach(card => {
        card.addEventListener('mousemove', function(e) {
            // Get card position
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            // Calculate tilt values based on mouse position
            const tiltX = ((y / rect.height) * 2 - 1) * -5;
            const tiltY = ((x / rect.width) * 2 - 1) * 5;
            
            // Apply tilt effect
            card.style.transform = `perspective(1000px) rotateX(${tiltX}deg) rotateY(${tiltY}deg) scale3d(1.02, 1.02, 1.02)`;
            
            // Add highlight effect
            const glareX = (x / rect.width) * 100;
            const glareY = (y / rect.height) * 100;
            card.style.background = `radial-gradient(circle at ${glareX}% ${glareY}%, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0) 50%), rgba(255, 255, 255, 0.8)`;
        });
        
        card.addEventListener('mouseleave', function() {
            // Reset effects
            card.style.transform = '';
            card.style.background = '';
        });
    });
}

/**
 * Animate metric counters
 */
function animateMetricCounters() {
    const metricValues = document.querySelectorAll('.metric-value');
    
    metricValues.forEach(metric => {
        const finalValue = metric.textContent;
        
        // Check if value is a number
        if (!isNaN(parseFloat(finalValue)) && isFinite(finalValue)) {
            // Start from zero
            metric.textContent = '0';
            
            const targetValue = parseFloat(finalValue);
            const duration = 1000; // 1 second
            const startTime = performance.now();
            
            function update(currentTime) {
                const elapsedTime = currentTime - startTime;
                const progress = Math.min(elapsedTime / duration, 1);
                
                // Use easeOutQuad for smoother animation
                const easedProgress = 1 - (1 - progress) * (1 - progress);
                const currentValue = (targetValue * easedProgress).toFixed(2);
                
                metric.textContent = currentValue;
                
                if (progress < 1) {
                    requestAnimationFrame(update);
                } else {
                    metric.textContent = finalValue;
                }
            }
            
            requestAnimationFrame(update);
        }
    });
}

/**
 * Initialize particles background
 */
function initParticleBackground() {
    if (typeof particlesJS === 'undefined') return;
    
    // Only apply to results panel
    const resultsPanel = document.getElementById('results-panel');
    if (!resultsPanel) return;
    
    // Create container for particles
    let particlesContainer = document.getElementById('particles-container');
    if (!particlesContainer) {
        particlesContainer = document.createElement('div');
        particlesContainer.id = 'particles-container';
        particlesContainer.style.position = 'absolute';
        particlesContainer.style.top = '0';
        particlesContainer.style.left = '0';
        particlesContainer.style.width = '100%';
        particlesContainer.style.height = '100%';
        particlesContainer.style.zIndex = '-1';
        
        resultsPanel.style.position = 'relative';
        resultsPanel.insertBefore(particlesContainer, resultsPanel.firstChild);
    }
    
    // Initialize particles.js with a subtle configuration
    particlesJS('particles-container', {
        particles: {
            number: {
                value: 20,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: '#ea0000'
            },
            shape: {
                type: 'circle',
                stroke: {
                    width: 0,
                    color: '#000000'
                }
            },
            opacity: {
                value: 0.1,
                random: true,
                anim: {
                    enable: true,
                    speed: 0.5,
                    opacity_min: 0.05,
                    sync: false
                }
            },
            size: {
                value: 5,
                random: true,
                anim: {
                    enable: true,
                    speed: 2,
                    size_min: 1,
                    sync: false
                }
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: '#ea0000',
                opacity: 0.1,
                width: 1
            },
            move: {
                enable: true,
                speed: 1,
                direction: 'none',
                random: true,
                straight: false,
                out_mode: 'out',
                bounce: false
            }
        },
        interactivity: {
            detect_on: 'canvas',
            events: {
                onhover: {
                    enable: true,
                    mode: 'grab'
                },
                onclick: {
                    enable: true,
                    mode: 'push'
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 140,
                    line_linked: {
                        opacity: 0.3
                    }
                },
                push: {
                    particles_nb: 3
                }
            }
        },
        retina_detect: true
    });
}

/**
 * Fade in elements one by one
 */
function fadeInElements() {
    // Select elements to animate
    const elements = document.querySelectorAll('.card, .analysis-result, h1, h2, h3, table');
    
    // Set initial state
    elements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        // Stagger the animations
        setTimeout(() => {
            el.style.opacity = '1';
            el.style.transform = 'translateY(0)';
        }, 100 * index);
    });
}

/**
 * Highlight code blocks using syntax highlighting
 */
function highlightCode() {
    const codeBlocks = document.querySelectorAll('pre code');
    
    if (window.hljs) {
        codeBlocks.forEach(block => {
            hljs.highlightBlock(block);
        });
    }
}

// Initialize effects when page loads
document.addEventListener('DOMContentLoaded', function() {
    fadeInElements();
    
    // Initialize after a slight delay to ensure everything is rendered
    setTimeout(() => {
        if (typeof setupParallaxEffects === 'function') setupParallaxEffects();
        if (typeof animateMetricCounters === 'function') animateMetricCounters();
        if (typeof initParticleBackground === 'function') initParticleBackground();
        if (typeof highlightCode === 'function') highlightCode();
        
        // Initialize Mermaid diagrams if available
        if (typeof mermaid !== 'undefined') {
            mermaid.initialize({ startOnLoad: true });
        }
    }, 500);
});