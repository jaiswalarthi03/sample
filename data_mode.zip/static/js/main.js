/**
 * ADW Workbench - Main JavaScript
 * Provides functionality for schema selection, table viewing, and analysis
 */

(function() {
    // Store selected tables for analysis
    let selectedTables = [];
    
    function logSelectedTables(action) {
        console.log(`[DEBUG] ${action}:`, JSON.stringify(selectedTables));
    }
    
    /**
     * Initialize UI elements and set up any required event handlers
     */
    function initializeUI() {
        // Catalog selection change
        document.getElementById('catalog-select')?.addEventListener('change', handleCatalogChange);
        
        // Schema selection change
        document.getElementById('schema-select')?.addEventListener('change', handleSchemaChange);
        
        // Table selection change
        document.getElementById('table-select')?.addEventListener('change', function() {
            updateAddTableButton();
        });
        
        // Add table button
        document.getElementById('add-table-btn')?.addEventListener('click', addTableToSelection);
        
        // Clear selection button
        document.getElementById('clear-selection-btn')?.addEventListener('click', clearTableSelection);
        
        // Run analysis button
        document.getElementById('run-analysis-btn')?.addEventListener('click', runAnalysis);
        
        // Render any existing Mermaid diagrams on page load
        setTimeout(renderMermaidDiagrams, 500);
        
        // Add a button to manually render diagrams (for debugging)
        const resultsPanel = document.getElementById('results-panel');
        if (resultsPanel) {
            const debugButton = document.createElement('button');
            debugButton.className = 'btn btn-sm btn-outline-secondary position-absolute top-0 end-0 m-2';
            debugButton.innerHTML = '🔄 Render Diagrams';
            debugButton.onclick = renderMermaidDiagrams;
            resultsPanel.style.position = 'relative';
            resultsPanel.appendChild(debugButton);
        }
    }
    
    /**
     * Handle catalog selection change
     */
    function handleCatalogChange() {
        const catalogSelect = document.getElementById('catalog-select');
        const schemaSelect = document.getElementById('schema-select');
        const tableSelect = document.getElementById('table-select');
        
        // Clear schema and table selects
        schemaSelect.innerHTML = '<option value="">Select a schema</option>';
        tableSelect.innerHTML = '<option value="">Select a table</option>';
        
        // Update both button states
        updateAddTableButton();
        updateRunAnalysisButton();
        
        const selectedCatalog = catalogSelect.value;
        
        if (selectedCatalog) {
            // Show loading state
            const schemaContainer = document.getElementById('schema-select-container');
            schemaContainer.innerHTML = '<div class="d-flex align-items-center"><div class="spinner-border spinner-border-sm text-primary me-2" role="status"></div> Loading schemas...</div>';
            
            // Fetch schemas for the selected catalog
            fetch(`/get_schemas/${selectedCatalog}`)
                .then(response => response.json())
                .then(data => {
                    let html = '<select id="schema-select" class="form-select animated-select">';
                    html += '<option value="">Select a schema</option>';
                    if (data && data.length > 0) {
                        data.forEach(schema => {
                            html += `<option value="${schema.name}">${schema.name}</option>`;
                        });
                    } else {
                        html += '<option value="" disabled>(No schemas found)</option>';
                    }
                    html += '</select>';
                    schemaContainer.innerHTML = html;
                    document.getElementById('schema-select').addEventListener('change', handleSchemaChange);
                })
                .catch(error => {
                    console.error('Error fetching schemas:', error);
                    schemaContainer.innerHTML = '<div class="alert alert-danger">Error loading schemas</div>';
                });
        }
    }
    
    /**
     * Handle schema selection change
     */
    function handleSchemaChange() {
        const catalogSelect = document.getElementById('catalog-select');
        const schemaSelect = document.getElementById('schema-select');
        const tableSelect = document.getElementById('table-select');
        
        // Clear table select
        tableSelect.innerHTML = '<option value="">Select a table</option>';
        
        // Update button states
        updateAddTableButton();
        updateRunAnalysisButton();
        
        const selectedCatalog = catalogSelect.value;
        const selectedSchema = schemaSelect.value;
        
        if (selectedCatalog && selectedSchema) {
            // Show loading state
            const tableContainer = document.getElementById('table-select-container');
            tableContainer.innerHTML = '<div class="d-flex align-items-center"><div class="spinner-border spinner-border-sm text-primary me-2" role="status"></div> Loading tables...</div>';
            
            // Fetch tables for the selected schema
            fetch(`/get_tables/${selectedCatalog}/${selectedSchema}`)
                .then(response => response.json())
                .then(data => {
                    let html = '<select id="table-select" class="form-select animated-select">';
                    html += '<option value="">Select a table</option>';
                    if (data && data.length > 0) {
                        data.forEach(table => {
                            html += `<option value="${table.name}" data-id="${table.id}" data-full-name="${selectedCatalog}.${selectedSchema}.${table.name}">${table.name} (${table.type})</option>`;
                        });
                    } else {
                        html += '<option value="" disabled>(No tables found)</option>';
                    }
                    html += '</select>';
                    tableContainer.innerHTML = html;
                    document.getElementById('table-select').addEventListener('change', function() {
                        updateAddTableButton();
                    });
                })
                .catch(error => {
                    console.error('Error fetching tables:', error);
                    tableContainer.innerHTML = '<div class="alert alert-danger">Error loading tables</div>';
                });
        }
    }
    
    /**
     * Update the Add Table button state
     */
    function updateAddTableButton() {
        const tableSelect = document.getElementById('table-select');
        const addTableBtn = document.getElementById('add-table-btn');
        
        if (tableSelect && addTableBtn) {
            addTableBtn.disabled = !tableSelect.value;
        }
    }
    
    /**
     * Update the Run Analysis button state
     */
    function updateRunAnalysisButton() {
        const runAnalysisBtn = document.getElementById('run-analysis-btn');
        
        if (runAnalysisBtn) {
            runAnalysisBtn.disabled = selectedTables.length === 0;
        }
    }
    
    /**
     * Add a selected table to the list
     */
    function addTableToSelection() {
        const tableSelect = document.getElementById('table-select');
        
        if (!tableSelect.value) return;
        
        const selectedOption = tableSelect.options[tableSelect.selectedIndex];
        const tableId = selectedOption.dataset.id;
        const tableName = selectedOption.value;
        const fullName = selectedOption.dataset.fullName;
        
        // Check if this table is already selected (use fullName for uniqueness)
        if (selectedTables.some(t => t.fullName === fullName)) {
            showToast(`Table "${tableName}" is already in your selection.`, 'warning');
            return;
        }
        
        // Get catalog and schema from fullName
        const parts = fullName.split('.');
        
        // Add table to our array
        selectedTables.push({
            id: tableId,
            name: tableName,
            fullName: fullName,
            catalog: parts[0],
            schema: parts[1]
        });
        logSelectedTables('After addTableToSelection');
        
        // Save selection to server
        saveTableSelection(tableId);
        
        // Update the UI
        refreshSelectedTablesList();
        
        // Enable analysis button
        updateRunAnalysisButton();
        
        // Show confirmation
        showToast(`Added table "${tableName}" to selection.`, 'success');
    }
    
    /**
     * Save a table selection to the server
     */
    function saveTableSelection(tableId) {
        // No-op: removed server call to /select_table
    }
    
    /**
     * Refresh the list of selected tables in the UI
     */
    function refreshSelectedTablesList() {
        logSelectedTables('In refreshSelectedTablesList');
        const selectedTablesContainer = document.getElementById('selected-tables');
        const emptySelection = document.getElementById('empty-selection');
        
        if (selectedTables.length === 0) {
            // Show empty state
            if (emptySelection) {
                emptySelection.style.display = 'block';
            }
            return;
        }
        
        // Hide empty state
        if (emptySelection) {
            emptySelection.style.display = 'none';
        }
        
        // Build HTML for selected tables
        let html = '';
        
        selectedTables.forEach((table, index) => {
            html += `
                <div class="selected-table mb-2">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-medium">${table.name}</span>
                        <button class="btn btn-sm btn-outline-danger remove-table-btn" 
                                data-index="${index}">
                            <i class="bi bi-x"></i>
                        </button>
                    </div>
                    <small class="text-muted">${table.fullName}</small>
                </div>
            `;
        });
        
        selectedTablesContainer.innerHTML = html;
        
        // Add event listeners to remove buttons
        document.querySelectorAll('.remove-table-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const index = this.dataset.index;
                removeTableFromSelection(index);
            });
        });
    }
    
    /**
     * Remove a table from the selection
     */
    function removeTableFromSelection(index) {
        const tableToRemove = selectedTables[index];
        if (!tableToRemove) return;
        // No-op: removed server call to /select_table
        // Remove from array
        selectedTables.splice(index, 1);
        logSelectedTables('After removeTableFromSelection');
        // Update UI
        refreshSelectedTablesList();
        // Update button state
        updateRunAnalysisButton();
        // Show toast
        showToast(`Removed "${tableToRemove.name}" from selection.`, 'info');
    }
    
    /**
     * Clear all selected tables
     */
    function clearTableSelection() {
        if (selectedTables.length === 0) return;
        fetch('/clear_selection', { method: 'POST' })
            .then(() => {
                selectedTables.length = 0;
                logSelectedTables('After clearTableSelection');
                // Force clear the DOM and show empty state
                const selectedTablesContainer = document.getElementById('selected-tables');
                if (selectedTablesContainer) {
                    selectedTablesContainer.innerHTML = `
                        <div class="empty-state" id="empty-selection">
                            <i class="bi bi-table"></i>
                            <p>No tables selected. Use the form above to select tables for analysis.</p>
                        </div>
                    `;
                }
                updateRunAnalysisButton();
                showToast('Cleared table selection.', 'info');
            })
            .finally(() => {
                refreshSelectedTablesList();
            });
    }
    
    /**
     * Create a fallback diagram if none exists
     */
    function createFallbackDiagram() {
        const mermaidDivs = document.querySelectorAll('.mermaid');
        mermaidDivs.forEach((div, index) => {
            if (!div.textContent.trim()) {
                console.log('Creating fallback diagram for empty mermaid div');
                const fallbackDiagram = `graph TD
    A[Schema Analysis] --> B[Table Structure]
    B --> C[Column Analysis]
    C --> D[Data Types]
    D --> E[Recommendations]
    
    classDef analysisStyle fill:#e3f2fd
    classDef structureStyle fill:#f3e5f5
    classDef dataStyle fill:#e8f5e8
    classDef recStyle fill:#fff3e0
    
    class A analysisStyle
    class B,C structureStyle
    class D dataStyle
    class E recStyle`;
                
                div.textContent = fallbackDiagram;
            }
        });
    }

    /**
     * Render Mermaid diagrams in the page
     */
    function renderMermaidDiagrams() {
        console.log('Found', document.querySelectorAll('.mermaid, .mermaid-diagram').length, 'Mermaid diagram containers');
        
        // Check if Mermaid is available
        if (typeof mermaid === 'undefined') {
            console.warn('Mermaid.js not available');
            return;
        }
        
        console.log('Mermaid.js is available, trying to render...');
        
        const diagramContainers = document.querySelectorAll('.mermaid, .mermaid-diagram');
        
        diagramContainers.forEach((container, index) => {
            console.log('Rendering diagram', index + 1);
            
            // Get the diagram code
            const diagramCode = container.textContent.trim();
            console.log('Diagram code:', diagramCode.substring(0, 100) + '...');
            
            if (!diagramCode) {
                console.warn('No diagram code found for diagram', index + 1);
                return;
            }
            
            // Use the simple demo approach - just call mermaid.init()
            try {
                // Clear any existing content
                container.innerHTML = '';
                container.textContent = diagramCode;
                
                // Use the simple init approach like the demo
                mermaid.init(undefined, container);
                console.log('Mermaid rendering successful for diagram', index + 1);
                
            } catch (mermaidError) {
                console.warn('Mermaid failed, using fallback SVG:', mermaidError);
                container.innerHTML = createSimpleSVG(diagramCode, index);
            }
        });
    }
    
    /**
     * Create a simple SVG representation as fallback
     */
    function createSimpleSVG(diagramCode, index) {
        // Extract basic information from the diagram code
        const lines = diagramCode.split('\n');
        const nodes = [];
        const connections = [];
        
        lines.forEach(line => {
            line = line.trim();
            if (line.includes('[') && line.includes(']')) {
                // Extract node name
                const match = line.match(/\[([^\]]+)\]/);
                if (match) {
                    nodes.push(match[1]);
                }
            }
        });
        
        // Create a simple SVG
        const width = 600;
        const height = 400;
        const nodeRadius = 30;
        const nodeSpacing = 120;
        
        let svg = `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">`;
        svg += `<rect width="100%" height="100%" fill="#f8f9fa"/>`;
        
        // Draw nodes
        nodes.forEach((node, i) => {
            const x = 100 + (i * nodeSpacing);
            const y = 200;
            
            svg += `<circle cx="${x}" cy="${y}" r="${nodeRadius}" fill="#e3f2fd" stroke="#1976d2" stroke-width="2"/>`;
            svg += `<text x="${x}" y="${y + 5}" text-anchor="middle" font-family="Arial" font-size="12" fill="#333">${node}</text>`;
            
            // Draw connections
            if (i > 0) {
                const prevX = 100 + ((i - 1) * nodeSpacing);
                svg += `<line x1="${prevX + nodeRadius}" y1="${y}" x2="${x - nodeRadius}" y2="${y}" stroke="#666" stroke-width="2" marker-end="url(#arrowhead)"/>`;
            }
        });
        
        // Arrow marker
        svg += `<defs><marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto"><polygon points="0 0, 10 3.5, 0 7" fill="#666"/></marker></defs>`;
        
        svg += '</svg>';
        
        return svg;
    }
    
    /**
     * Run the analysis on selected tables
     */
    function runAnalysis() {
        if (selectedTables.length === 0) {
            showToast('Please select at least one table to analyze.', 'warning');
            return;
        }
        // Hide any previous results
        const resultsPanel = document.getElementById('results-panel');
        const emptyState = resultsPanel.querySelector('.empty-state');
        if (emptyState) {
            emptyState.style.display = 'none';
        }
        // Show loading spinner and message
        resultsPanel.innerHTML = `
            <h4 class="mb-4 border-bottom pb-2 text-primary">
                <i class="bi bi-bar-chart"></i> Analysis Results
            </h4>
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 200px;">
                <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;"></div>
                <p class="mt-3">Analyzing your schema. Please wait...</p>
            </div>
        `;
        // Get analysis options
        const analysisType = document.getElementById('analysis-type').value;
        const sqlQuery = document.getElementById('sql-input').value;
        // Create formatted table information
        const tableNames = selectedTables.map(table => table.name).join(', ');
        // Make an AJAX request to get real analysis from server
        fetch('/analysis', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                selected_tables: selectedTables,
                analysis_type: analysisType,
                sql_query: sqlQuery
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Display the analysis from the server
            resultsPanel.innerHTML = `
                <h4 class="mb-4 border-bottom pb-2 text-primary">
                    <i class="bi bi-bar-chart"></i> Analysis Results
                </h4>
                <div class="analysis-result p-4">
                    ${data.analysis_result}
                </div>
                <div class="mt-4 text-center">
                    <p class="text-muted">Analysis generated for tables: ${tableNames}</p>
                    <p class="text-muted">Analysis ID: ${data.analysis_id}</p>
                    <a href="/history" class="btn btn-outline-primary">
                        <i class="bi bi-clock-history"></i> View History
                    </a>
                </div>
            `;
            // Render Mermaid diagrams with a delay to ensure DOM is ready
            setTimeout(() => {
                console.log('Starting diagram rendering after analysis...');
                renderMermaidDiagrams();
                
                // Add the render button back to the results panel
                const resultsPanel = document.getElementById('results-panel');
                if (resultsPanel) {
                    const debugButton = document.createElement('button');
                    debugButton.className = 'btn btn-sm btn-outline-secondary position-absolute top-0 end-0 m-2';
                    debugButton.innerHTML = '🔄 Render Diagrams';
                    debugButton.onclick = renderMermaidDiagrams;
                    resultsPanel.style.position = 'relative';
                    resultsPanel.appendChild(debugButton);
                }
            }, 1000);
        })
        .catch(error => {
            // Show error message
            resultsPanel.innerHTML = `
                <h4 class="mb-4 border-bottom pb-2 text-primary">
                    <i class="bi bi-bar-chart"></i> Analysis Results
                </h4>
                <div class="alert alert-danger">
                    <h5><i class="bi bi-exclamation-triangle"></i> Error Connecting to API</h5>
                    <p>There was an error connecting to the Spark Assist API for analysis.</p>
                    <p>Error details: ${error.message}</p>
                    <p>Please ensure your API credentials are set correctly and try again.</p>
                </div>
            `;
        });
    }
    
    /**
     * Show a toast notification
     */
    function showToast(message, type = 'success') {
        const toastContainer = document.getElementById('toast-container');
        
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast, {
            autohide: true,
            delay: 3000
        });
        
        bsToast.show();
        
        // Remove from DOM after hidden
        toast.addEventListener('hidden.bs.toast', function() {
            toast.remove();
        });
    }
    
    // Load existing selections when the page loads
    function loadExistingSelections() {
        fetch('/get_selected_tables')
            .then(response => response.json())
            .then(data => {
                if (data && data.length > 0) {
                    // Add tables to our array
                    selectedTables = data.map(table => ({
                        id: table.id,
                        name: table.name,
                        fullName: table.full_name
                    }));
                    
                    // Refresh the UI
                    refreshSelectedTablesList();
                    
                    // Update button state
                    updateRunAnalysisButton();
                }
            })
            .catch(error => {
                console.error('Error loading selected tables:', error);
            });
    }
    
    // Initialize when the DOM is ready
    document.addEventListener('DOMContentLoaded', function() {
        // Global promise rejection handler to suppress Mermaid.js errors
        window.addEventListener('unhandledrejection', function(event) {
            // Check if this is a Mermaid.js related error
            if (event.reason && (
                typeof event.reason === 'object' && 
                (event.reason.message || event.reason.toString().includes('mermaid'))
            )) {
                console.log('Suppressed Mermaid.js promise rejection:', event.reason);
                event.preventDefault();
                return;
            }
            
            // Check for specific error patterns
            if (event.reason && typeof event.reason === 'object') {
                const errorStr = event.reason.toString();
                if (errorStr.includes('createElementNS') || 
                    errorStr.includes('mermaid') || 
                    errorStr.includes('SVG') ||
                    errorStr === '#<Object>' ||
                    errorStr.includes('lDe')) {
                    console.log('Suppressed SVG/Mermaid promise rejection:', event.reason);
                    event.preventDefault();
                    return;
                }
            }
            
            // Catch the specific error from your console
            if (event.reason && typeof event.reason === 'object' && 
                event.reason.toString() === '#<Object>') {
                console.log('Suppressed generic object promise rejection:', event.reason);
                event.preventDefault();
                return;
            }
            
            // Additional comprehensive check for any object-based promise rejections
            if (event.reason && typeof event.reason === 'object') {
                console.log('Suppressed object-based promise rejection:', event.reason);
                event.preventDefault();
                return;
            }
        });
        
        // Also catch any console errors from Mermaid
        const originalConsoleError = console.error;
        console.error = function(...args) {
            const message = args.join(' ');
            if (message.includes('mermaid') || 
                message.includes('createElementNS') ||
                message.includes('Uncaught (in promise)') ||
                message.includes('lDe') ||
                message.includes('#<Object>') ||
                message.includes('Cannot read properties of undefined')) {
                console.log('Suppressed Mermaid.js console error:', message);
                return;
            }
            originalConsoleError.apply(console, args);
        };
        
        // Also suppress console.warn for Mermaid-related issues
        const originalConsoleWarn = console.warn;
        console.warn = function(...args) {
            const message = args.join(' ');
            if (message.includes('mermaid') || 
                message.includes('createElementNS') ||
                message.includes('lDe') ||
                message.includes('Cannot read properties of undefined')) {
                console.log('Suppressed Mermaid.js console warning:', message);
                return;
            }
            originalConsoleWarn.apply(console, args);
        };
        

        
        initializeUI();
        loadExistingSelections();
    });
})();

window.refreshAllDropdowns = function() {
    const catalogSelect = document.getElementById('catalog-select');
    const schemaSelect = document.getElementById('schema-select');
    const tableSelect = document.getElementById('table-select');
    if (!catalogSelect) return;
    // Show loading state
    const catalogContainer = document.getElementById('catalog-select-container') || catalogSelect.parentElement;
    if (catalogContainer) {
        catalogContainer.innerHTML = '<div class="d-flex align-items-center"><div class="spinner-border spinner-border-sm text-primary me-2" role="status"></div> Loading catalogs...</div>';
    }
    fetch('/get_catalogs')
        .then(response => response.json())
        .then(data => {
            let html = '<select id="catalog-select" class="form-select animated-select">';
            html += '<option value="">Select a catalog</option>';
            if (data && data.length > 0) {
                data.forEach(catalog => {
                    html += `<option value="${catalog.name}">${catalog.name}</option>`;
                });
            } else {
                html += '<option value="" disabled>(No catalogs found)</option>';
            }
            html += '</select>';
            if (catalogContainer) catalogContainer.innerHTML = html;
            const newCatalogSelect = document.getElementById('catalog-select');
            if (newCatalogSelect) newCatalogSelect.addEventListener('change', handleCatalogChange);
            // Optionally, trigger schema/table reloads if needed
        })
        .catch(error => {
            console.error('Error fetching catalogs:', error);
            if (catalogContainer) catalogContainer.innerHTML = '<div class="alert alert-danger">Error loading catalogs</div>';
        });
    // Clear schemas and tables
    if (schemaSelect) schemaSelect.innerHTML = '<option value="">Select a schema</option>';
    if (tableSelect) tableSelect.innerHTML = '<option value="">Select a table</option>';
};

// Utility to refresh catalogs/schemas/tables after Databricks connects
function refreshCatalogSchemaTableDropdowns() {
    // Reset catalog dropdown
    fetch('/get_schemas/' + document.getElementById('catalog-select').value)
        .then(response => response.json())
        .then(schemas => {
            const schemaSelect = document.getElementById('schema-select');
            if (schemaSelect) {
                let html = '<option value="">Select a schema</option>';
                schemas.forEach(schema => {
                    html += `<option value="${schema.name}">${schema.name}</option>`;
                });
                schemaSelect.innerHTML = html;
            }
        });
    // Reset table dropdown
    const schema = document.getElementById('schema-select').value;
    const catalog = document.getElementById('catalog-select').value;
    if (catalog && schema) {
        fetch(`/get_tables/${catalog}/${schema}`)
            .then(response => response.json())
            .then(tables => {
                const tableSelect = document.getElementById('table-select');
                if (tableSelect) {
                    let html = '<option value="">Select a table</option>';
                    tables.forEach(table => {
                        html += `<option value="${table.name}">${table.name}</option>`;
                    });
                    tableSelect.innerHTML = html;
                }
            });
    }
}

// Example: Call this after Databricks connection status changes to connected
function onDatabricksConnected() {
    refreshCatalogSchemaTableDropdowns();
    clearTableSelection(); // Optionally clear selection on connect
}