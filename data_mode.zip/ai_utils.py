def clean_spark_assist_output(text):
    """
    Clean up Spark Assist output by removing markdown code block formatting.
    Args:
        text (str): Raw Spark Assist response text
    Returns:
        str: Cleaned HTML content
    """
    # Remove ```html prefix
    if text.startswith('```html'):
        text = text[7:]
    # Remove ``` suffix
    if text.endswith('```'):
        text = text[:-3]
    # Remove any leading/trailing whitespace
    text = text.strip()
    # Handle cases where Spark Assist might add extra formatting
    text = text.replace('```html\n', '')
    text = text.replace('\n```', '')
    return text

def get_sample_analysis():
    """Return a sample analysis for demonstration purposes"""
    return """
    <h1>📊 Sample Governance & Compliance Analysis</h1>
    <h2>🔍 Data Quality Assessment</h2>
    <ul>
        <li><span style=\"color: green;\">✅</span> Data completeness: 95% - Good coverage across tables</li>
        <li><span style=\"color: orange;\">⚠️</span> Data accuracy: 87% - Some inconsistencies detected</li>
        <li><span style=\"color: green;\">✅</span> Data consistency: 92% - Consistent naming conventions</li>
        <li><span style=\"color: red;\">❌</span> Data timeliness: 78% - Some tables need refresh</li>
    </ul>
    <h2>🔒 Security & Privacy Analysis</h2>
    <ul>
        <li><span style=\"color: red;\">❌</span> Missing column-level encryption for sensitive data</li>
        <li><span style=\"color: orange;\">⚠️</span> Row-level security not implemented</li>
        <li><span style=\"color: green;\">✅</span> Access controls properly configured</li>
        <li><span style=\"color: red;\">❌</span> Audit logging needs enhancement</li>
    </ul>
    <h2>⚡ Performance & Scalability Review</h2>
    <ul>
        <li><span style=\"color: green;\">✅</span> Partitioning strategy implemented</li>
        <li><span style=\"color: orange;\">⚠️</span> Clustering could be optimized</li>
        <li><span style=\"color: red;\">❌</span> Missing indexes on frequently queried columns</li>
        <li><span style=\"color: green;\">✅</span> Resource utilization within acceptable limits</li>
    </ul>
    <h2>📋 Compliance Evaluation</h2>
    <ul>
        <li><span style=\"color: orange;\">⚠️</span> GDPR compliance: PII identification needed</li>
        <li><span style=\"color: red;\">❌</span> SOX compliance: Audit trails insufficient</li>
        <li><span style=\"color: green;\">✅</span> HIPAA compliance: Basic requirements met</li>
        <li><span style=\"color: orange;\">⚠️</span> PCI DSS: Payment data handling needs review</li>
    </ul>
    <h2>🏛️ Data Governance Assessment</h2>
    <ul>
        <li><span style=\"color: green;\">✅</span> Data ownership clearly defined</li>
        <li><span style=\"color: orange;\">⚠️</span> Data stewardship roles need clarification</li>
        <li><span style=\"color: red;\">❌</span> Data lifecycle management incomplete</li>
        <li><span style=\"color: green;\">✅</span> Data catalog implementation in progress</li>
    </ul>
    <h2>💡 Recommendations</h2>
    <ol>
        <li><strong>Immediate Actions:</strong> Implement column-level encryption for sensitive data</li>
        <li><strong>Short-term:</strong> Enhance audit logging and PII identification</li>
        <li><strong>Medium-term:</strong> Optimize clustering and add missing indexes</li>
        <li><strong>Long-term:</strong> Complete data lifecycle management implementation</li>
    </ol>
    <h2>⚠️ Risk Assessment</h2>
    <table border=\"1\">
        <tr>
            <th>Risk</th>
            <th>Severity</th>
            <th>Probability</th>
            <th>Mitigation</th>
        </tr>
        <tr>
            <td>Data Breach</td>
            <td><span style=\"color: red;\">High</span></td>
            <td><span style=\"color: orange;\">Medium</span></td>
            <td>Implement encryption and access controls</td>
        </tr>
        <tr>
            <td>Compliance Violation</td>
            <td><span style=\"color: red;\">High</span></td>
            <td><span style=\"color: red;\">High</span></td>
            <td>Enhance audit trails and PII handling</td>
        </tr>
        <tr>
            <td>Performance Degradation</td>
            <td><span style=\"color: orange;\">Medium</span></td>
            <td><span style=\"color: orange;\">Medium</span></td>
            <td>Optimize indexes and clustering</td>
        </tr>
    </table>
    """ 