import requests
from config import AI_API_KEY, AI_API_URL
from ai_utils import clean_spark_assist_output, get_sample_analysis

def get_spark_assist_analysis(prompt):
    """
    Send a prompt to the Spark Assist API and return the cleaned HTML result.
    This function is the single point of AI analysis API usage. To swap providers, edit this function only.
    """
    try:
        params = {
            'key': AI_API_KEY,
        }
        request_body = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt}
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "topK": 32,
                "topP": 0.95,
                "maxOutputTokens": 8192,
            }
        }
        if not AI_API_KEY:
            return get_sample_analysis()
        response = requests.post(
            AI_API_URL,
            params=params,
            json=request_body,
            headers={"Content-Type": "application/json"},
            verify=False
        )
        if response.status_code == 200:
            response_json = response.json()
            if 'candidates' in response_json and len(response_json['candidates']) > 0:
                parts = response_json['candidates'][0].get('content', {}).get('parts', [])
                if parts and 'text' in parts[0]:
                    analysis_text = parts[0]['text']
                else:
                    analysis_text = str(parts)
                if not analysis_text.strip():
                    return get_sample_analysis()
                analysis_text = clean_spark_assist_output(analysis_text)
                return analysis_text
            else:
                return f"""
                <h1>⚠️ API Error</h1>
                <p>There was an error with the Spark Assist API response format.</p>
                <p>Using sample analysis instead.</p>
                {get_sample_analysis()}
                """
        else:
            return f"""
            <h1>⚠️ API Error</h1>
            <p>There was an error connecting to the Spark Assist API:</p>
            <pre>{response.status_code} - {response.text}</pre>
            <p>Using sample analysis instead.</p>
            {get_sample_analysis()}
            """
    except Exception as e:
        return f"""
        <h1>⚠️ Error</h1>
        <p>There was an error generating the analysis:</p>
        <pre>{str(e)}</pre>
        <p>Using sample analysis instead.</p>
        {get_sample_analysis()}
        """ 