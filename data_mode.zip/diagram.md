# ADW Workbench Platform – Architecture & Feature Overview

## 1. User Interaction & Web UI
- **User** interacts via a modern web UI (HTML, JS, Bootstrap)
- Selects Databricks catalog/schema/tables, analysis type, and submits analysis requests
- Views results, diagrams, history, and can export reports

## 2. Flask Application Layer (`app.py`)
- Central controller for all HTTP requests and UI rendering
- Handles:
  - Routing (index, analysis, history, export, API endpoints)
  - Session and DB connection management
  - Request parsing (AJAX, form, JSON)
  - Orchestrates the 5-step analysis pipeline:
    1. Databricks connection & discovery
    2. Table selection & metadata gathering
    3. Tree-of-Tables processing (for large/complex tables)
    4. AI analysis & governance (prompt generation, RAG)
    5. Results & reporting (HTML, diagrams, export, history)
- Manages caching, error handling, and status reporting

## 3. Databricks Connector (`databricks_connector.py`)
- Handles all communication with Databricks SQL Warehouse:
  - Catalog/schema/table/column discovery
  - Table details, query history, and performance metrics
  - SQL execution (with cache clearing)
  - Warehouse status management (auto-start, status check)
- Stores metadata and query cache in local SQLite DB

## 4. AI Analysis Engine (`ai_analysis_engine.py`)
- Generates detailed HTML prompts for Spark Assist AI
- Supports 20+ analysis types (core, performance, governance, advanced)
- Injects schema metadata, SQL, and Tree-of-Tables structure into prompts
- Enforces strict HTML/diagram formatting rules
- Handles AI response cleaning and error fallback

## 5. Spark Assist API Client (`ai_api_client.py`)
- Centralized function for all AI API calls
- Sends prompt to Spark Assist (Gemini, OpenAI, etc.)
- Handles API key, endpoint, and response parsing
- Swappable for different AI providers

## 6. Tree-of-Tables Analyzer (`tree_of_tables_analyzer.py`)
- Implements hierarchical decomposition for large tables
- Loads data from Databricks, normalizes, and chunks into context-preserving blocks
- Builds tree structures for schema analysis
- Integrates with vector search for chunk retrieval (RAG)
- Provides governance, performance, and context metrics
- Can create large test tables for simulation

## 7. Vector Search Engine & RAG (`vector_search_engine.py`)
- Uses FAISS and Sentence Transformers for semantic search
- Stores chunk/table embeddings and metadata
- Supports similarity search for RAG (retrieval-augmented generation)
- Used by Tree-of-Tables and DataArchitectureAnalyzer
- Simulates Spark Assist AI for local/test use

## 8. DataArchitectureAnalyzer (in `vector_search_engine.py`)
- Analyzes normalization, denormalization, and architectural standards
- Generates embeddings for all tables
- Tests compliance with 20+ standards (normalization, performance, security, etc.)
- Finds similar tables and generates AI-powered recommendations

## 9. Compliance & Advanced Analysis
- Supports:
  - PII/PCI/GDPR detection
  - ML readiness
  - Data lineage, cost optimization
  - Data catalog, ETL pipeline, audit trail, retention, disaster recovery, migration
- All with dedicated prompt templates and diagram requirements

## 10. Caching & Performance
- Metadata and query results cached in SQLite
- Query cache cleared before every SQL execution to avoid staleness
- Table metadata cached for performance

## 11. History, Export, and Reporting
- All analyses stored in history (SQLite)
- Can view, re-run, or export analyses (HTML/JSON)
- Export includes diagrams, metrics, and recommendations

## 12. Testing & Simulation (`test_suite.py`)
- End-to-end test suite covers:
  - Flask app health
  - Databricks connection
  - Vector DB and similarity search
  - Large table chunking
  - Denormalization analysis
  - AI analysis (Spark Assist)
  - Web interface and workflow
- Simulates Spark Assist AI for local tests

## 13. Static & Template Files
- Modern HTML/CSS/JS for UI
- Templates for all pages (index, analysis, history, export, error)
- Custom JS for dynamic dropdowns, loaders, diagram rendering

## 14. Security & Disclaimer
- All AI-generated content is clearly marked with a disclaimer
- SSL verification can be toggled (currently off for dev/testing)

---

## **Data/Logic Flow Overview**
1. **User** selects tables/analysis → **Flask App**
2. **Flask App** queries **Databricks Connector** for metadata
3. **Tree-of-Tables Analyzer** chunks/structures large tables
4. **Vector Search Engine** indexes chunks, enables RAG
5. **AI Analysis Engine** builds prompt (with schema, tree, SQL)
6. **Spark Assist API Client** sends prompt, gets HTML+diagram
7. **Flask App** renders results, saves to history, allows export
8. **Test Suite** can simulate all flows for validation

---

## **Key Features Visualized for Diagramming**
- User → Flask → Databricks/AI/Tree-of-Tables/Vector Search
- Tree-of-Tables: hierarchical chunking, context preservation
- RAG: semantic search over table/chunk embeddings
- AI Analysis: prompt engineering, diagram enforcement, compliance
- History/Export: persistent storage, re-analysis, reporting
- Testing: full simulation, local Spark Assist AI

---

**Use this as a reference to draw a detailed architecture diagram showing all modules, flows, and advanced features (RAG, Tree-of-Tables, compliance, etc.).** 