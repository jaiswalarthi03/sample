import os
import json
import datetime
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, g, abort
from werkzeug.middleware.proxy_fix import ProxyFix
import databricks_connector
import ai_analysis_engine
from tree_of_tables_analyzer import TreeOfTablesAnalyzer
from config import ANALYSIS_TYPES, ANALYSIS_CATEGORIES

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "adw_workbench_secret")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Initialize Tree-of-Tables analyzer
tree_analyzer = TreeOfTablesAnalyzer()

# Initialize database
def get_db():
    """Connect to the application's SQLite database."""
    if 'db' not in g:
        g.db = sqlite3.connect(
            databricks_connector.DATABASE_PATH
        )
        # Fix for Python 3.12 datetime adapter deprecation warning
        sqlite3.register_adapter(datetime.datetime, lambda dt: dt.isoformat())
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(e=None):
    """Close the database connection at the end of the request."""
    db = g.pop('db', None)
    if db is not None:
        db.close()

app.teardown_appcontext(close_db)

# Initialize database schema
def init_db():
    """Initialize the database schema."""
    databricks_connector.init_db()
    
# Initialize DB at startup
with app.app_context():
    init_db()

@app.before_request
def log_request_info():
    # Only log significant requests, not static files or basic page loads
    if not request.path.startswith('/static/') and request.path != '/':
        print(f"🔄 {request.method} {request.path}")

# Routes
@app.route('/')
def index():
    """Home page - show schema selection UI."""
    # Fetch catalogs from Databricks
    catalogs = databricks_connector.get_catalogs()
    
    return render_template('index.html', 
                          catalogs=catalogs, 
                          analysis_types=ANALYSIS_TYPES,
                          analysis_categories=ANALYSIS_CATEGORIES)

@app.route('/get_schemas/<catalog_name>')
def get_schemas(catalog_name):
    """API endpoint to get schemas for a selected catalog."""
    try:
        schemas = databricks_connector.get_schemas(catalog_name)
        return jsonify(schemas)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/get_tables/<catalog_name>/<schema_name>')
def get_tables(catalog_name, schema_name):
    """API endpoint to get tables for a selected schema."""
    try:
        tables = databricks_connector.get_tables(catalog_name, schema_name)
        return jsonify(tables)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/get_columns/<catalog_name>/<schema_name>/<table_name>')
def get_columns(catalog_name, schema_name, table_name):
    """API endpoint to get columns for a selected table."""
    try:
        columns = databricks_connector.get_columns(catalog_name, schema_name, table_name)
        return jsonify(columns)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/get_selected_tables')
def get_selected_tables():
    """API endpoint to get currently selected tables (for session management)."""
    # Since we're not persisting selections server-side, return empty list
    # The frontend manages selections in memory
    return jsonify([])

@app.route('/clear_selection', methods=['POST'])
def clear_selection():
    """API endpoint to clear table selection."""
    # Since we're not persisting selections server-side, just return success
    return jsonify({"success": True})

@app.route('/analysis', methods=['POST'])
def analyze():
    """
    Run comprehensive analysis on selected tables following the 5-step process:
    Step 1: Connection & Discovery from Databricks
    Step 2: Table Selection & Analysis
    Step 3: Tree-of-Tables Processing
    Step 4: AI Analysis & Governance
    Step 5: Results & Reporting
    """
    try:
        print("🚀 Starting Analysis...")
        
        # Step 1: Connection & Discovery from Databricks
        print("📡 Connecting to Databricks...")
        if not databricks_connector.test_connection():
            return jsonify({"success": False, "error": "Failed to connect to Databricks"}), 500
        
        # Check if this is an AJAX request with JSON
        if request.is_json:
            data = request.get_json()
            selected_tables = data.get('selected_tables', [])
            analysis_type = data.get('analysis_type', 'general')
            sql_query = data.get('sql_query', '')
        else:
            selected_tables = request.form.get('selected_tables', '')
            analysis_type = request.form.get('analysis_type', 'general')
            sql_query = request.form.get('sql_query', '')
            try:
                selected_tables = json.loads(selected_tables)
            except Exception:
                selected_tables = []

        # If no tables selected, return error
        if not selected_tables or len(selected_tables) == 0:
            return jsonify({"success": False, "error": "Please select at least one table for analysis."}), 400

        # Step 2: Table Selection & Analysis
        print("📋 Analyzing Tables...")
        schema_metadata = {}
        table_names = []
        tree_structure = None
        performance_metrics = {}
        
        for t in selected_tables:
            if isinstance(t, dict):
                if 'catalog' in t and 'schema' in t and 'name' in t:
                    catalog_name = t['catalog']
                    schema_name = t['schema']
                    table_name = t['name']
                    table_names.append(f"{catalog_name}.{schema_name}.{table_name}")
                elif 'fullName' in t:
                    parts = t['fullName'].split('.')
                    if len(parts) == 3:
                        catalog_name, schema_name, table_name = parts
                        table_names.append(t['fullName'])
                    else:
                        continue
                elif 'full_name' in t:
                    parts = t['full_name'].split('.')
                    if len(parts) == 3:
                        catalog_name, schema_name, table_name = parts
                        table_names.append(t['full_name'])
                    else:
                        continue
                else:
                    continue
            else:
                continue
            
            # Get comprehensive metadata for this table
            print(f"  📊 {catalog_name}.{schema_name}.{table_name}")
            columns = databricks_connector.get_columns(catalog_name, schema_name, table_name)
            details = databricks_connector.get_table_details(catalog_name, schema_name, table_name)
            
            # Enhanced metadata collection with performance metrics
            table_key = f"{catalog_name}.{schema_name}.{table_name}"
            schema_metadata[table_key] = {
                "columns": columns,
                "details": details,
                "column_count": len(columns),
                "is_large_table": len(columns) > 100,  # Flag for large tables
                "analysis_timestamp": datetime.datetime.now().isoformat()
            }
            
            # Performance optimization: Cache metadata
            cache_metadata(table_key, schema_metadata[table_key])
        
        # Step 3: Tree-of-Tables Processing (Enhanced for large tables)
        print("🌳 Processing Tree Structure...")
        if analysis_type in ['tree_of_tables', 'governance', 'performance']:
            try:
                # Convert table list to format expected by TreeOfTablesAnalyzer
                table_list = []
                for t in selected_tables:
                    if isinstance(t, dict):
                        if 'catalog' in t and 'schema' in t and 'name' in t:
                            table_list.append(t)
                        elif 'fullName' in t:
                            parts = t['fullName'].split('.')
                            if len(parts) == 3:
                                table_list.append({
                                    'catalog': parts[0],
                                    'schema': parts[1],
                                    'name': parts[2]
                                })
                        elif 'full_name' in t:
                            parts = t['full_name'].split('.')
                            if len(parts) == 3:
                                table_list.append({
                                    'catalog': parts[0],
                                    'schema': parts[1],
                                    'name': parts[2]
                                })
                
                # Enhanced Tree-of-Table analysis with context preservation
                print(f"  🔍 Analyzing {len(table_list)} tables...")
                tree_results = tree_analyzer.analyze_multiple_tables(table_list)
                tree_structure = tree_results.get('tree_structures', {})
                
                # Add enhanced tree analysis results to schema metadata
                for table_key, tree_data in tree_structure.items():
                    if table_key in schema_metadata:
                        schema_metadata[table_key]['tree_analysis'] = tree_data
                        # Add context preservation metrics
                        schema_metadata[table_key]['context_preservation'] = {
                            'chunk_count': len(tree_data) if isinstance(tree_data, dict) else 0,
                            'avg_chunk_size': calculate_avg_chunk_size(tree_data),
                            'context_loss_score': calculate_context_loss_score(tree_data)
                        }
                
                print(f"✓ Tree analysis completed")
                
            except Exception as e:
                print(f"⚠️ Tree analysis failed: {str(e)}")
                # Continue with regular analysis if Tree-of-Table fails
        
        # Step 4: AI Analysis & Governance
        print("🤖 AI Analysis...")
        # Generate enhanced prompt with performance optimization context
        prompt = ai_analysis_engine.create_analysis_prompt(
            schema_metadata, 
            analysis_type, 
            sql_query, 
            tree_structure
        )
        
        print("📤 Sending to AI...")
        
        try:
            analysis_result = ai_analysis_engine.generate_analysis(prompt)
        except Exception as e:
            return jsonify({"success": False, "error": f"Spark Assist API error: {str(e)}"}), 500
        
        # Step 5: Results & Reporting
        print("📊 Generating Report...")
        
        # Calculate performance metrics
        performance_metrics = {
            'tables_analyzed': len(table_names),
            'total_columns': sum(len(schema_metadata[key]['columns']) for key in schema_metadata),
            'large_tables': sum(1 for key in schema_metadata if schema_metadata[key].get('is_large_table', False)),
            'analysis_duration': datetime.datetime.now().isoformat(),
            'tree_of_tables_applied': tree_structure is not None
        }
        
        # Store analysis in database for history
        analysis_id = store_analysis_result(analysis_type, table_names, sql_query, analysis_result, performance_metrics)
        
        return jsonify({
            "success": True,
            "analysis_id": analysis_id,
            "analysis_result": analysis_result,
            "tables_analyzed": ", ".join(table_names),
            "metrics": performance_metrics
        })
        
    except Exception as e:
        print(f"❌ Analysis failed: {str(e)}")
        return jsonify({"success": False, "error": str(e)}), 500

def cache_metadata(table_key, metadata):
    """Cache table metadata for performance optimization"""
    try:
        db = get_db()
        cursor = db.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO metadata_cache 
            (table_key, metadata_json, cached_at) 
            VALUES (?, ?, ?)
        """, (table_key, json.dumps(metadata), datetime.datetime.now()))
        db.commit()
    except Exception as e:
        print(f"⚠️ Metadata caching failed: {str(e)}")

def calculate_avg_chunk_size(tree_data):
    """Calculate average chunk size for context preservation metrics"""
    if not isinstance(tree_data, dict):
        return 0
    
    total_size = 0
    chunk_count = 0
    
    for branch, chunks in tree_data.items():
        if isinstance(chunks, list):
            for chunk in chunks:
                if isinstance(chunk, dict) and 'metadata' in chunk:
                    total_size += chunk['metadata'].get('size', 0)
                    chunk_count += 1
    
    return total_size / chunk_count if chunk_count > 0 else 0

def calculate_context_loss_score(tree_data):
    """Calculate context loss score (0-1, where 0 is no loss)"""
    if not isinstance(tree_data, dict):
        return 1.0
    
    # Simple heuristic: more branches = more context loss
    branch_count = len(tree_data)
    return min(branch_count / 10.0, 1.0)  # Normalize to 0-1

def store_analysis_result(analysis_type, table_names, sql_query, analysis_result, metrics):
    """Store analysis result in database"""
    try:
        db = get_db()
        cursor = db.cursor()
        cursor.execute("""
            INSERT INTO analysis_history 
            (analysis_type, tables_analyzed, sql_query, analysis_result, metrics, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            analysis_type, 
            ", ".join(table_names), 
            sql_query, 
            analysis_result, 
            json.dumps(metrics),
            datetime.datetime.now()
        ))
        db.commit()
        return cursor.lastrowid
    except Exception as e:
        print(f"⚠️ Failed to store analysis result: {str(e)}")
        return 1  # Return default ID if storage fails

@app.route('/create_test_tables', methods=['POST'])
def create_test_tables():
    """Create large test tables in Databricks for Tree-of-Table testing."""
    try:
        data = request.get_json() if request.is_json else request.form
        catalog = data.get('catalog', 'default')
        schema = data.get('schema', 'default')
        
        success = tree_analyzer.create_large_test_tables(catalog, schema)
        
        if success:
            return jsonify({
                "success": True,
                "message": f"Test tables created successfully in {catalog}.{schema}",
                "tables": ["large_consent_table", "large_patient_table"]
            })
        else:
            return jsonify({
                "success": False,
                "error": "Failed to create test tables"
            }), 500
            
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/tree_analysis', methods=['POST'])
def tree_analysis():
    """Perform Tree-of-Table analysis on selected tables."""
    try:
        data = request.get_json() if request.is_json else request.form
        selected_tables = data.get('selected_tables', [])
        
        if not selected_tables:
            return jsonify({"success": False, "error": "No tables selected"}), 400
        
        # Convert table list to format expected by TreeOfTablesAnalyzer
        table_list = []
        for t in selected_tables:
            if isinstance(t, dict):
                if 'catalog' in t and 'schema' in t and 'name' in t:
                    table_list.append(t)
                elif 'fullName' in t:
                    parts = t['fullName'].split('.')
                    if len(parts) == 3:
                        table_list.append({
                            'catalog': parts[0],
                            'schema': parts[1],
                            'name': parts[2]
                        })
        
        # Perform Tree-of-Table analysis
        results = tree_analyzer.analyze_multiple_tables(table_list)
        
        return jsonify({
            "success": True,
            "results": results
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/history')
def history():
    """Show analysis history."""
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute(
        """SELECT id, analysis_type, tables_analyzed, sql_query, created_at 
        FROM analysis_history 
        ORDER BY created_at DESC"""
    )
    
    history_items = cursor.fetchall()
    
    return render_template('history.html', history=history_items)

@app.route('/history/<int:analysis_id>', methods=['GET', 'POST'])
def view_analysis(analysis_id):
    """View a saved analysis."""
    db = get_db()
    cursor = db.cursor()
    
    # If POST, it means we're re-running the analysis with a new analysis type
    if request.method == 'POST':
        new_analysis_type = request.form.get('analysis_type')
        
        # Get the existing analysis to reuse tables and SQL
        cursor.execute(
            "SELECT tables_analyzed, sql_query FROM analysis_history WHERE id = ?",
            (analysis_id,)
        )
        existing = cursor.fetchone()
        
        if not existing:
            flash("Analysis not found", "error")
            return redirect(url_for('history'))
            
        tables_string = existing['tables_analyzed']
        sql_query = existing['sql_query']
        
        # Parse tables into the format needed for reanalysis
        tables_list = []
        for table_str in tables_string.split(", "):
            parts = table_str.split(".")
            if len(parts) == 3:
                tables_list.append({
                    "catalog": parts[0],
                    "schema": parts[1],
                    "name": parts[2]
                })
        
        # Rebuild schema metadata
        schema_metadata = {}
        metrics = {}
        
        for table in tables_list:
            catalog_name = table['catalog']
            schema_name = table['schema']
            table_name = table['name']
            
            # Get columns for this table
            columns = databricks_connector.get_columns(catalog_name, schema_name, table_name)
            full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
            
            # Get table details
            table_details = databricks_connector.get_table_details(catalog_name, schema_name, table_name)
            
            # Get query history for this table
            table_queries = databricks_connector.get_query_history(table_name, limit=5)
            
            # Calculate average query duration
            avg_duration = 0
            if table_queries:
                durations = [q['duration_ms'] for q in table_queries]
                avg_duration = sum(durations) / len(durations) if durations else 0
            
            # Store schema metadata
            schema_metadata[full_table_name] = {
                "columns": columns,
                "details": table_details
            }
            
            # Store metrics
            metrics[full_table_name] = {
                "table_size_bytes": table_details.get("size_bytes", 0),
                "file_count": table_details.get("file_count", 0),
                "format": table_details.get("format", "unknown"),
                "query_duration_ms": avg_duration,
                "queries": table_queries
            }
        
        # Generate new analysis using the AI model
        prompt = ai_analysis_engine.create_analysis_prompt(schema_metadata, new_analysis_type, sql_query)
        analysis_result = ai_analysis_engine.generate_analysis(prompt)
        
        # Save as a new analysis in the DB
        cursor.execute(
            """INSERT INTO analysis_history 
            (analysis_type, tables_analyzed, sql_query, analysis_result, metrics, created_at) 
            VALUES (?, ?, ?, ?, ?, ?)""",
            (
                new_analysis_type, 
                tables_string,
                sql_query,
                analysis_result,
                json.dumps(metrics),
                datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            )
        )
        db.commit()
        new_analysis_id = cursor.lastrowid
        
        return redirect(url_for('view_analysis', analysis_id=new_analysis_id))
    
    # GET request - show the analysis
    cursor.execute(
        """SELECT id, analysis_type, tables_analyzed, sql_query, analysis_result, metrics, created_at 
        FROM analysis_history 
        WHERE id = ?""",
        (analysis_id,)
    )
    
    analysis = cursor.fetchone()
    
    if not analysis:
        abort(404)
        
    metrics = json.loads(analysis['metrics']) if analysis['metrics'] else {}
    
    # Already have types as a dictionary
    
    return render_template('analysis.html',
                          analysis_id=analysis_id,
                          analysis_result=analysis['analysis_result'],
                          analysis_type=analysis['analysis_type'],
                          tables_analyzed=analysis['tables_analyzed'],
                          analysis_date=analysis['created_at'],
                          metrics=metrics,
                          sql_query=analysis['sql_query'],
                          from_history=True,
                          analysis_types=ANALYSIS_TYPES)

@app.route('/history/delete/<int:analysis_id>', methods=['POST'])
def delete_analysis(analysis_id):
    """Delete an analysis from history."""
    try:
        db = get_db()
        cursor = db.cursor()
        cursor.execute("DELETE FROM analysis_history WHERE id = ?", (analysis_id,))
        db.commit()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/export/<int:analysis_id>')
def export_analysis(analysis_id):
    """Export analysis results as HTML or JSON."""
    format_type = request.args.get('format', 'html')
    
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute(
        """SELECT id, analysis_type, tables_analyzed, sql_query, analysis_result, metrics, created_at 
        FROM analysis_history 
        WHERE id = ?""",
        (analysis_id,)
    )
    
    analysis = cursor.fetchone()
    
    if not analysis:
        abort(404)
    
    if format_type == 'json':
        # Export as JSON
        export_data = {
            'analysis_id': analysis['id'],
            'analysis_type': analysis['analysis_type'],
            'tables_analyzed': analysis['tables_analyzed'],
            'sql_query': analysis['sql_query'],
            'analysis_result': analysis['analysis_result'],
            'metrics': json.loads(analysis['metrics']) if analysis['metrics'] else {},
            'created_at': analysis['created_at']
        }
        
        response = jsonify(export_data)
        response.headers['Content-Disposition'] = f'attachment; filename=analysis_{analysis_id}.json'
        return response
    
    else:
        # Export as HTML
        metrics = json.loads(analysis['metrics']) if analysis['metrics'] else {}
        
        html_content = render_template('export.html',
                                      analysis_id=analysis_id,
                                      analysis_result=analysis['analysis_result'],
                                      analysis_type=analysis['analysis_type'],
                                      tables_analyzed=analysis['tables_analyzed'],
                                      analysis_date=analysis['created_at'],
                                      metrics=metrics,
                                      sql_query=analysis['sql_query'])
        
        response = app.response_class(html_content, mimetype='text/html')
        response.headers['Content-Disposition'] = f'attachment; filename=analysis_{analysis_id}.html'
        return response

@app.route('/api/databricks_status')
def api_databricks_status():
    from databricks_connector import get_connection_status
    return jsonify(get_connection_status())


@app.errorhandler(404)
def handle_404(e):
    if request.path == '/analysis' and (request.is_json or request.headers.get('Accept') == 'application/json'):
        return jsonify({'success': False, 'error': 'Not found'}), 404
    return render_template('404.html'), 404

@app.errorhandler(500)
def handle_500(e):
    if request.path == '/analysis' and (request.is_json or request.headers.get('Accept') == 'application/json'):
        return jsonify({'success': False, 'error': 'Internal server error'}), 500
    return render_template('500.html'), 500

if __name__ == "__main__":
    # Get port from environment variable or use default
    port = int(os.environ.get('PORT', 5000))
    host = os.environ.get('HOST', '0.0.0.0')
    debug = os.environ.get('DEBUG', 'True').lower() == 'true'
    
    app.run(host=host, port=port, debug=debug)