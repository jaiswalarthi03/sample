import csv
import os
import logging
from typing import List, Dict, Optional, Union

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

RULES_FILE = "rules.csv"

def _get_next_rule_id(rules: List[Dict[str, str]]) -> int:
    """Generates the next available ID for a new rule."""
    if not rules:
        return 1
    return max(int(rule.get('ID', 0)) for rule in rules) + 1

def _read_all_rules() -> List[Dict[str, str]]:
    """Reads all rules from the CSV file, including their IDs."""
    rules = []
    if os.path.exists(RULES_FILE):
        try:
            with open(RULES_FILE, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Ensure all values are strings
                    rules.append({k: str(v) for k, v in row.items()})
        except (IOError, csv.Error) as e:
            logging.error(f"Error reading rules from {RULES_FILE}: {e}")
            raise
    return rules

def _write_all_rules(rules: List[Dict[str, str]]):
    """Writes all rules back to the CSV file."""
    if not rules:
        # If no rules, ensure the file is empty or just headers
        with open(RULES_FILE, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['ID', 'Category', 'Rule']) # Write header even if no rules
        return

    fieldnames = ['ID', 'Category', 'Rule'] # Ensure consistent order
    # Dynamically get all fieldnames from all rules to handle potential new fields
    # For this simple case, we assume 'ID', 'Category', 'Rule' are the only fields
    # fieldnames = list(rules[0].keys()) # More robust for dynamic fields

    try:
        with open(RULES_FILE, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rules)
    except (IOError, csv.Error) as e:
        logging.error(f"Error writing rules to {RULES_FILE}: {e}")
        raise

def get_all_rules(skip: int = 0, limit: int = 100) -> Dict[str, Union[int, List[Dict[str, str]]]]:
    """
    Returns all rules with their IDs, with optional pagination.
    """
    all_rules = _read_all_rules()
    total_count = len(all_rules)
    paginated_rules = all_rules[skip : skip + limit]
    return {"total_count": total_count, "rules": paginated_rules}

def add_rule(category: str, rule_text: str) -> Dict[str, str]:
    """Adds a new rule to the CSV file."""
    rules = _read_all_rules()
    new_id = _get_next_rule_id(rules)
    new_rule = {'ID': str(new_id), 'Category': category, 'Rule': rule_text}
    rules.append(new_rule)
    _write_all_rules(rules)
    logging.info(f"Added new rule: {new_rule}")
    return new_rule

def update_rule(rule_id: Union[str, int], category: str, rule_text: str) -> Optional[Dict[str, str]]:
    """Updates an existing rule in the CSV file by ID."""
    rules = _read_all_rules()
    updated_rule = None
    found = False
    for i, rule in enumerate(rules):
        if str(rule.get('ID')) == str(rule_id):
            rules[i]['Category'] = category
            rules[i]['Rule'] = rule_text
            updated_rule = rules[i]
            found = True
            break
    if found:
        _write_all_rules(rules)
        logging.info(f"Updated rule with ID {rule_id}: {updated_rule}")
        return updated_rule
    logging.warning(f"Rule with ID {rule_id} not found for update.")
    return None

def delete_rule(rule_id: Union[str, int]) -> bool:
    """Deletes a rule from the CSV file by ID."""
    rules = _read_all_rules()
    initial_len = len(rules)
    rules = [rule for rule in rules if str(rule.get('ID')) != str(rule_id)]
    if len(rules) < initial_len:
        _write_all_rules(rules)
        logging.info(f"Deleted rule with ID {rule_id}.")
        return True
    logging.warning(f"Rule with ID {rule_id} not found for deletion.")
    return False

def load_rules_categorized(rules_file: str = RULES_FILE) -> Dict[str, List[str]]:
    """Load validation rules from rules.csv file, categorized by 'Category' column.
    This is the original function, renamed to avoid conflict and clarify purpose.
    """
    rules_by_category = {}
    if os.path.exists(rules_file):
        try:
            with open(rules_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    category = row.get('Category', 'General').strip()
                    rule = row.get('Rule', '').strip()
                    if rule:
                        rules_by_category.setdefault(category, []).append(rule)
        except (IOError, csv.Error) as e:
            logging.error(f"Error loading rules from {rules_file}: {e}")
            raise
    else:
        logging.warning(f"Rules file not found at {rules_file}")
        
    return rules_by_category

# Ensure the rules.csv file exists with headers if it's new
if not os.path.exists(RULES_FILE):
    try:
        with open(RULES_FILE, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['ID', 'Category', 'Rule'])
        logging.info(f"Created empty rules file: {RULES_FILE}")
    except IOError as e:
        logging.error(f"Could not create rules file {RULES_FILE}: {e}")
