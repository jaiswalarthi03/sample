# ADW Data Modeller

A comprehensive data modeling and compliance analysis tool with a React frontend and Python FastAPI backend. This application analyzes Databricks table schemas and performs AI-powered compliance checks using Spark Assist.

## 🚀 Quick Start

### Prerequisites
- **Python 3.8+**
- **Node.js 14+** and npm
- **Databricks workspace** with access token
- **Spark Assist API key**

### Installation

1. **Clone or download the project**
   ```bash
   cd "ADW Data Modeller"
   ```

2. **Install Python dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Install frontend dependencies**
   ```bash
   cd frontend
   npm install
   cd ..
   ```

## ⚙️ Configuration

### Backend Configuration

1. **Edit `config.py`** with your credentials:
   ```python
   # Spark Assist API Configuration
   SPARK_ASSIST_API_KEY = "your-spark-assist-api-key-here"
   SPARK_ASSIST_API_URL = "https://api.spark-assist.com/v1/chat/completions"
   
   # Databricks Configuration
   HOSTNAME = "your-databricks-hostname.cloud.databricks.com"
   TOKEN = "your-databricks-personal-access-token"
   
   # Default Analysis Settings
   DEFAULT_CATALOG = "samples"
   DEFAULT_SCHEMA = "nyctaxi"
   DEFAULT_TABLES = ["trips"]
   ```

2. **Get your Databricks Personal Access Token:**
   - Go to your Databricks workspace
   - Click your profile icon → User Settings
   - Navigate to Access tokens tab
   - Generate new token and copy it

3. **Get your Spark Assist API Key:**
   - Access the Spark Assist platform
   - Generate an API key for the service
   - Copy the key to your configuration

### Frontend Configuration

1. **Edit `frontend/.env`** (if needed):
   ```
   REACT_APP_API_BASE_URL=http://127.0.0.1:8000
   ```

## 🏃‍♂️ Running the Application

### Option 1: Run Both Services Manually

**Terminal 1 - Backend:**
```bash
python app.py
```
The backend API will start at `http://localhost:8000`

**Terminal 2 - Frontend:**
```bash
cd frontend
npm start
```
The frontend will start at `http://localhost:3000`

> ✅ **Status**: Both services are currently running successfully!
> - Backend: `http://localhost:8000` (API documentation at `/docs`)
> - Frontend: `http://localhost:3000` (React development server)
> - Health check: `http://localhost:8000/health`

### Option 2: Run Backend Only (API Mode)

```bash
python app.py
```
Access the API documentation at `http://localhost:8000/docs`

### Option 3: Run Command Line Analysis

```bash
# Analyze default tables
python table_analyzer.py

# Analyze specific tables
python table_analyzer.py --catalog samples --schema nyctaxi --tables trips

# Analyze all tables in a schema
python table_analyzer.py --catalog samples --schema bakehouse --all-tables
```

## 📁 Project Structure

```
ADW Data Modeller/
├── app.py                 # FastAPI backend server
├── table_analyzer.py      # Command-line analysis tool
├── config.py             # Configuration settings
├── ai.py                 # AI compliance checker
├── spark.py              # Spark Assist API client
├── db.py                 # Databricks connection
├── rules.py              # Compliance rules loader
├── rules.csv             # Compliance rules definition
├── requirements.txt      # Python dependencies
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   └── Dashboard.js  # Main analysis interface
│   │   └── services/
│   │       └── api.js        # API client
│   ├── package.json      # Frontend dependencies
│   └── .env              # Frontend configuration
└── analysis_output/
    ├── raw_schemas/      # Extracted table schemas (JSON)
    └── reports/          # Compliance reports (HTML)
```

## 🔧 API Endpoints

- **POST** `/analyze` - Analyze tables and generate compliance reports
  ```json
  {
    "catalog": "samples",
    "schema": "nyctaxi", 
    "tables": ["trips"]
  }
  ```

- **GET** `/docs` - Interactive API documentation
- **GET** `/health` - Health check endpoint

## 📊 Features

### Web Interface
- **Interactive Dashboard** - Select catalogs, schemas, and tables
- **Real-time Analysis** - Live progress tracking with loading animations
- **Compliance Reports** - Detailed HTML reports with AI insights
- **Schema Visualization** - JSON schema extraction and display

### Command Line Interface
- **Batch Processing** - Analyze multiple tables at once
- **Flexible Targeting** - Specify exact tables or entire schemas
- **Rate Limiting** - Built-in delays for responsible API usage
- **Error Handling** - Robust error recovery and logging

### AI-Powered Analysis
- **Compliance Checking** - Automated rule validation
- **Smart Recommendations** - AI-generated improvement suggestions
- **Custom Rules** - Configurable compliance rules via `rules.csv`
- **Detailed Reports** - Comprehensive analysis with explanations

## 🛠️ Development

### Frontend Development
```bash
cd frontend
npm start          # Development server with hot reload
npm run build      # Production build
npm test           # Run tests
```

### Backend Development
```bash
python app.py      # Development server with auto-reload
```

## 📝 Output Files

- **Raw Schemas**: `analysis_output/raw_schemas/[table]_schema.json`
- **Compliance Reports**: `analysis_output/reports/[table]_compliance_report.html`

## 🔒 Security Notes

⚠️ **Important**: This application is configured for development use. For production deployment:

- Use environment variables for sensitive credentials
- Configure proper CORS policies
- Implement authentication and authorization
- Use HTTPS and secure headers
- Set up proper logging and monitoring

## 🐛 Troubleshooting

**Backend won't start:**
- Check Python version (3.8+ required)
- Verify all dependencies are installed: `pip install -r requirements.txt`
- Ensure Databricks credentials are correct

**Frontend won't start:**
- Check Node.js version (14+ required)
- Clear npm cache: `npm cache clean --force`
- Delete `node_modules` and reinstall: `rm -rf node_modules && npm install`

**API connection issues:**
- Verify backend is running on port 8000
- Check `frontend/.env` has correct API URL
- Ensure no firewall blocking localhost connections

**Analysis fails:**
- Verify Databricks token has proper permissions
- Check table/schema names exist in your workspace
- Ensure Spark Assist API key is valid and has credits

## 📄 License

This project is for internal use and development purposes.