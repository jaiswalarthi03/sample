import requests
import logging
from typing import Dict, Any, List, Optional
from config import BASE_URL, HEADERS

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class DatabricksAPIError(Exception):
    """Custom exception for Databricks API errors."""
    pass

def get_catalogs() -> List[str]:
    """
    Get all catalog names using Unity Catalog API.
    """
    url = f"{BASE_URL}/catalogs"
    try:
        response = requests.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        catalogs_info = response.json().get('catalogs', [])
        return [catalog.get('name') for catalog in catalogs_info if catalog.get('name')]
    except requests.exceptions.RequestException as e:
        logging.error(f"Error getting catalogs: {e}")
        raise DatabricksAPIError(f"Failed to get catalogs") from e

def get_schemas(catalog_name: str) -> List[str]:
    """
    Get all schema names in a given catalog using Unity Catalog API.
    """
    url = f"{BASE_URL}/schemas"
    params = {
        "catalog_name": catalog_name
    }
    try:
        response = requests.get(url, headers=HEADERS, params=params, timeout=30)
        response.raise_for_status()
        schemas_info = response.json().get('schemas', [])
        return [schema.get('name') for schema in schemas_info if schema.get('name')]
    except requests.exceptions.RequestException as e:
        logging.error(f"Error getting schemas for {catalog_name}: {e}")
        raise DatabricksAPIError(f"Failed to get schemas for {catalog_name}") from e

def get_tables(catalog_name: str, schema_name: str) -> List[str]:
    """
    Get all table names in a given catalog and schema using Unity Catalog API.
    """
    url = f"{BASE_URL}/tables"
    params = {
        "catalog_name": catalog_name,
        "schema_name": schema_name
    }
    try:
        response = requests.get(url, headers=HEADERS, params=params, timeout=30)
        response.raise_for_status()
        tables_info = response.json().get('tables', [])
        return [table.get('name') for table in tables_info if table.get('name')]
    except requests.exceptions.RequestException as e:
        logging.error(f"Error getting tables for {catalog_name}.{schema_name}: {e}")
        raise DatabricksAPIError(f"Failed to get tables for {catalog_name}.{schema_name}") from e

def get_table_details(catalog: str, schema: str, table: str) -> Dict[str, Any]:
    """
    Get comprehensive table information combining all sources from Unity Catalog API.
    """
    table_url = f"{BASE_URL}/tables/{catalog}.{schema}.{table}"
    details_url = f"{table_url}/details"
    
    try:
        # Fetch basic table info
        table_response = requests.get(table_url, headers=HEADERS, timeout=30)
        table_response.raise_for_status()
        table_details = table_response.json()

        # Fetch detailed Delta table info
        try:
            details_response = requests.get(details_url, headers=HEADERS, timeout=30)
            details_response.raise_for_status()
            delta_details = details_response.json()
            # Merge delta details into the main table details
            table_details.update(delta_details)
        except requests.exceptions.RequestException as e:
            logging.warning(f"Could not get detail info for {catalog}.{schema}.{table}: {e}")
            # Continue without delta details if the endpoint fails

        return table_details
        
    except requests.exceptions.RequestException as e:
        logging.error(f"Error getting extended table info for {catalog}.{schema}.{table}: {e}")
        raise DatabricksAPIError(f"Failed to get extended table info for {catalog}.{schema}.{table}") from e

def extract_comprehensive_schema(table_details: Dict[str, Any]) -> Dict[str, Any]:
    """Extract comprehensive table schema with all Databricks commands consolidated."""
    if not table_details:
        return {}
    
    table_name = table_details.get("name", "")
    catalog = table_details.get("catalog_name", "")
    schema = table_details.get("schema_name", "")
    
    # Comprehensive schema information
    schema_info = {
        "describe_table": {
            "table_name": table_name,
            "catalog": catalog,
            "schema": schema,
            "table_type": table_details.get("table_type", ""),
            "comment": table_details.get("comment", ""),
            "created_at": table_details.get("created_at", ""),
            "updated_at": table_details.get("updated_at", ""),
            "owner": table_details.get("owner", ""),
            "columns": []
        },
        "describe_detail": {
            "location": table_details.get("storage_location", ""),
            "provider": table_details.get("data_source_format", ""),
            "table_id": table_details.get("table_id", ""),
            "metastore_id": table_details.get("metastore_id", ""),
            "full_name": table_details.get("full_name", ""),
            "detail_info": table_details.get("detail_info", {})
        },
        "table_properties": table_details.get("properties", {}),
        "extended_info": {
            "sql_path": table_details.get("sql_path", ""),
            "browse_only": table_details.get("browse_only", False),
            "enable_predictive_optimization": table_details.get("enable_predictive_optimization", False),
            "pipeline_id": table_details.get("pipeline_id", ""),
            "effective_predictive_optimization_flag": table_details.get("effective_predictive_optimization_flag", {})
        }
    }
    
    # Extract column information with comprehensive details
    columns = table_details.get("columns", [])
    for col in columns:
        column_info = {
            "name": col.get("name", ""),
            "type_name": col.get("type_name", ""),
            "type_text": col.get("type_text", ""),
            "type_json": col.get("type_json", ""),
            "type_precision": col.get("type_precision", 0),
            "type_scale": col.get("type_scale", 0),
            "nullable": col.get("nullable", True),
            "position": col.get("position", 0),
            "comment": col.get("comment", ""),
            "partition_index": col.get("partition_index"),
            "type_interval_type": col.get("type_interval_type")
        }
        schema_info["describe_table"]["columns"].append(column_info)
    
    return schema_info
