import requests
import logging
from typing import Optional, Dict, Any

from config import SPARK_ASSIST_API_KEY, SPARK_ASSIST_API_URL

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class AI_API_Error(Exception):
    """Custom exception for AI API errors."""
    pass

def call_generative_ai_api(prompt: str, api_url: str, api_key: str) -> Optional[str]:
    """
    Makes a call to a generative AI API with the given prompt.
    
    Args:
        prompt (str): The text prompt to send to the AI API.
        api_url (str): The URL of the AI API.
        api_key (str): The API key for the AI API.
        
    Returns:
        Optional[str]: The content of the AI API response as a string, or None if an error occurs.
    """
    headers = {
        'Content-Type': 'application/json',
        'X-goog-api-key': api_key
    }
    
    payload = {
        "contents": [
            {
                "parts": [
                    {
                        "text": prompt
                    }
                ]
            }
        ]
    }
    
    try:
        response = requests.post(
            api_url,
            headers=headers,
            json=payload,
            timeout=60
        )
        response.raise_for_status()
        
        result = response.json()
        if 'candidates' in result and len(result['candidates']) > 0:
            content = result['candidates'][0]['content']['parts'][0]['text']
            return content
        else:
            logging.warning("No analysis result returned from the AI API")
            return None
            
    except requests.exceptions.RequestException as e:
        logging.error(f"Error calling AI API: {e}")
        raise AI_API_Error(f"Failed to call AI API") from e
    except (KeyError, IndexError) as e:
        logging.error(f"Error parsing AI API response: {e}")
        raise AI_API_Error("Failed to parse AI API response") from e

def call_spark_assist_api(prompt: str) -> Optional[str]:
    """
    Makes a call to the Spark Assist API with the given prompt.
    
    Args:
        prompt (str): The text prompt to send to the Spark Assist API.
        
    Returns:
        Optional[str]: The content of the Spark Assist API response as a string, or None if an error occurs.
    """
    return call_generative_ai_api(prompt, SPARK_ASSIST_API_URL, SPARK_ASSIST_API_KEY)