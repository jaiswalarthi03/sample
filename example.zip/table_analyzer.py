import argparse
import json
import os
import sys
import time
import logging
from typing import List, Dict, Any

# Import necessary classes and functions from existing modules
from db import get_table_details, extract_comprehensive_schema, get_tables, DatabricksAPIError
from ai import AIComplianceChecker
from rules import load_rules
from config import DEFAULT_CATALOG, DEFAULT_SCHEMA, DEFAULT_TABLES, RATE_LIMIT_SECONDS

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def parse_arguments():
    """
    Parse command line arguments for table analysis.
    """
    parser = argparse.ArgumentParser(
        description="Analyze Databricks table schemas for compliance using AI.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Example:
  python table_analyzer.py --catalog samples --schema bakehouse --tables sales_customers sales_franchises
  python table_analyzer.py --catalog samples --schema bakehouse --all-tables
        """
    )
    
    parser.add_argument(
        '--catalog',
        default=DEFAULT_CATALOG,
        help=f'Databricks catalog name (default: {DEFAULT_CATALOG})'
    )
    parser.add_argument(
        '--schema',
        default=DEFAULT_SCHEMA,
        help=f'Databricks schema name (default: {DEFAULT_SCHEMA})'
    )
    parser.add_argument(
        '--tables',
        nargs='*',
        default=DEFAULT_TABLES,
        help=f'List of table names to analyze (default: {", ".join(DEFAULT_TABLES)})'
    )
    parser.add_argument(
        '--all-tables',
        action='store_true',
        help='Analyze all tables in the specified catalog and schema'
    )
    parser.add_argument(
        '--output-dir',
        default='analysis_output',
        help='Directory to save raw schema JSONs and compliance reports (default: analysis_output)'
    )
    
    return parser.parse_args()

def main():
    """
    Main function to orchestrate table schema extraction and AI compliance analysis.
    """
    args = parse_arguments()

    # Ensure output directories exist
    raw_schemas_dir = os.path.join(args.output_dir, 'raw_schemas')
    reports_dir = os.path.join(args.output_dir, 'reports')
    os.makedirs(raw_schemas_dir, exist_ok=True)
    os.makedirs(reports_dir, exist_ok=True)

    checker = AIComplianceChecker()
    categorized_rules = load_rules()

    if not categorized_rules:
        logging.error("Error: No rules found in rules.csv. Please ensure the file exists and contains rules.")
        sys.exit(1)

    tables_to_analyze = []
    if args.all_tables:
        logging.info(f"Fetching all tables in {args.catalog}.{args.schema}...")
        try:
            tables_to_analyze = get_tables(args.catalog, args.schema)
        except DatabricksAPIError as e:
            logging.error(f"Error: Could not fetch tables for {args.catalog}.{args.schema}. Exiting. Reason: {e}")
            sys.exit(1)
            
        if not tables_to_analyze:
            logging.info(f"No tables found in {args.catalog}.{args.schema}.")
            sys.exit(0)
        logging.info(f"Found {len(tables_to_analyze)} tables to analyze.")
    else:
        tables_to_analyze = args.tables
        if not tables_to_analyze:
            logging.info("No tables specified for analysis. Using default tables from config.py.")
            tables_to_analyze = DEFAULT_TABLES
            if not tables_to_analyze:
                logging.error("Error: No default tables configured and no tables specified. Exiting.")
                sys.exit(1)

    full_analysis_report = []
    
    for i, table_name in enumerate(tables_to_analyze):
        if i > 0:
            logging.info(f"Waiting {RATE_LIMIT_SECONDS} seconds before analyzing next table ({table_name})...")
            time.sleep(RATE_LIMIT_SECONDS)

        logging.info(f"--- Analyzing table: {args.catalog}.{args.schema}.{table_name} ---")
        
        try:
            table_raw_details = get_table_details(args.catalog, args.schema, table_name)
            comprehensive_schema = extract_comprehensive_schema(table_raw_details)
            
            raw_schema_filename = os.path.join(raw_schemas_dir, f"{args.catalog}_{args.schema}_{table_name}_schema.json")
            with open(raw_schema_filename, 'w', encoding='utf-8') as f:
                json.dump(comprehensive_schema, f, indent=4)
            logging.info(f"Raw schema saved to: {raw_schema_filename}")

            schema_data_for_ai = comprehensive_schema
            
            logging.info(f"Sending schema for {table_name} to Spark Assist for compliance check...")
            compliance_report = checker.check_compliance(schema_data_for_ai, categorized_rules)
            
            if compliance_report:
                report_filename = os.path.join(reports_dir, f"{args.catalog}_{args.schema}_{table_name}_compliance_report.md")
                with open(report_filename, 'w', encoding='utf-8') as f:
                    f.write(compliance_report)
                logging.info(f"Compliance report saved to: {report_filename}")
                
                full_analysis_report.append(f"\n## Compliance Report for {args.catalog}.{args.schema}.{table_name}\n")
                full_analysis_report.append(compliance_report)
                full_analysis_report.append("\n" + "="*80 + "\n")
            else:
                logging.warning(f"Failed to get compliance report for {table_name}.")
                full_analysis_report.append(f"\n## Compliance Report for {args.catalog}.{args.schema}.{table_name}\n")
                full_analysis_report.append("Failed to generate report.\n")
                full_analysis_report.append("\n" + "="*80 + "\n")

        except DatabricksAPIError as e:
            logging.error(f"Error processing table {table_name}: {e}")
            full_analysis_report.append(f"\n## Compliance Report for {args.catalog}.{args.schema}.{table_name}\n")
            full_analysis_report.append(f"Error: Failed to extract details for this table: {e}\n")
            full_analysis_report.append("\n" + "="*80 + "\n")
        except Exception as e:
            logging.error(f"An unexpected error occurred while processing table {table_name}: {e}")
            full_analysis_report.append(f"\n## Compliance Report for {args.catalog}.{args.schema}.{table_name}\n")
            full_analysis_report.append(f"Error: An unexpected error occurred: {e}\n")
            full_analysis_report.append("\n" + "="*80 + "\n")

    # Final summary output
    print("\n" + "#"*80)
    print("OVERALL COMPLIANCE ANALYSIS SUMMARY")
    print("#"*80)
    for report_part in full_analysis_report:
        print(report_part)
    print("#"*80)

if __name__ == "__main__":
    main()