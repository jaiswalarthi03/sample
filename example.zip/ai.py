import json
import logging
from typing import List, Dict, Any, Optional

# Import the LLM calling function from spark.py
from spark import call_spark_assist_api, AI_API_Error

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class AIComplianceChecker:
    def __init__(self):
        pass

    def _densify_json(self, data: Dict[str, Any]) -> str:
        """Converts a dictionary to a compact JSON string, removes all whitespace and newlines."""
        return json.dumps(data, separators=(',', ':'))
    
    def _build_prompt(self, schema_data: Dict[str, Any], categorized_rules: Dict[str, List[str]]) -> str:
        """Builds the prompt for the AI compliance check."""
        if not schema_data or 'describe_table' not in schema_data:
            raise ValueError("Invalid schema data provided.")
        
        table_info = schema_data['describe_table']
        table_name = table_info.get('table_name', 'N/A')
        columns = table_info.get('columns', [])
        
        table_comment = table_info.get('comment', 'No table comment provided.')
        table_properties = schema_data.get('table_properties', {})
        
        column_details = []
        for col in columns:
            col_name = col.get('name', 'N/A')
            col_comment = col.get('comment', 'No column comment provided.')
            column_details.append(f"- Column Name: {col_name}, Comment: '{col_comment}'")

        rules_text_parts = []
        for category, rules_list in categorized_rules.items():
            rules_text_parts.append(f"### {category} Rules:")
            for i, rule in enumerate(rules_list):
                rules_text_parts.append(f"{i+1}. {rule}")
        all_rules_text = "\n".join(rules_text_parts)

        densified_schema_data = self._densify_json(schema_data)

        prompt_parts = [
            "You are an expert data model compliance checker. Your task is to analyze the provided database schema against a set of naming standard rules, mandatory columns, mandatory tags, and documentation standards.",
            "For each rule, determine if the schema complies. Provide a clear 'Yes' or 'No' for compliance.",
            "If a rule is not complied with, provide a brief explanation of why, including specific examples from the schema if possible.",
            "The output MUST be in HTML format, structured EXACTLY as follows, using the provided CSS classes for styling. Minimize vertical space between elements:",
            "```html",
            "<div class=\"compliance-report\">",
            "    <h2>Compliance Report for Table: [table_name]</h2>",
            "",
            "    <h3>[Category Name] Rules:</h3>",
            "    <div class=\"rule-item\">",
            "        <h4>Rule 1: [Rule Text]</h4>",
            "        <p>",
            "            <strong>Complied:</strong> <span class=\"complied-yes\">&#10003; Yes</span> / <span class=\"complied-no\">&#10007; No</span>",
            "        </p>",
            "        <p>",
            "            <strong>Details:</strong> [Provide specific details. If not complied, explain why and give an example of the violation and how to fix it. If complied, state 'N/A' or 'Complied.']",
            "        </p>",
            "    </div>",
            "    <div class=\"rule-item\">",
            "        <h4>Rule 2: [Rule Text]</h4>",
            "        <p>",
            "            <strong>Complied:</strong> <span class=\"complied-yes\">&#10003; Yes</span> / <span class=\"complied-no\">&#10007; No</span>",
            "        </p>",
            "        <p>",
            "            <strong>Details:</strong> [Provide specific details. If not complied, explain why and give an example of the violation and how to fix it. If complied, state 'N/A' or 'Complied.']",
            "        </p>",
            "    </div>",
            "    <!-- ... continue for all rules within the category -->",
            "",
            "    <h3>[Another Category Name] Rules:</h3>",
            "    <div class=\"rule-item\">",
            "        <h4>Rule 1: [Rule Text]</h4>",
            "        <p>",
            "            <strong>Complied:</strong> <span class=\"complied-yes\">&#10003; Yes</span> / <span class=\"complied-no\">&#10007; No</span>",
            "        </p>",
            "        <p>",
            "            <strong>Details:</strong> [Provide specific details. If not complied, explain why and give an example of the violation and how to fix it. If complied, state 'N/A' or 'Complied.']",
            "        </p>",
            "    </div>",
            "    <!-- ... continue for all categories and rules -->",
            "</div>",
            "```",
            "",
            "Dos and Don'ts for your analysis:",
            "- DO strictly adhere to the requested Markdown output format.",
            "- DO provide 'Yes' or 'No' for 'Complied'.",
            "- DO provide concrete examples for 'Details' when a rule is NOT complied. For instance, if 'customerID' violates snake_case, state: 'Violation: Column \'customerID\' is not snake_case. Example: \'customerID\' should be \'customer_id\'.',",
            "- DO NOT include the full list of table properties in the 'Details' for tag-related rules. Simply state whether the tag is present or not.",
            "- DO NOT make assumptions about compliance; base your analysis strictly on the provided schema and rules.",
            "- DO NOT include any conversational text outside the Markdown report.",
            "- DO NOT skip any rules; provide a compliance status for every rule listed.",
            "",
            "Here are the rules to check against:",
            all_rules_text,
            "",
            "Here is the schema data (densified JSON, focus on table_name, column_name, properties, and comments for compliance check):",
            f"Table Name: {table_name}",
            f"Table Comment: '{table_comment}'",
            f"Table Property Keys: {list(table_properties.keys())}",
            "Columns:",
            "\n".join(column_details),
            "",
            "Densified Schema JSON:",
            densified_schema_data,
            ""
        ]
        return "\n".join(prompt_parts)

    def check_compliance(self, schema_data: Dict[str, Any], categorized_rules: Dict[str, List[str]]) -> Optional[str]:
        """
        Send schema data and categorized rules to LLM API for compliance checking.
        """
        try:
            prompt = self._build_prompt(schema_data, categorized_rules)
            logging.info(f"Final prompt size (characters): {len(prompt)}")
            
            compliance_report = call_spark_assist_api(prompt)
            # Remove markdown code block fences if present
            if compliance_report:
                compliance_report = compliance_report.replace("```html", "").replace("```", "").strip()

                # Calculate metrics
                rules_passed = compliance_report.count('class="complied-yes"')
                rules_failed = compliance_report.count('class="complied-no"')
                total_rules = rules_passed + rules_failed
                compliance_rate = 0
                if total_rules > 0:
                    compliance_rate = int((rules_passed / total_rules) * 100)

                # Create metric cards HTML
                metrics_html = f"""
<style>
    .metrics-container {{
        display: flex;
        justify-content: space-around;
        margin-bottom: 20px;
    }}
    .metric-card {{
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 20px;
        text-align: center;
        width: 22%;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }}
    .metric-card h3 {{
        margin: 0;
        font-size: 2.5em;
        color: #333;
    }}
    .metric-card p {{
        margin: 5px 0 0;
        font-size: 1em;
        color: #666;
    }}
</style>
<div class="metrics-container">
    <div class="metric-card">
        <h3>{compliance_rate}%</h3>
        <p>Compliance Rate</p>
    </div>
    <div class="metric-card">
        <h3>{total_rules}</h3>
        <p>Total Rules Checked</p>
    </div>
    <div class="metric-card">
        <h3>{rules_passed}</h3>
        <p>Rules Passed</p>
    </div>
    <div class="metric-card">
        <h3>{rules_failed}</h3>
        <p>Issues Found</p>
    </div>
</div>
"""

                # Inject metrics into the report
                h2_end_tag = "</h2>"
                report_parts = compliance_report.split(h2_end_tag)
                if len(report_parts) == 2:
                    compliance_report = report_parts[0] + h2_end_tag + metrics_html + report_parts[1]

            return compliance_report
        except (ValueError, AI_API_Error) as e:
            logging.error(f"Failed to check compliance: {e}")
            return None
