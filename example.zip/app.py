from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os
import json
import time
import logging
from typing import List, Optional, Dict, Any, Union

# Import necessary classes and functions from existing modules
from db import get_table_details, extract_comprehensive_schema, get_tables, get_catalogs, get_schemas, DatabricksAPIError
from ai import AIComplianceChecker
from rules import get_all_rules, add_rule, update_rule, delete_rule, load_rules_categorized
from config import DEFAULT_CATALOG, DEFAULT_SCHEMA, DEFAULT_TABLES, RATE_LIMIT_SECONDS

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

origins = [
    "*", # Temporarily allow all origins for debugging CORS
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Request model for the analysis endpoint
class AnalysisRequest(BaseModel):
    catalog: Optional[str] = DEFAULT_CATALOG
    schema: Optional[str] = DEFAULT_SCHEMA
    tables: Optional[List[str]] = DEFAULT_TABLES
    all_tables: Optional[bool] = False
    output_dir: Optional[str] = 'analysis_output'

@app.post("/analyze_tables/")
async def analyze_tables_post(request: AnalysisRequest):
    """
    API endpoint to trigger Databricks table schema extraction and AI compliance analysis via POST.
    """
    catalog = request.catalog
    schema = request.schema
    tables = request.tables
    all_tables = request.all_tables
    output_dir = request.output_dir

    return await _analyze_tables_core(catalog, schema, tables, all_tables, output_dir)

@app.get("/analyze_tables/")
async def analyze_tables_get(
    catalog: str = DEFAULT_CATALOG,
    schema: str = DEFAULT_SCHEMA,
    tables: Optional[List[str]] = DEFAULT_TABLES,
    all_tables: bool = False,
    output_dir: str = 'analysis_output'
):
    """
    API endpoint to trigger Databricks table schema extraction and AI compliance analysis via GET.
    """
    return await _analyze_tables_core(catalog, schema, tables, all_tables, output_dir)

async def _analyze_tables_core(
    catalog: str,
    schema: str,
    tables: Optional[List[str]],
    all_tables: bool,
    output_dir: str
):
    """
    Core logic for Databricks table schema extraction and AI compliance analysis.
    """

    # Ensure output directories exist
    raw_schemas_dir = os.path.join(output_dir, 'raw_schemas')
    reports_dir = os.path.join(output_dir, 'reports')
    os.makedirs(raw_schemas_dir, exist_ok=True)
    os.makedirs(reports_dir, exist_ok=True)

    checker = AIComplianceChecker()
    categorized_rules = load_rules_categorized()

    if not categorized_rules:
        raise HTTPException(status_code=500, detail="Error: No rules found in rules.csv. Please ensure the file exists and contains rules.")

    tables_to_analyze = []
    if all_tables:
        logging.info(f"Fetching all tables in {catalog}.{schema}...")
        try:
            tables_to_analyze = get_tables(catalog, schema)
        except DatabricksAPIError as e:
            raise HTTPException(status_code=500, detail=f"Error: Could not fetch tables for {catalog}.{schema}. Reason: {e}")
            
        if not tables_to_analyze:
            return {"message": f"No tables found in {catalog}.{schema}."}
        logging.info(f"Found {len(tables_to_analyze)} tables to analyze.")
    else:
        tables_to_analyze = tables
        if not tables_to_analyze:
            logging.info("No tables specified for analysis. Using default tables from config.py.")
            tables_to_analyze = DEFAULT_TABLES
            if not tables_to_analyze:
                raise HTTPException(status_code=500, detail="Error: No default tables configured and no tables specified.")

    analysis_results = []
    
    for i, table_name in enumerate(tables_to_analyze):
        if i > 0:
            logging.info(f"Waiting {RATE_LIMIT_SECONDS} seconds before analyzing next table ({table_name})...")
            time.sleep(RATE_LIMIT_SECONDS)

        logging.info(f"--- Analyzing table: {catalog}.{schema}.{table_name} ---")
        
        try:
            table_raw_details = get_table_details(catalog, schema, table_name)
            comprehensive_schema = extract_comprehensive_schema(table_raw_details)
            
            raw_schema_filename = os.path.join(raw_schemas_dir, f"{catalog}_{schema}_{table_name}_schema.json")
            with open(raw_schema_filename, 'w', encoding='utf-8') as f:
                json.dump(comprehensive_schema, f, indent=4)
            logging.info(f"Raw schema saved to: {raw_schema_filename}")

            schema_data_for_ai = comprehensive_schema
            
            logging.info(f"Sending schema for {table_name} to Spark Assist for compliance check...")
            compliance_report = checker.check_compliance(schema_data_for_ai, categorized_rules)
            
            result_entry = {
                "table": f"{catalog}.{schema}.{table_name}",
                "raw_schema_file": raw_schema_filename,
                "compliance_report_file": None,
                "status": "success"
            }

            if compliance_report:
                report_filename = os.path.join(reports_dir, f"{catalog}_{schema}_{table_name}_compliance_report.html")
                with open(report_filename, 'w', encoding='utf-8') as f:
                    f.write(compliance_report)
                logging.info(f"Compliance report saved to: {report_filename}")
                result_entry["compliance_report_file"] = report_filename
                result_entry["compliance_report_html"] = compliance_report # Add HTML content to response
            else:
                logging.warning(f"Failed to get compliance report for {table_name}.")
                result_entry["status"] = "warning"
                result_entry["message"] = "Failed to generate compliance report."

            analysis_results.append(result_entry)

        except DatabricksAPIError as e:
            logging.error(f"Error processing table {table_name}: {e}")
            analysis_results.append({
                "table": f"{catalog}.{schema}.{table_name}",
                "status": "error",
                "message": f"Databricks API Error: {e}"
            })
        except Exception as e:
            logging.error(f"An unexpected error occurred while processing table {table_name}: {e}")
            analysis_results.append({
                "table": f"{catalog}.{schema}.{table_name}",
                "status": "error",
                "message": f"Unexpected Error: {e}"
            })
    
    return {"message": "Analysis complete", "results": analysis_results}

from rules import get_all_rules, add_rule, update_rule, delete_rule, load_rules_categorized

# Pydantic models for rules management
class RuleCreate(BaseModel):
    category: str
    rule_text: str

class RuleUpdate(BaseModel):
    category: str
    rule_text: str

@app.get("/rules/", response_model=Dict[str, Union[int, List[Dict[str, str]]]])
async def read_rules(skip: int = 0, limit: int = 100):
    """
    Retrieve all rules with pagination.
    """
    return get_all_rules(skip=skip, limit=limit)

@app.post("/rules/", response_model=Dict[str, str], status_code=201)
async def create_rule(rule: RuleCreate):
    """
    Add a new rule.
    """
    new_rule = add_rule(rule.category, rule.rule_text)
    return new_rule

@app.put("/rules/{rule_id}", response_model=Optional[Dict[str, str]])
async def update_single_rule(rule_id: int, rule: RuleUpdate):
    """
    Update an existing rule by ID.
    """
    updated_rule = update_rule(rule_id, rule.category, rule.rule_text)
    if not updated_rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    return updated_rule

@app.delete("/rules/{rule_id}", status_code=204)
async def delete_single_rule(rule_id: int):
    """
    Delete a rule by ID.
    """
    if not delete_rule(rule_id):
        raise HTTPException(status_code=404, detail="Rule not found")
    return {"message": "Rule deleted successfully"}

@app.get("/catalogs/", response_model=List[str])
async def list_catalogs():
    """
    Retrieve a list of all available catalogs.
    """
    try:
        return get_catalogs()
    except DatabricksAPIError as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving catalogs: {e}")

@app.get("/schemas/{catalog_name}", response_model=List[str])
async def list_schemas(catalog_name: str):
    """
    Retrieve a list of schemas within a specified catalog.
    """
    try:
        return get_schemas(catalog_name)
    except DatabricksAPIError as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving schemas for catalog {catalog_name}: {e}")

@app.get("/tables/{catalog_name}/{schema_name}", response_model=List[str])
async def list_tables(catalog_name: str, schema_name: str):
    """
    Retrieve a list of tables within a specified catalog and schema.
    """
    try:
        return get_tables(catalog_name, schema_name)
    except DatabricksAPIError as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving tables for {catalog_name}.{schema_name}: {e}")

@app.get("/")
async def root():
    return {"message": "Welcome to the Databricks Table Analyzer API. Use /docs for API documentation."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
