# config.py

import os

# Configuration for API Keys and Endpoints

# Spark Assist API Configuration
# Load from environment variables for better security, fallback to hardcoded values
SPARK_ASSIST_API_KEY = os.getenv("SPARK_ASSIST_API_KEY", "AIzaSyArUnz_XPElfgwK8PgZ_HR67RvLbK-J71w")
SPARK_ASSIST_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

# Databricks Configuration
# Load from environment variables for better security, fallback to hardcoded values
HOSTNAME = os.getenv("DATABRICKS_HOSTNAME", "dbc-0dd33e8f-e6be.cloud.databricks.com")
TOKEN = os.getenv("DATABRICKS_TOKEN", "dapi66447cd35cbee8c9b2ac27548b1797f5")

# API Configuration
BASE_URL = f"https://{HOSTNAME}/api/2.1/unity-catalog"
HEADERS = {
    "Authorization": f"Bearer {TOKEN}",
    "Content-Type": "application/json"
}

# Default table information (can be overridden by command line arguments)
DEFAULT_CATALOG = "samples"
DEFAULT_SCHEMA = "bakehouse"
DEFAULT_TABLES = ["sales_customers"]

# Rate limiting for API calls
RATE_LIMIT_SECONDS = 5
