const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://127.0.0.1:8000'; // Use environment variable or fallback

export const fetchCatalogs = async () => {
  const response = await fetch(`${API_BASE_URL}/catalogs/`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
};

export const fetchSchemas = async (catalogName) => {
  const response = await fetch(`${API_BASE_URL}/schemas/${catalogName}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
};

export const fetchTables = async (catalogName, schemaName) => {
  const response = await fetch(`${API_BASE_URL}/tables/${catalogName}/${schemaName}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
};

export const analyzeTables = async (catalog, schema, tables, allTables, outputDir) => {
  const requestBody = {
    catalog,
    schema,
    tables,
    all_tables: allTables,
    output_dir: outputDir
  };

  const response = await fetch(`${API_BASE_URL}/analyze_tables/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestBody)
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
};

export const fetchRules = async (skip = 0, limit = 100) => {
  const params = new URLSearchParams();
  params.append('skip', skip);
  params.append('limit', limit);
  
  const response = await fetch(`${API_BASE_URL}/rules/?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
};

export const createRule = async (ruleData) => {
  const response = await fetch(`${API_BASE_URL}/rules/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(ruleData),
  });
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
};

export const updateRule = async (ruleId, ruleData) => {
  const response = await fetch(`${API_BASE_URL}/rules/${ruleId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(ruleData),
  });
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.json();
};

export const deleteRule = async (ruleId) => {
  const response = await fetch(`${API_BASE_URL}/rules/${ruleId}`, {
    method: 'DELETE',
  });
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  return response.status === 204; // No content for successful deletion
};
