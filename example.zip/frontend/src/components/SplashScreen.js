import React from 'react';
import './SplashScreen.css';

const SplashScreen = () => {
  return (
    <div className="splash-screen">
      <div className="sun-rays-effect"></div>
      <img src="/data.gif" alt="Loading..." className="splash-logo" />
      <h1 className="splash-title">ADW <span className="red-text">Data Modeller</span></h1>
      <p className="splash-subtitle">Loading...</p>
    </div>
  );
};

export default SplashScreen;
