import React from 'react';
import { NavLink } from 'react-router-dom';
import './Header.css';

const Header = () => {
  return (
    <header className="simple-header">
      <div className="header-content">
        <div className="header-left">
          <img src="/data.gif" alt="ADW Data Modeller Logo" className="logo" />
          <div className="app-title">
            <span style={{ color: '#000' }}>ADW</span> <span style={{ color: '#dc2626' }}>Data Modeller</span>
          </div>
        </div>
        <div className="header-right">
          <nav className="nav-buttons">
            <NavLink to="/" className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span role="img" aria-label="dashboard">🏠</span> Dashboard
            </NavLink>
            <NavLink to="/rules" className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span role="img" aria-label="rules">📜</span> Rules
            </NavLink>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
