import React, { useState, useEffect } from 'react';
import { fetchRules, createRule, updateRule, deleteRule } from '../services/api';

const ITEMS_PER_PAGE = 5; // Define how many rules per page

function Rules() {
  const [rules, setRules] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [newRuleCategory, setNewRuleCategory] = useState('');
  const [newRuleText, setNewRuleText] = useState('');
  const [editingRuleId, setEditingRuleId] = useState(null);
  const [editedRule, setEditedRule] = useState({ ID: null, Category: '', Rule: '' });

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [totalRules, setTotalRules] = useState(0);

  const getRules = async (page = currentPage) => {
    try {
      setLoading(true);
      setError(''); // Clear previous errors
      console.log(`Fetching rules for page: ${page}, skip: ${(page - 1) * ITEMS_PER_PAGE}, limit: ${ITEMS_PER_PAGE}`);
      const skip = (page - 1) * ITEMS_PER_PAGE;
      const limit = ITEMS_PER_PAGE; // Fixed typo here
      const response = await fetchRules(skip, limit); // Pass skip and limit
      console.log('Fetch rules response:', response.rules, response.total_count);
      setRules(response.rules);
      setTotalRules(response.total_count);
      setCurrentPage(page);
    } catch (err) {
      setError('Failed to fetch rules: ' + err.message);
      console.error('Error fetching rules:', err);
    } finally {
      setLoading(false);
      console.log('Loading state set to false.');
    }
  };

  useEffect(() => {
    getRules();
  }, []);

  const handleAddRule = async (e) => {
    e.preventDefault();
    if (!newRuleCategory || !newRuleText) {
      setError('Category and Rule text cannot be empty.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await createRule({ category: newRuleCategory, rule_text: newRuleText });
      setNewRuleCategory('');
      setNewRuleText('');
      await getRules(1); // Refresh the list and go to first page
    } catch (err) {
      setError('Failed to add rule: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEditClick = (rule) => {
    setEditingRuleId(rule.ID);
    setEditedRule({ ID: rule.ID, Category: rule.Category, Rule: rule.Rule });
  };

  const handleCancelEdit = () => {
    setEditingRuleId(null);
    setEditedRule({ ID: null, Category: '', Rule: '' });
  };

  const handleUpdateRule = async (e) => {
    e.preventDefault();
    if (!editedRule.Category || !editedRule.Rule) {
      setError('Category and Rule text cannot be empty.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await updateRule(editedRule.ID, { category: editedRule.Category, rule_text: editedRule.Rule });
      setEditingRuleId(null); // Exit editing mode
      setEditedRule({ ID: null, Category: '', Rule: '' }); // Clear edited rule state
      await getRules(currentPage); // Refresh the current page
    } catch (err) {
      setError('Failed to update rule: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteRule = async (ruleId) => {
    if (window.confirm('Are you sure you want to delete this rule?')) {
      setError('');
      setLoading(true);
      try {
        await deleteRule(ruleId);
        // If the last item on a page is deleted, go to the previous page if not on the first page
        const newTotalRules = totalRules - 1;
        const newMaxPage = Math.ceil(newTotalRules / ITEMS_PER_PAGE) || 1;
        const pageToFetch = currentPage > newMaxPage ? newMaxPage : currentPage;
        await getRules(pageToFetch); // Refresh the list
      } catch (err) {
        setError('Failed to delete rule: ' + err.message);
      } finally {
        setLoading(false);
      }
    }
  };

  const totalPages = Math.ceil(totalRules / ITEMS_PER_PAGE);

  return (
    <div className="rules-page">
      <h1>Rules Management</h1>
      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}

      <h2>Add New Rule</h2>
      <form onSubmit={handleAddRule} style={{ marginBottom: '30px', border: '1px solid #eee', padding: '20px', borderRadius: '5px' }}>
        <div>
          <label htmlFor="new-category">Category:</label>
          <input
            type="text"
            id="new-category"
            value={newRuleCategory}
            onChange={(e) => setNewRuleCategory(e.target.value)}
            disabled={loading}
            required
          />
        </div>
        <div style={{ marginTop: '10px' }}>
          <label htmlFor="new-rule-text">Rule Text:</label>
          <textarea
            id="new-rule-text"
            value={newRuleText}
            onChange={(e) => setNewRuleText(e.target.value)}
            disabled={loading}
            required
            rows="3"
            style={{ width: '100%', resize: 'vertical' }}
          ></textarea>
        </div>
        <button type="submit" disabled={loading} style={{ marginTop: '10px', padding: '8px 15px', cursor: 'pointer' }}>
          Add Rule
        </button>
      </form>

      <h2>Existing Rules</h2>
      {rules.length === 0 && !loading ? (
        <p>No rules found. Add some rules above.</p>
      ) : (
        <>
          <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px' }}>
            <thead>
              <tr style={{ backgroundColor: '#f2f2f2' }}>
                <th style={{ border: '1px solid #ddd', padding: '8px', textAlign: 'left' }}>ID</th>
                <th style={{ border: '1px solid #ddd', padding: '8px', textAlign: 'left' }}>Category</th>
                <th style={{ border: '1px solid #ddd', padding: '8px', textAlign: 'left' }}>Rule</th>
                <th style={{ border: '1px solid #ddd', padding: '8px', textAlign: 'left' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rules.map((rule) => (
                <tr key={rule.ID}>
                  <td style={{ border: '1px solid #ddd', padding: '8px' }}>{rule.ID}</td>
                  <td style={{ border: '1px solid #ddd', padding: '8px' }}>
                    {editingRuleId === rule.ID ? (
                      <input
                        type="text"
                        value={editedRule.Category}
                        onChange={(e) => setEditedRule(prev => ({ ...prev, Category: e.target.value }))}
                        disabled={loading}
                      />
                    ) : (
                      rule.Category
                    )}
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '8px' }}>
                    {editingRuleId === rule.ID ? (
                      <textarea
                        value={editedRule.Rule}
                        onChange={(e) => setEditedRule(prev => ({ ...prev, Rule: e.target.value }))}
                        disabled={loading}
                        rows="2"
                        style={{ width: '100%', resize: 'vertical' }}
                      ></textarea>
                    ) : (
                      rule.Rule
                    )}
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '8px' }}>
                    {editingRuleId === rule.ID ? (
                      <>
                        <button onClick={handleUpdateRule} disabled={loading} style={{ marginRight: '5px', padding: '5px 10px', cursor: 'pointer' }}>Save</button>
                        <button onClick={handleCancelEdit} disabled={loading} style={{ padding: '5px 10px', cursor: 'pointer' }}>Cancel</button>
                      </>
                    ) : (
                      <>
                        <button onClick={() => handleEditClick(rule)} disabled={loading} style={{ marginRight: '5px', padding: '5px 10px', cursor: 'pointer' }}>Edit</button>
                        <button onClick={() => handleDeleteRule(rule.ID)} disabled={loading} style={{ padding: '5px 10px', cursor: 'pointer', backgroundColor: '#dc3545', color: 'white', border: 'none' }}>Delete</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px' }}>
              <button
                onClick={() => getRules(currentPage - 1)}
                disabled={currentPage === 1 || loading}
                style={{ padding: '8px 15px', cursor: 'pointer' }}
              >
                Previous
              </button>
              <span>Page {currentPage} of {totalPages}</span>
              <button
                onClick={() => getRules(currentPage + 1)}
                disabled={currentPage === totalPages || loading}
                style={{ padding: '8px 15px', cursor: 'pointer' }}
              >
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default Rules;
