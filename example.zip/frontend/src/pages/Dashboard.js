import React, { useState, useEffect } from 'react';
import { fetchCatalogs, fetchSchemas, fetchTables, analyzeTables } from '../services/api';
import SplashScreen from '../components/SplashScreen';
import './Dashboard.css';

function Dashboard() {
  const [catalogs, setCatalogs] = useState([]);
  const [selectedCatalog, setSelectedCatalog] = useState('');
  const [schemas, setSchemas] = useState([]);
  const [selectedSchema, setSelectedSchema] = useState('');
  const [tables, setTables] = useState([]);
  const [selectedTables, setSelectedTables] = useState([]);
  const [analysisReport, setAnalysisReport] = useState('');
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [error, setError] = useState('');
  const [dots, setDots] = useState(''); // New state for loading dots

  // Fetch catalogs on component mount
  useEffect(() => {
    const getCatalogs = async () => {
      try {
        const data = await fetchCatalogs();
        setCatalogs(data);
        if (data.length > 0) {
          setSelectedCatalog(data[0]); // Select first catalog by default
        }
      } catch (err) {
        setError('Failed to fetch catalogs: ' + err.message);
      } finally {
        setInitialLoading(false);
      }
    };
    getCatalogs();
  }, []);

  // Fetch schemas when selectedCatalog changes
  useEffect(() => {
    if (selectedCatalog) {
      const getSchemas = async () => {
        try {
          setLoading(true);
          const data = await fetchSchemas(selectedCatalog);
          setSchemas(data);
          setSelectedSchema(data.length > 0 ? data[0] : ''); // Select first schema by default
        } catch (err) {
          setError(`Failed to fetch schemas for ${selectedCatalog}: ` + err.message);
        } finally {
          setLoading(false);
        }
      };
      getSchemas();
    } else {
      setSchemas([]);
      setSelectedSchema('');
    }
  }, [selectedCatalog]);

  // Fetch tables when selectedSchema changes
  useEffect(() => {
    if (selectedCatalog && selectedSchema) {
      const getTables = async () => {
        try {
          setLoading(true);
          const data = await fetchTables(selectedCatalog, selectedSchema);
          setTables(data);
          setSelectedTables([]); // Clear selected tables when schema changes
        } catch (err) {
          setError(`Failed to fetch tables for ${selectedCatalog}.${selectedSchema}: ` + err.message);
        } finally {
          setLoading(false);
        }
      };
      getTables();
    } else {
      setTables([]);
      setSelectedTables([]);
    }
  }, [selectedCatalog, selectedSchema]);

  // New useEffect for loading dots animation
  useEffect(() => {
    if (loading) {
      const interval = setInterval(() => {
        setDots(prevDots => {
          if (prevDots.length >= 3) {
            return '';
          }
          return prevDots + '.';
        });
      }, 500); // Change every 500ms
      return () => clearInterval(interval);
    } else {
      setDots(''); // Reset dots when not loading
    }
  }, [loading]);

  const handleAnalyze = async () => {
    if (!selectedCatalog || !selectedSchema || selectedTables.length === 0) {
      setError('Please select a catalog, schema, and at least one table.');
      return;
    }
    setError('');
    setLoading(true);
    setAnalysisReport('');
    try {
      const result = await analyzeTables(selectedCatalog, selectedSchema, selectedTables, false, 'analysis_output');
      if (result.results && result.results.length > 0) {
        const allReports = result.results
          .filter(r => r.compliance_report_html)
          .map(r => r.compliance_report_html)
          .join('<div style="margin: 20px 0; border-top: 2px solid #ccc;"></div>');
        
        if (allReports) {
          setAnalysisReport(allReports);
        } else {
          const reportFiles = result.results
            .filter(r => r.compliance_report_file)
            .map(r => r.compliance_report_file)
            .join(', ');
          
          if (reportFiles) {
            setAnalysisReport(`Analysis complete. Reports saved to: ${reportFiles}`);
          }
        }
      }
    } catch (err) {
      setError('Failed to run analysis: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  if (initialLoading) {
    return <SplashScreen />;
  }

  return (
    <div className="dashboard-page">
      {loading && (
        <div className="loading-overlay">
          <div className="loading-container">
            <img src="/loader.gif" alt="Loading..." className="loading-gif" />
            <p className="loading-text">Loading{dots}</p>
          </div>
        </div>
      )}
      {error && <p className="error">Error: {error}</p>}
      <div className="dashboard-content">
        <div className="sidebar">
          <h3>Select Data for Analysis</h3>
          <div className="form-group">
            <label htmlFor="catalog-select">Catalog:</label>
            <select
              id="catalog-select"
              value={selectedCatalog}
              onChange={(e) => setSelectedCatalog(e.target.value)}
              disabled={loading}
            >
              <option value="">Select a Catalog</option>
              {catalogs.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="schema-select">Schema:</label>
            <select
              id="schema-select"
              value={selectedSchema}
              onChange={(e) => setSelectedSchema(e.target.value)}
              disabled={loading || !selectedCatalog}
            >
              <option value="">Select a Schema</option>
              {schemas.map((sch) => (
                <option key={sch} value={sch}>{sch}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="tables-select">Tables (Ctrl/Cmd + click to select multiple):</label>
            <select
              id="tables-select"
              multiple
              value={selectedTables}
              onChange={(e) =>
                setSelectedTables(
                  Array.from(e.target.selectedOptions, (option) => option.value)
                )
              }
              disabled={loading || !selectedSchema}
            >
              {tables.map((tbl) => (
                <option key={tbl} value={tbl}>{tbl}</option>
              ))}
            </select>
          </div>
          <button onClick={handleAnalyze} disabled={loading || selectedTables.length === 0} className="btn analyze-btn">
            Run Analysis
          </button>
        </div>
        <div className="main-content">
          <h2>Analysis Report</h2>
          <div className="analysis-report">
            {analysisReport ? (
              <div
                className="compliance-report"
                dangerouslySetInnerHTML={{ __html: analysisReport }}
              />
            ) : (
              <p>Select tables and run analysis to see the report.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
