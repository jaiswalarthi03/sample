import requests
import json
import os
import sys
import dash
from dash import html, dcc, Input, Output, State
import dash_bootstrap_components as dbc
from llm_api import validate_schema

# Databricks connection parameters
server_hostname = "dbc-6ca44baf-5e80.cloud.databricks.com"
personal_access_token = "dapi197c341dbc1155fb0d31f2c9644a50ef"
warehouse_id = "ca34798d4f948cfd"

# API endpoint for SQL queries
api_url = f"https://{server_hostname}/api/2.0/sql/statements"

# Headers for authentication
headers = {
    "Authorization": f"Bearer {personal_access_token}",
    "Content-Type": "application/json"
}

# Initialize the Dash app with Bootstrap for styling
app = dash.Dash(__name__, 
                external_stylesheets=[dbc.themes.BOOTSTRAP],
                suppress_callback_exceptions=True,
                prevent_initial_callbacks=True,
                update_title=None,  # Prevents the 'Updating...' browser title
                meta_tags=[{'name': 'viewport', 'content': 'width=device-width, initial-scale=1'}])

# Custom CSS for the app
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>Databricks Geospatial Schema Validator</title>
        {%favicon%}
        {%css%}
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
            
            :root {
                --primary-color: #dc3545;
                --secondary-color: #212529;
                --accent-color: #f8f9fa;
                --border-radius: 8px;
                --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                --transition: all 0.3s ease;
            }
            
            body {
                font-family: 'Poppins', sans-serif;
                background-color: white;
                margin: 0;
                padding: 0;
                color: var(--secondary-color);
            }
            
            .header {
                background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
                border-bottom: 3px solid var(--primary-color);
                padding: 1.5rem;
                margin-bottom: 2rem;
                box-shadow: var(--box-shadow);
                display: flex;
                align-items: center;
                justify-content: space-between;
            }
            
            .logo-container {
                display: flex;
                align-items: center;
                gap: 15px;
            }
            
            .logo {
                max-height: 50px;
                transition: var(--transition);
            }
            
            .logo:hover {
                transform: scale(1.05);
            }
            
            .content {
                padding: 0 2rem 2rem 2rem;
                max-width: 1400px;
                margin: 0 auto;
            }
            
            .card {
                border-radius: var(--border-radius);
                box-shadow: var(--box-shadow);
                transition: var(--transition);
                border: none;
                overflow: hidden;
            }
            
            .card:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            }
            
            .card-header {
                background-color: var(--primary-color);
                color: white;
                font-weight: 600;
                padding: 1rem;
            }
            
            .result-container {
                border-radius: var(--border-radius);
                padding: 0;
                margin-top: 1rem;
                background-color: white;
                box-shadow: var(--box-shadow);
                height: 800px;
                position: relative;
            }
            
            .result-container iframe {
                border-radius: var(--border-radius);
            }
            
            /* Custom scrollbar */
            .result-container::-webkit-scrollbar {
                width: 8px;
            }
            
            .result-container::-webkit-scrollbar-track {
                background: #f1f1f1;
                border-radius: 10px;
            }
            
            .result-container::-webkit-scrollbar-thumb {
                background: var(--primary-color);
                border-radius: 10px;
            }
            
            .result-container::-webkit-scrollbar-thumb:hover {
                background: #b30000;
            }
            
            h1, h2, h3 {
                font-weight: 600;
                color: var(--secondary-color);
            }
            
            .btn-primary {
                background-color: var(--primary-color);
                border-color: var(--primary-color);
                border-radius: var(--border-radius);
                padding: 0.5rem 1.5rem;
                font-weight: 500;
                transition: var(--transition);
                box-shadow: 0 2px 4px rgba(220, 53, 69, 0.3);
            }
            
            .btn-primary:hover {
                background-color: #c82333;
                border-color: #bd2130;
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(220, 53, 69, 0.4);
            }
            
            /* Custom loading spinner styling */
            .loading-spinner {
                margin: 1rem 0;
                text-align: center;
            }
            
            /* Override Dash's default spinner */
            ._dash-loading {
                margin: 0 !important;
                position: relative !important;
            }
            
            ._dash-loading-callback {
                border: 3px solid rgba(220, 53, 69, 0.2) !important;
                border-top: 3px solid var(--primary-color) !important;
                border-radius: 50% !important;
                width: 40px !important;
                height: 40px !important;
                animation: spinner 1s linear infinite !important;
                margin: 1rem auto !important;
            }
            
            @keyframes spinner {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            
            .dropdown {
                border-radius: var(--border-radius);
            }
            
            /* Animation effects */
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .animate-fade-in {
                animation: fadeIn 0.5s ease forwards;
            }
            
            /* Logo upload button styling */
            .logo-upload {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .logo-upload-btn {
                background-color: transparent;
                color: var(--primary-color);
                border: 1px dashed var(--primary-color);
                border-radius: var(--border-radius);
                padding: 0.3rem 0.8rem;
                font-size: 0.8rem;
                cursor: pointer;
                transition: var(--transition);
            }
            
            .logo-upload-btn:hover {
                background-color: rgba(220, 53, 69, 0.1);
            }
            
            /* Custom iframe styling */
            .custom-iframe {
                width: 100%;
                height: 100%;
                border: none;
                border-radius: var(--border-radius);
            }
            
            /* Add a red vertical scrollbar to the iframe */
            .iframe-container {
                position: relative;
                height: 100%;
                overflow: hidden;
                border-radius: var(--border-radius);
            }
            
            .iframe-container::after {
                content: '';
                position: absolute;
                top: 0;
                right: 0;
                width: 8px;
                height: 100%;
                background-color: var(--primary-color);
                opacity: 0.7;
                z-index: 10;
                pointer-events: none;
            }
        </style>
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''

# Function to execute a query and get results
def execute_query(query, catalog=None, schema=None):
    payload = {
        "statement": query,
        "warehouse_id": warehouse_id
    }
    
    # Add catalog and schema if provided
    if catalog:
        payload["catalog"] = catalog
    if schema:
        payload["schema"] = schema
    
    try:
        # Send the request
        response = requests.post(api_url, headers=headers, json=payload)
        
        # Check if the request was successful
        if response.status_code == 200:
            # Get the statement ID from the response
            statement_id = response.json().get('statement_id')
            
            # Poll for results
            results_url = f"https://{server_hostname}/api/2.0/sql/statements/{statement_id}"
            
            while True:
                # Get the statement status
                status_response = requests.get(results_url, headers=headers)
                status_data = status_response.json()
                
                # Check if the query is complete
                if status_data.get('status', {}).get('state') == 'SUCCEEDED':
                    print(f"Query executed successfully: {query}")
                    # Return the results
                    if 'result' in status_data and 'data_array' in status_data['result']:
                        return status_data['result']['data_array']
                    else:
                        return []
                elif status_data.get('status', {}).get('state') == 'FAILED':
                    error_msg = status_data.get('status', {}).get('error', 'Unknown error')
                    print(f"Query failed: {error_msg}")
                    return None
                
                # Wait before polling again
                import time
                time.sleep(1)
        else:
            print(f"Request failed with status code: {response.status_code}")
            print(f"Error message: {response.text}")
            return None
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None

# Function to get tables in workspace.default schema
def get_tables():
    try:
        print("Querying for tables in workspace.default schema...")
        
        # This query will list actual tables, not the schema itself
        tables_query = """
        SELECT table_name 
        FROM workspace.information_schema.tables 
        WHERE table_schema = 'default' 
        AND table_catalog = 'workspace'
        """
        
        tables_result = execute_query(tables_query)
        
        if tables_result and len(tables_result) > 0:
            tables = [table[0] for table in tables_result]
            return tables
        else:
            # Fallback to the original SHOW TABLES command
            print("Information schema query failed, trying SHOW TABLES...")
            tables = execute_query("SHOW TABLES IN workspace.default")
            
            if tables and len(tables) > 0:
                # Filter out entries that might be schema names rather than table names
                actual_tables = []
                for table in tables:
                    table_name = table[0]
                    if table_name != 'default':  # Skip the schema name itself
                        actual_tables.append(table_name)
                
                return actual_tables
            else:
                # Try a direct query for known tables
                known_tables = ["simple_geospatial_table", "advanced_geospatial_table", "biofuel_production"]
                existing_tables = []
                
                for table_name in known_tables:
                    sample_query = f"SELECT * FROM workspace.default.{table_name} LIMIT 1"
                    sample_data = execute_query(sample_query)
                    
                    if sample_data is not None:
                        existing_tables.append(table_name)
                
                return existing_tables
    except Exception as e:
        print(f"Error getting tables: {str(e)}")
        return []

# Function to extract table metadata
def extract_table_metadata(table_name):
    try:
        # Get table schema
        schema_query = f"DESCRIBE TABLE workspace.default.{table_name}"
        schema = execute_query(schema_query)
        
        if not schema or len(schema) == 0:
            return None
        
        # Get sample data
        sample_query = f"SELECT * FROM workspace.default.{table_name} LIMIT 5"
        sample_data = execute_query(sample_query)
        
        # Format column information
        columns = []
        for column in schema:
            col_name = column[0] if len(column) > 0 else ""
            data_type = column[1] if len(column) > 1 else ""
            comment = column[2] if len(column) > 2 else ""
            
            columns.append({
                "name": col_name,
                "data_type": data_type,
                "comment": comment
            })
        
        # Format sample data
        samples = []
        if sample_data and len(sample_data) > 0:
            column_names = [col["name"] for col in columns]
            
            for row in sample_data:
                row_dict = {}
                for i, col_name in enumerate(column_names):
                    if i < len(row):
                        row_dict[col_name] = str(row[i]) if row[i] is not None else "NULL"
                samples.append(row_dict)
        
        # Create metadata object
        metadata = {
            "table_name": table_name,
            "schema": "workspace.default",
            "columns": columns,
            "sample_data": samples
        }
        
        return metadata
    
    except Exception as e:
        print(f"Error extracting metadata: {str(e)}")
        return None

# Define the app layout
def create_layout():
    return html.Div([
        # Header
        html.Div([
            # Logo and title container
            html.Div([
                html.Div([
                    html.Img(id="logo-image", className="logo", style={'display': 'none'}),
                    html.H1("Databricks Geospatial Schema Validator", className="m-0")
                ], className="logo-container"),
                
                # Logo upload button
                html.Div([
                    dcc.Upload(
                        id='logo-upload',
                        children=html.Button('Add Logo', className='logo-upload-btn'),
                        multiple=False
                    ),
                ], className="logo-upload")
            ], className="d-flex justify-content-between align-items-center w-100")
        ], className="header"),
        
        # Main content
        html.Div([
            # Table selection section
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H3("Select a Table", className="card-header", style={'fontSize': '1.2rem'}),
                        html.Div([
                            html.P("Choose a table from your Databricks workspace to validate its geospatial schema."),
                            dbc.Button("Load Tables", id="load-tables-button", color="primary", className="mb-3 mt-3"),
                            dcc.Loading(
                                id="loading-tables",
                                type="default",
                                color="#dc3545",
                                fullscreen=False,
                                className="loading-spinner",
                                children=[
                                    dcc.Dropdown(
                                        id="table-dropdown",
                                        options=[],
                                        placeholder="Select a table...",
                                        className="mb-3"
                                    )
                                ]
                            ),
                            dbc.Button("Validate Schema", id="validate-button", color="primary", disabled=True),
                        ], className="card-body")
                    ], className="card animate-fade-in")
                ], md=3),
                
                # Results section
                dbc.Col([
                    html.Div([
                        html.H3("Validation Results", className="card-header", style={'fontSize': '1.2rem'}),
                        html.Div([
                            dcc.Loading(
                                id="loading-results",
                                type="default",
                                color="#dc3545",
                                fullscreen=False,
                                className="loading-spinner",
                                children=[
                                    html.Div(id="validation-results", className="iframe-container")
                                ]
                            )
                        ], className="card-body p-0")
                    ], className="card animate-fade-in")
                ], md=6),
                
                # ADW Capabilities section (placeholder for future content)
                dbc.Col([
                    html.Div([
                        html.H3("ADW Capabilities", className="card-header", style={'fontSize': '1.2rem'}),
                        html.Div([
                            html.P("This section will display ADW capabilities in the future.", className="text-muted"),
                            html.Div(id="adw-capabilities-content", className="p-3")
                        ], className="card-body")
                    ], className="card animate-fade-in")
                ], md=3)
            ])
        ], className="content")
    ])

# Set the app layout
app.layout = create_layout()

# Callback to load tables
@app.callback(
    [Output("table-dropdown", "options"),
     Output("table-dropdown", "value"),
     Output("validate-button", "disabled")],
    [Input("load-tables-button", "n_clicks")],
    prevent_initial_call=True
)
def load_tables_callback(n_clicks):
    if n_clicks is None:
        return [], None, True
    
    try:
        tables = get_tables()
        if not tables or len(tables) == 0:
            return [], None, True
        
        options = [{'label': table, 'value': table} for table in tables]
        return options, None, True
    except Exception as e:
        print(f"Error loading tables: {str(e)}")
        return [], None, True

# Callback to update the validate button state when a table is selected
@app.callback(
    Output("validate-button", "disabled", allow_duplicate=True),
    [Input("table-dropdown", "value")],
    prevent_initial_call=True
)
def update_validate_button(selected_table):
    return selected_table is None

# Callback to validate the schema
@app.callback(
    [Output("validation-results", "children"),
     Output("adw-capabilities-content", "children")],
    [Input("validate-button", "n_clicks")],
    [State("table-dropdown", "value")],
    prevent_initial_call=True
)
def validate_schema_callback(n_clicks, selected_table):
    if n_clicks is None or selected_table is None:
        return html.P("Select a table and click 'Validate Schema' to see results."), \
               html.P("ADW capabilities will appear here after validation.", className="text-muted")
    
    try:
        # Extract table metadata
        metadata = extract_table_metadata(selected_table)
        
        if not metadata:
            return html.P(f"Could not extract metadata for table {selected_table}."), \
                   html.P("No ADW capabilities available.", className="text-muted")
        
        # Convert metadata to JSON string
        metadata_json = json.dumps(metadata, indent=2)
        
        # Validate schema using Gemini LLM with HTML output
        result = validate_schema(metadata_json, html_output=True)
        
        # Extract ADW capabilities mention from the result
        adw_capabilities = html.Div([
            html.P("This section will be populated with ADW capabilities in the future.", className="text-muted"),
            html.Hr(),
            html.P("The LLM has been instructed to mention ADW capabilities in its response.", className="fst-italic")
        ])
        
        # Return the HTML result directly
        return html.Iframe(
            srcDoc=result,
            style={
                'width': '100%',
                'height': '800px',
                'border': 'none'
            },
            className="custom-iframe"
        ), adw_capabilities
    except Exception as e:
        error_div = html.Div([
            html.H4("Error", className="text-danger"),
            html.P(f"An error occurred: {str(e)}")
        ])
        return error_div, html.P("No ADW capabilities available due to error.", className="text-danger")

# Callback for logo upload
@app.callback(
    [Output("logo-image", "src"),
     Output("logo-image", "style")],
    Input("logo-upload", "contents"),
    State("logo-upload", "filename"),
    prevent_initial_call=True
)
def update_logo(contents, filename):
    if contents is None:
        return None, {'display': 'none'}
    
    # Check if the file is an image
    if not any(ext in filename.lower() for ext in ['.png', '.jpg', '.jpeg', '.svg', '.gif']):
        return None, {'display': 'none'}
    
    # Return the image content and update style to display it
    return contents, {'display': 'block', 'max-height': '50px'}

# Run the app
if __name__ == "__main__":
    app.run_server(debug=True)