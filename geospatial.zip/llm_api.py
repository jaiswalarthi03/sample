import os
import json
import requests

# Default Gemini API settings
DEFAULT_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

def load_api_key():
    """Load the Gemini API key from file or environment variable"""
    try:
        # First try to load from file
        key_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "gemini_api_key.txt")
        if os.path.exists(key_file_path):
            with open(key_file_path, "r") as f:
                api_key = f.read().strip()
                if api_key:
                    return api_key
        
        # If file doesn't exist or is empty, try environment variable
        api_key = os.environ.get("GEMINI_API_KEY")
        if api_key:
            return api_key
            
        # If neither exists, raise an error
        raise ValueError("Gemini API key not found. Please create a gemini_api_key.txt file or set GEMINI_API_KEY environment variable.")
    except Exception as e:
        print(f"Error loading API key: {str(e)}")
        return None

def load_custom_prompt():
    """Load the custom prompt template from file"""
    try:
        prompt_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "custom_prompt.txt")
        if os.path.exists(prompt_file_path):
            with open(prompt_file_path, "r") as f:
                return f.read()
        return None
    except Exception as e:
        print(f"Error loading custom prompt: {str(e)}")
        return None

def validate_schema(metadata_json, custom_prompt=None, html_output=False):
    """Validate a table schema for geospatial compliance using Gemini LLM"""
    try:
        # Format the metadata as a string if it's a dictionary
        if isinstance(metadata_json, dict):
            metadata_str = json.dumps(metadata_json, indent=2)
        else:
            metadata_str = metadata_json
            
        # Load the custom prompt or use a default one
        prompt_template = custom_prompt if custom_prompt else load_custom_prompt()
        
        if not prompt_template:
            # Default prompt if custom prompt is not available
            prompt_template = """
            You are a geospatial data expert. Analyze this Databricks table schema and evaluate 
            if it's well-designed for geospatial analysis. The table metadata is provided as JSON.
            
            Table Metadata:
            {metadata_json}
            
            Provide a detailed assessment covering:
            1. Coordinate columns (latitude/longitude)
            2. Geometry column presence and format (WKT, WKB, GeoJSON)
            3. Naming conventions
            4. Spatial indexing (H3, WebMercator)
            5. Spatial reference (SRID)
            
            Score the schema from 1-10 for geospatial analysis suitability.
            Format your response in markdown with clear sections and recommendations.
            Include specific examples of how to improve the schema if needed.
            """
        
        # Modify the prompt to request HTML output if needed
        if html_output:
            prompt_template += """
            
            IMPORTANT: Format your entire response as clean, well-structured HTML that can be directly displayed in a web browser.
            Use appropriate HTML tags (<h1>, <h2>, <p>, <ul>, <li>, etc.) for formatting.
            Use a clean, professional design with minimal styling.
            Use white background with traces of red and black for styling elements.
            Make sure the HTML is valid and properly formatted.
            """
        
        # Replace the placeholder with the actual metadata
        prompt = prompt_template.replace("{metadata_json}", metadata_str)
        
        # Call the Gemini API
        response = call_gemini_api(prompt)
        return response
    
    except Exception as e:
        return f"Error validating schema: {str(e)}"

def call_gemini_api(prompt, api_url=None):
    """Call the Gemini API with the given prompt"""
    try:
        api_key = load_api_key()
        if not api_key:
            return "Error: Unable to load API key"
            
        # Use the provided API URL or the default
        url = api_url if api_url else DEFAULT_API_URL
        
        # Add the API key as a query parameter
        url = f"{url}?key={api_key}"
        
        # Prepare the request payload
        payload = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt}
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "topK": 40,
                "topP": 0.95,
                "maxOutputTokens": 8192,
            }
        }
        
        # Make the API request
        response = requests.post(url, json=payload)
        
        # Check if the request was successful
        if response.status_code == 200:
            response_json = response.json()
            
            # Extract the generated text from the response
            if 'candidates' in response_json and len(response_json['candidates']) > 0:
                candidate = response_json['candidates'][0]
                if 'content' in candidate and 'parts' in candidate['content']:
                    parts = candidate['content']['parts']
                    if len(parts) > 0 and 'text' in parts[0]:
                        # Get the raw text
                        text = parts[0]['text']
                        
                        # Clean up the response by removing markdown code blocks if present
                        # This handles both ```html and ``` at the beginning and end
                        if text.startswith('```'):
                            # Find the first newline to skip the language identifier line
                            first_newline = text.find('\n')
                            if first_newline != -1:
                                text = text[first_newline + 1:]
                            
                            # Remove the closing code block
                            if text.endswith('```'):
                                text = text[:-3].strip()
                        
                        return text
            
            # If we couldn't extract the text, return the raw response
            return f"Unexpected response format: {json.dumps(response_json)}"
        else:
            return f"API request failed with status code {response.status_code}: {response.text}"
    
    except Exception as e:
        return f"Error calling Gemini API: {str(e)}"