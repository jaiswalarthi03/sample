# Databricks Geospatial Schema Validator

A tool for validating and analyzing Databricks table schemas for geospatial compliance using the Gemini LLM API.

## Features

- Lists tables in the workspace.default schema
- Extracts table metadata (columns, data types, sample data)
- Validates schemas for geospatial analysis suitability
- Provides detailed recommendations for improvement
- Scores schemas on a scale of 1-10 for geospatial compliance

## File Structure

- `code.py` - Main script for connecting to Databricks and validating schemas
- `llm_api.py` - Module for interacting with the Gemini LLM API
- `custom_prompt.txt` - Customizable prompt template for schema validation
- `gemini_api_key.txt` - File to store your Gemini API key

## Prerequisites

- Python 3.6+
- Databricks workspace with SQL warehouse
- Gemini API key

## Installation

1. Clone or download this repository
2. Install required dependencies:
   ```
   pip install requests
   ```
3. Add your Gemini API key to `gemini_api_key.txt` or set it as an environment variable:
   ```
   # On Windows
   set GEMINI_API_KEY=your_api_key_here
   
   # On Linux/Mac
   export GEMINI_API_KEY=your_api_key_here
   ```

## Usage

1. Run the script:
   ```
   python code.py
   ```
2. Select a table from the list to validate
3. Review the detailed geospatial validation results

## Customizing the LLM Integration

### Changing the Prompt

Edit the `custom_prompt.txt` file to modify the validation criteria or response format. The prompt should include the `{metadata_json}` placeholder where the table metadata will be inserted.

### Changing the API Key

Replace the contents of `gemini_api_key.txt` with your new API key, or set the `GEMINI_API_KEY` environment variable.

### Using a Different LLM

To use a different LLM service, modify the `llm_api.py` file to implement the new API integration. The main interface function `validate_schema(metadata_json, custom_prompt=None)` should remain the same to maintain compatibility with `code.py`.

## License

This project is licensed under the MIT License - see the LICENSE file for details.