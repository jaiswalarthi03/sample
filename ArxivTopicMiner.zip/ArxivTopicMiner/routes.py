import logging
from datetime import datetime, timedelta
from flask import render_template, request, jsonify, flash, redirect, url_for
from app import app, db
from models import Paper, Term, Topic, ProcessingSession
from services.arxiv_service import ArxivService
from services.clustering_service import ClusteringService

logger = logging.getLogger(__name__)

# Initialize services
arxiv_service = ArxivService()
clustering_service = ClusteringService()

@app.route('/')
def index():
    """
    Main search page
    """
    categories = arxiv_service.get_popular_categories()
    return render_template('index.html', categories=categories)

@app.route('/search', methods=['POST'])
def search_papers():
    """
    Search arXiv papers based on user input
    """
    try:
        # Get search parameters
        query = request.form.get('query', '').strip()
        max_results = int(request.form.get('max_results', 20))
        start_date_str = request.form.get('start_date')
        end_date_str = request.form.get('end_date')
        selected_categories = request.form.getlist('categories')
        
        if not query:
            flash('Please enter a search query', 'error')
            return redirect(url_for('index'))
        
        # Parse dates
        start_date = None
        end_date = None
        
        if start_date_str:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
        
        if end_date_str:
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
        
        logger.info(f"Searching for: {query}, max_results: {max_results}")
        
        # Search papers
        papers_data = arxiv_service.search_papers(
            query=query,
            max_results=max_results,
            start_date=start_date,
            end_date=end_date,
            categories=selected_categories if selected_categories else None
        )
        
        if not papers_data:
            flash('No papers found for your search criteria', 'warning')
            return redirect(url_for('index'))
        
        # Store papers in database
        stored_papers = []
        for paper_data in papers_data:
            # Check if paper already exists
            existing_paper = Paper.query.filter_by(arxiv_id=paper_data['arxiv_id']).first()
            
            if not existing_paper:
                paper = Paper(
                    arxiv_id=paper_data['arxiv_id'],
                    title=paper_data['title'],
                    summary=paper_data['summary'],
                    authors=paper_data['authors'],
                    published_date=paper_data['published_date'],
                    categories=paper_data['categories'],
                    pdf_url=paper_data['pdf_url']
                )
                db.session.add(paper)
                db.session.flush()
                stored_papers.append(paper)
            else:
                stored_papers.append(existing_paper)
        
        db.session.commit()
        
        # Create processing session
        session = ProcessingSession(
            search_query=query,
            papers_count=len(stored_papers)
        )
        db.session.add(session)
        db.session.commit()
        
        flash(f'Found {len(papers_data)} papers', 'success')
        
        return render_template('index.html', 
                             papers=stored_papers, 
                             session_id=session.id,
                             search_query=query,
                             categories=arxiv_service.get_popular_categories())
        
    except Exception as e:
        logger.error(f"Error searching papers: {str(e)}")
        flash(f'Error searching papers: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/process', methods=['POST'])
def process_papers():
    """
    Process selected papers to extract jargon and create clusters
    """
    try:
        paper_ids = request.form.getlist('paper_ids')
        session_id = request.form.get('session_id')
        
        if not paper_ids:
            return jsonify({'error': 'No papers selected'}), 400
        
        if not session_id:
            return jsonify({'error': 'No session ID provided'}), 400
        
        # Convert to integers
        paper_ids = [int(pid) for pid in paper_ids]
        session_id = int(session_id)
        
        logger.info(f"Processing {len(paper_ids)} papers for session {session_id}")
        
        # Start processing (this could be moved to a background task for better UX)
        results = clustering_service.process_papers(paper_ids, session_id)
        
        return jsonify({
            'success': True,
            'message': f'Successfully processed {len(paper_ids)} papers',
            'results': results
        })
        
    except Exception as e:
        logger.error(f"Error processing papers: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/dashboard')
def dashboard():
    """
    Display visualization dashboard
    """
    try:
        data = clustering_service.get_dashboard_data()
        return render_template('dashboard.html', data=data)
        
    except Exception as e:
        logger.error(f"Error loading dashboard: {str(e)}")
        flash(f'Error loading dashboard: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/api/processing-status/<int:session_id>')
def get_processing_status(session_id):
    """
    Get the status of a processing session
    """
    try:
        session = ProcessingSession.query.get(session_id)
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        
        return jsonify({
            'status': session.status,
            'terms_extracted': session.terms_extracted,
            'topics_created': session.topics_created,
            'error_message': session.error_message
        })
        
    except Exception as e:
        logger.error(f"Error getting processing status: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/topics')
def get_topics():
    """
    Get all topics with their terms for API access
    """
    try:
        data = clustering_service.get_dashboard_data()
        return jsonify(data)
        
    except Exception as e:
        logger.error(f"Error getting topics: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/topics/<int:topic_id>', methods=['DELETE'])
def delete_topic(topic_id):
    """
    Delete a topic cluster
    """
    try:
        success = clustering_service.delete_topic(topic_id)
        if success:
            return jsonify({'success': True, 'message': 'Topic deleted successfully'})
        else:
            return jsonify({'error': 'Topic not found'}), 404
            
    except Exception as e:
        logger.error(f"Error deleting topic: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found_error(error):
    return render_template('base.html', 
                         content='<div class="container"><h1>Page Not Found</h1><p>The page you are looking for does not exist.</p></div>'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('base.html', 
                         content='<div class="container"><h1>Internal Server Error</h1><p>An unexpected error occurred.</p></div>'), 500
