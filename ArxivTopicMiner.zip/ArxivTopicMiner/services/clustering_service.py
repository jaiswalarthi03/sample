import logging
import time
from typing import List, Dict, Set
from app import db
from models import Paper, Term, Topic, ProcessingSession
from services.gemini_service import GeminiService
from config import Config

logger = logging.getLogger(__name__)

class ClusteringService:
    def __init__(self):
        self.gemini_service = GeminiService()
    
    def process_papers(self, paper_ids: List[int], session_id: int) -> Dict:
        """
        Process selected papers to extract jargon and create topic clusters
        """
        try:
            session = ProcessingSession.query.get(session_id)
            if not session:
                raise Exception("Processing session not found")
            
            session.status = 'processing'
            db.session.commit()
            
            # Get papers that haven't been processed yet
            papers = Paper.query.filter(
                Paper.id.in_(paper_ids),
                Paper.processed == False
            ).all()
            
            if not papers:
                logger.info("All selected papers already processed")
                session.status = 'completed'
                db.session.commit()
                return self._get_processing_results(session_id)
            
            logger.info(f"Processing {len(papers)} unprocessed papers")
            
            # Extract jargon terms in batches
            all_terms = []
            batch_size = Config.GEMINI_BATCH_SIZE
            
            for i in range(0, len(papers), batch_size):
                batch = papers[i:i+batch_size]
                summaries = [paper.summary for paper in batch]
                
                batch_number = i//batch_size + 1
                total_batches = (len(papers)-1)//batch_size + 1
                
                logger.info(f"Processing batch {batch_number} of {total_batches} ({len(batch)} papers)")
                
                # Extract jargon terms
                extracted_terms = self.gemini_service.extract_jargon_from_summaries(summaries)
                
                # Store terms in database
                for j, paper in enumerate(batch):
                    paper_terms = self._filter_terms_for_paper(extracted_terms, j, len(batch))
                    
                    for term_data in paper_terms:
                        # Check if term already exists for this paper
                        existing_term = Term.query.filter_by(
                            text=term_data['term'],
                            paper_id=paper.id
                        ).first()
                        
                        if not existing_term:
                            new_term = Term(
                                text=term_data['term'],
                                context=term_data['context'],
                                paper_id=paper.id,
                                frequency=1
                            )
                            db.session.add(new_term)
                            all_terms.append(term_data['term'])
                        else:
                            # Increment frequency if term already exists
                            existing_term.frequency += 1
                    
                    # Mark paper as processed
                    paper.processed = True
                
                db.session.commit()
                
                # Wait between batches (except for the last batch)
                if batch_number < total_batches:
                    batch_delay = Config.GEMINI_BATCH_DELAY
                    logger.info(f"Waiting {batch_delay} seconds before next batch...")
                    time.sleep(batch_delay)
            
            # Remove duplicates and cluster terms
            unique_terms = list(set(all_terms))
            logger.info(f"Clustering {len(unique_terms)} unique terms")
            
            if unique_terms:
                clusters = self.gemini_service.cluster_terms_into_topics(unique_terms)
                
                # Create topics and assign terms
                for cluster_data in clusters:
                    # Check if topic already exists
                    existing_topic = Topic.query.filter_by(name=cluster_data['topic_name']).first()
                    
                    if not existing_topic:
                        topic = Topic(
                            name=cluster_data['topic_name'],
                            description=cluster_data['description']
                        )
                        db.session.add(topic)
                        db.session.flush()  # Get the ID
                    else:
                        topic = existing_topic
                    
                    # Assign terms to topic
                    for term_text in cluster_data['terms']:
                        terms_to_update = Term.query.filter_by(
                            text=term_text,
                            topic_id=None
                        ).all()
                        
                        for term in terms_to_update:
                            term.topic_id = topic.id
            
            # Update session
            session.terms_extracted = len(all_terms)
            session.topics_created = len(clusters) if unique_terms else 0
            session.status = 'completed'
            db.session.commit()
            
            logger.info("Processing completed successfully")
            return self._get_processing_results(session_id)
            
        except Exception as e:
            logger.error(f"Error processing papers: {str(e)}")
            session.status = 'failed'
            session.error_message = str(e)
            db.session.commit()
            raise
    
    def _filter_terms_for_paper(self, extracted_terms: List[Dict], paper_index: int, batch_size: int) -> List[Dict]:
        """
        Filter extracted terms to assign them to the correct paper
        This is a simplified approach - in practice, you might want more sophisticated mapping
        """
        # For simplicity, distribute terms evenly across papers in the batch
        terms_per_paper = len(extracted_terms) // batch_size
        start_idx = paper_index * terms_per_paper
        end_idx = start_idx + terms_per_paper if paper_index < batch_size - 1 else len(extracted_terms)
        
        return extracted_terms[start_idx:end_idx]
    
    def _get_processing_results(self, session_id: int) -> Dict:
        """
        Get results from a processing session
        """
        session = ProcessingSession.query.get(session_id)
        
        # Get topics with their terms
        topics_data = []
        topics = Topic.query.all()
        
        for topic in topics:
            terms = Term.query.filter_by(topic_id=topic.id).all()
            if terms:  # Only include topics that have terms
                topics_data.append({
                    'id': topic.id,
                    'name': topic.name,
                    'description': topic.description,
                    'terms': [{'text': term.text, 'frequency': term.frequency} for term in terms],
                    'term_count': len(terms)
                })
        
        return {
            'session': {
                'id': session.id,
                'status': session.status,
                'terms_extracted': session.terms_extracted,
                'topics_created': session.topics_created,
                'error_message': session.error_message
            },
            'topics': topics_data
        }
    
    def get_dashboard_data(self) -> Dict:
        """
        Get all data for the dashboard visualization including processed papers
        """
        # Get all topics with their terms
        topics = Topic.query.all()
        topics_data = []
        
        for topic in topics:
            terms = Term.query.filter_by(topic_id=topic.id).all()
            if terms:
                # Group terms by paper for better context
                papers_with_terms = {}
                for term in terms:
                    if term.paper_id not in papers_with_terms:
                        papers_with_terms[term.paper_id] = {
                            'paper_title': term.paper.title,
                            'paper_id': term.paper_id,
                            'arxiv_id': term.paper.arxiv_id,
                            'terms': []
                        }
                    papers_with_terms[term.paper_id]['terms'].append({
                        'text': term.text,
                        'frequency': term.frequency,
                        'context': term.context
                    })
                
                topics_data.append({
                    'id': topic.id,
                    'name': topic.name,
                    'description': topic.description,
                    'terms': [{'text': term.text, 'frequency': term.frequency, 'context': term.context} for term in terms],
                    'term_count': len(terms),
                    'papers': list(papers_with_terms.values())
                })
        
        # Get all processed papers with their processing sessions
        processed_papers = Paper.query.filter_by(processed=True).all()
        papers_data = []
        
        for paper in processed_papers:
            terms_count = Term.query.filter_by(paper_id=paper.id).count()
            papers_data.append({
                'id': paper.id,
                'arxiv_id': paper.arxiv_id,
                'title': paper.title,
                'authors': paper.authors,
                'published_date': paper.published_date.isoformat(),
                'categories': paper.categories,
                'pdf_url': paper.pdf_url,
                'terms_count': terms_count,
                'processed_at': paper.created_at.isoformat()
            })
        
        # Get processing sessions for history
        sessions = ProcessingSession.query.filter_by(status='completed').order_by(ProcessingSession.created_at.desc()).all()
        sessions_data = []
        
        for session in sessions:
            sessions_data.append({
                'id': session.id,
                'search_query': session.search_query,
                'papers_count': session.papers_count,
                'terms_extracted': session.terms_extracted,
                'topics_created': session.topics_created,
                'created_at': session.created_at.isoformat(),
                'completed_at': session.completed_at.isoformat() if session.completed_at else None
            })
        
        # Get top terms by frequency
        top_terms = Term.get_top_terms(limit=10)
        top_terms_data = [{'text': term.text, 'frequency': term.total_frequency} for term in top_terms]
        
        # Get some statistics
        total_papers = len(processed_papers)
        total_terms = Term.query.count()
        total_topics = len(topics_data)
        total_sessions = len(sessions_data)
        
        return {
            'topics': topics_data,
            'papers': papers_data,
            'sessions': sessions_data,
            'top_terms': top_terms_data,
            'statistics': {
                'total_papers': total_papers,
                'total_terms': total_terms,
                'total_topics': total_topics,
                'total_sessions': total_sessions
            }
        }
    
    def delete_topic(self, topic_id: int) -> bool:
        """
        Delete a topic and reassign its terms to null topic_id
        """
        try:
            topic = Topic.query.get(topic_id)
            if not topic:
                return False
            
            # Reassign all terms of this topic to null (unassigned)
            terms = Term.query.filter_by(topic_id=topic_id).all()
            for term in terms:
                term.topic_id = None
            
            # Delete the topic
            db.session.delete(topic)
            db.session.commit()
            
            logger.info(f"Deleted topic '{topic.name}' and unassigned {len(terms)} terms")
            return True
            
        except Exception as e:
            logger.error(f"Error deleting topic: {str(e)}")
            db.session.rollback()
            return False
