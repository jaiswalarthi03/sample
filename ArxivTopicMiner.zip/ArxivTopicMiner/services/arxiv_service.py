import arxiv
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from config import Config

logger = logging.getLogger(__name__)

class ArxivService:
    def __init__(self):
        self.client = arxiv.Client(
            page_size=50,
            delay_seconds=Config.ARXIV_DELAY_SECONDS,
            num_retries=3
        )
    
    def search_papers(self, 
                     query: str, 
                     max_results: int = 20,
                     start_date: Optional[datetime] = None,
                     end_date: Optional[datetime] = None,
                     categories: Optional[List[str]] = None) -> List[Dict]:
        """
        Search arXiv papers with given parameters
        """
        # Enforce maximum limit
        max_results = min(max_results, Config.ARXIV_MAX_RESULTS)
        
        try:
            # Build the search query
            search_query = query
            
            # Add date range if specified
            if start_date or end_date:
                date_query = self._build_date_query(start_date, end_date)
                if date_query:
                    search_query = f"({query}) AND {date_query}"
            
            # Add category filter if specified
            if categories:
                cat_query = " OR ".join([f"cat:{cat}" for cat in categories])
                search_query = f"({search_query}) AND ({cat_query})"
            
            logger.info(f"Searching arXiv with query: {search_query}")
            
            # Create search object
            search = arxiv.Search(
                query=search_query,
                max_results=min(max_results, Config.ARXIV_MAX_RESULTS),
                sort_by=arxiv.SortCriterion.SubmittedDate,
                sort_order=arxiv.SortOrder.Descending
            )
            
            # Execute search
            results = []
            for result in self.client.results(search):
                paper_data = {
                    'arxiv_id': result.entry_id.split('/')[-1],  # Extract ID from URL
                    'title': result.title,
                    'summary': result.summary,
                    'authors': ', '.join([author.name for author in result.authors]),
                    'published_date': result.published,
                    'categories': ', '.join(result.categories),
                    'pdf_url': result.pdf_url,
                    'primary_category': result.primary_category
                }
                results.append(paper_data)
            
            logger.info(f"Found {len(results)} papers")
            return results
            
        except Exception as e:
            logger.error(f"Error searching arXiv: {str(e)}")
            raise Exception(f"Failed to search arXiv: {str(e)}")
    
    def _build_date_query(self, start_date: Optional[datetime], end_date: Optional[datetime]) -> str:
        """
        Build date range query for arXiv API
        """
        date_parts = []
        
        if start_date:
            date_str = start_date.strftime("%Y%m%d")
            date_parts.append(f"submittedDate:[{date_str}0000 TO *]")
        
        if end_date:
            date_str = end_date.strftime("%Y%m%d")
            date_parts.append(f"submittedDate:[* TO {date_str}2359]")
        
        return " AND ".join(date_parts)
    
    def get_popular_categories(self) -> List[Dict[str, str]]:
        """
        Return list of popular arXiv categories
        """
        return [
            {'id': 'cs.AI', 'name': 'Artificial Intelligence'},
            {'id': 'cs.LG', 'name': 'Machine Learning'},
            {'id': 'cs.CL', 'name': 'Computation and Language'},
            {'id': 'cs.CV', 'name': 'Computer Vision'},
            {'id': 'cs.CR', 'name': 'Cryptography and Security'},
            {'id': 'stat.ML', 'name': 'Machine Learning (Statistics)'},
            {'id': 'math.ST', 'name': 'Statistics Theory'},
            {'id': 'physics.data-an', 'name': 'Data Analysis'},
            {'id': 'q-bio.QM', 'name': 'Quantitative Methods'},
            {'id': 'econ.EM', 'name': 'Econometrics'}
        ]
