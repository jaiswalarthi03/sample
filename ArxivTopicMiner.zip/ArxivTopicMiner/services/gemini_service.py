import json
import logging
import os
import time
from typing import List, Dict, Tuple
from google import genai
from google.genai import types
from pydantic import BaseModel
from config import Config

logger = logging.getLogger(__name__)

class JargonTerm(BaseModel):
    term: str
    context: str
    confidence: float

class JargonExtraction(BaseModel):
    terms: List[JargonTerm]

class TopicCluster(BaseModel):
    topic_name: str
    description: str
    terms: List[str]

class ClusteringResult(BaseModel):
    clusters: List[TopicCluster]

class GeminiService:
    def __init__(self):
        # Use environment variable first, fallback to config
        api_key = os.environ.get('GEMINI_API_KEY') or Config.GEMINI_API_KEY
        if not api_key:
            raise ValueError("GEMINI_API_KEY not found in environment variables or config")
        
        self.client = genai.Client(api_key=api_key)
        self.last_request_time = 0
        self.request_count = 0
        self.rate_limit_window = 60  # 1 minute
        self.timeout = Config.GEMINI_REQUEST_TIMEOUT
    
    def _wait_for_rate_limit(self):
        """
        Implement rate limiting to respect Gemini API limits
        Free tier: 10 requests per minute for Flash model
        """
        current_time = time.time()
        
        # Reset counter if window has passed
        if current_time - self.last_request_time > self.rate_limit_window:
            self.request_count = 0
            self.last_request_time = current_time
        
        # Check if we need to wait
        if self.request_count >= Config.GEMINI_RATE_LIMIT_RPM:
            wait_time = self.rate_limit_window - (current_time - self.last_request_time)
            if wait_time > 0:
                logger.info(f"Rate limit reached ({self.request_count}/{Config.GEMINI_RATE_LIMIT_RPM}), waiting {wait_time:.2f} seconds")
                time.sleep(wait_time + 1)  # Add 1 second buffer
                self.request_count = 0
                self.last_request_time = time.time()
        
        self.request_count += 1
        logger.debug(f"Making request {self.request_count}/{Config.GEMINI_RATE_LIMIT_RPM}")
    
    def extract_jargon_from_summaries(self, summaries: List[str]) -> List[Dict]:
        """
        Extract jargon terms from a batch of paper summaries
        """
        try:
            self._wait_for_rate_limit()
            
            # Combine summaries for batch processing
            combined_text = "\n\n---PAPER SEPARATOR---\n\n".join(summaries)
            
            system_prompt = """You are an expert academic researcher specializing in identifying complex technical jargon.

Your task is to extract technical jargon terms from academic paper summaries. Focus on:
1. Complex technical terms that would be difficult for non-experts to understand
2. Terms that are 1-4 words long
3. Domain-specific terminology, algorithms, methodologies, and technical concepts
4. Avoid common words, general terms, or widely understood concepts

For each term you extract:
- Provide the exact term as it appears
- Include surrounding context (1-2 sentences)
- Rate your confidence (0.0 to 1.0) in the term being genuine jargon

Extract terms from each paper summary section separately. Look for terms like:
- Novel algorithms or methods
- Technical abbreviations and acronyms
- Specialized mathematical concepts
- Domain-specific processes or phenomena
- Advanced technical terminology

Return your findings in the specified JSON format."""

            user_prompt = f"""Extract jargon terms from these academic paper summaries:

{combined_text}

Identify 5-15 jargon terms per summary that would be difficult for general audiences to understand."""

            # Enhanced error handling for API response
            response = self.client.models.generate_content(
                model="gemini-2.5-flash",
                contents=[
                    types.Content(role="user", parts=[types.Part(text=user_prompt)])
                ],
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    response_mime_type="application/json",
                    response_schema=JargonExtraction,
                    temperature=0.1,  # Lower temperature for more consistent JSON
                ),
            )

            if not response or not response.text:
                logger.warning("Empty response from Gemini API")
                return []

            # Clean the response text before parsing
            response_text = response.text.strip()
            
            # Check if response starts with HTML (error case)
            if response_text.startswith('<'):
                logger.error(f"Received HTML error response: {response_text[:200]}...")
                raise Exception("API returned HTML error instead of JSON. Check API key and quota.")
            
            try:
                data = json.loads(response_text)
                extraction = JargonExtraction(**data)
                logger.info(f"Extracted {len(extraction.terms)} jargon terms")
                return [term.dict() for term in extraction.terms]
            except json.JSONDecodeError as je:
                logger.error(f"JSON decode error: {je}")
                logger.error(f"Response text: {response_text[:500]}...")
                raise Exception(f"Invalid JSON response from API: {str(je)}")

        except Exception as e:
            logger.error(f"Error extracting jargon: {str(e)}")
            # Don't re-raise as Exception, let the original error bubble up
            raise
    
    def cluster_terms_into_topics(self, terms: List[str]) -> List[Dict]:
        """
        Cluster extracted terms into meaningful topics
        """
        try:
            self._wait_for_rate_limit()
            
            if not terms:
                return []
            
            terms_text = "\n".join([f"- {term}" for term in terms])
            
            system_prompt = """You are an expert in academic research organization and topic modeling.

Your task is to analyze a list of technical jargon terms and group them into coherent, meaningful topics or research themes.

Guidelines:
1. Create 3-8 topic clusters (depending on the diversity of terms)
2. Each cluster should represent a distinct research area or technical domain
3. Provide a clear, descriptive name for each topic
4. Include a brief description explaining what the topic encompasses
5. Assign each term to the most appropriate cluster
6. If a term doesn't fit well anywhere, create a "Miscellaneous" or "Cross-disciplinary" cluster

Consider these common academic domains when clustering:
- Machine Learning/AI methodologies
- Data processing and analysis
- Mathematical/Statistical methods  
- Domain-specific applications
- Technical frameworks and architectures
- Evaluation and metrics
- Theoretical concepts

Ensure clusters are balanced and meaningful for academic research purposes."""

            user_prompt = f"""Cluster these technical jargon terms into meaningful research topics:

{terms_text}

Create coherent topic clusters that would help researchers understand the main themes and areas covered by these terms."""

            # Enhanced error handling for clustering
            response = self.client.models.generate_content(
                model="gemini-2.5-flash",
                contents=[
                    types.Content(role="user", parts=[types.Part(text=user_prompt)])
                ],
                config=types.GenerateContentConfig(
                    system_instruction=system_prompt,
                    response_mime_type="application/json",
                    response_schema=ClusteringResult,
                    temperature=0.1,  # Lower temperature for more consistent JSON
                ),
            )

            if not response or not response.text:
                logger.warning("Empty response from clustering")
                return []

            # Clean the response text before parsing
            response_text = response.text.strip()
            
            # Check if response starts with HTML (error case)
            if response_text.startswith('<'):
                logger.error(f"Received HTML error response: {response_text[:200]}...")
                raise Exception("API returned HTML error instead of JSON. Check API key and quota.")
            
            try:
                data = json.loads(response_text)
                clustering = ClusteringResult(**data)
                logger.info(f"Created {len(clustering.clusters)} topic clusters")
                return [cluster.dict() for cluster in clustering.clusters]
            except json.JSONDecodeError as je:
                logger.error(f"JSON decode error: {je}")
                logger.error(f"Response text: {response_text[:500]}...")
                raise Exception(f"Invalid JSON response from API: {str(je)}")

        except Exception as e:
            logger.error(f"Error clustering terms: {str(e)}")
            # Don't re-raise as Exception, let the original error bubble up
            raise
