import os

class Config:
    # Gemini API configuration - Use environment variable first
    GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', "AIzaSyAWDx1A5G1EUVxm6sz8fegm20lFujTlZzE")
    
    # Database configuration
    DATABASE_URL = os.environ.get('DATABASE_URL', 'sqlite:///arxiv_jargon.db')
    
    # Session configuration
    SECRET_KEY = os.environ.get('SESSION_SECRET', 'dev-secret-key-change-in-production')
    
    # Rate limiting configuration for Gemini Free Tier
    # Free tier limits: 10 requests per minute for Flash model
    GEMINI_RATE_LIMIT_RPM = 8  # Conservative limit to avoid hitting rate limits
    GEMINI_BATCH_SIZE = 5  # Process 5 papers at a time for better efficiency
    GEMINI_BATCH_DELAY = 20  # Wait 20 seconds between batches
    GEMINI_REQUEST_TIMEOUT = 30  # Timeout for API requests
    
    # arXiv configuration
    ARXIV_MAX_RESULTS = 20  # Limit to maximum 20 papers
    ARXIV_DELAY_SECONDS = 1  # Delay between arXiv requests
