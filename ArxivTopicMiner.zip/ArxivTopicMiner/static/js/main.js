// Main JavaScript file for arXiv Jargon Extractor

// Global variables
let processingInterval;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeFeatherIcons();
    initializeTooltips();
    setupDateValidation();
});

function initializeFeatherIcons() {
    // Replace feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
}

function initializeTooltips() {
    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

function setupDateValidation() {
    const startDateInput = document.getElementById('start_date');
    const endDateInput = document.getElementById('end_date');
    
    if (startDateInput && endDateInput) {
        startDateInput.addEventListener('change', function() {
            if (this.value && endDateInput.value) {
                if (new Date(this.value) > new Date(endDateInput.value)) {
                    alert('Start date cannot be after end date');
                    this.value = '';
                }
            }
        });
        
        endDateInput.addEventListener('change', function() {
            if (this.value && startDateInput.value) {
                if (new Date(this.value) < new Date(startDateInput.value)) {
                    alert('End date cannot be before start date');
                    this.value = '';
                }
            }
        });
    }
}

// Processing status functions
function checkProcessingStatus(sessionId) {
    fetch(`/api/processing-status/${sessionId}`)
        .then(response => response.json())
        .then(data => {
            updateProcessingUI(data);
            
            if (data.status === 'processing') {
                // Continue checking
                setTimeout(() => checkProcessingStatus(sessionId), 2000);
            } else if (data.status === 'completed') {
                showProcessingComplete();
            } else if (data.status === 'failed') {
                showProcessingError(data.error_message);
            }
        })
        .catch(error => {
            console.error('Error checking status:', error);
        });
}

function updateProcessingUI(data) {
    const statusElement = document.getElementById('processingStatus');
    if (statusElement) {
        let message = 'Processing papers...';
        
        if (data.terms_extracted > 0) {
            message = `Extracted ${data.terms_extracted} terms...`;
        }
        
        if (data.topics_created > 0) {
            message = `Created ${data.topics_created} topic clusters...`;
        }
        
        statusElement.textContent = message;
    }
}

function showProcessingComplete() {
    const modal = bootstrap.Modal.getInstance(document.getElementById('processingModal'));
    if (modal) {
        modal.hide();
    }
    
    // Show success message
    showAlert('Processing completed successfully! View results in the Dashboard.', 'success');
    
    // Optionally redirect to dashboard
    setTimeout(() => {
        window.location.href = '/dashboard';
    }, 2000);
}

function showProcessingError(errorMessage) {
    const modal = bootstrap.Modal.getInstance(document.getElementById('processingModal'));
    if (modal) {
        modal.hide();
    }
    
    showAlert(`Processing failed: ${errorMessage}`, 'danger');
}

// Utility functions
function showAlert(message, type = 'info') {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} alert-dismissible fade show`;
    alertContainer.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert at the top of the main container
    const main = document.querySelector('main');
    if (main) {
        main.insertBefore(alertContainer, main.firstChild);
    }
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (alertContainer.parentNode) {
            alertContainer.remove();
        }
    }, 5000);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function truncateText(text, maxLength = 100) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength).trim() + '...';
}

// Search enhancement functions
function toggleAdvancedSearch() {
    const advancedSection = document.getElementById('advancedSearch');
    if (advancedSection) {
        advancedSection.classList.toggle('d-none');
    }
}

function clearSearchForm() {
    const form = document.querySelector('form');
    if (form) {
        form.reset();
    }
}

// Export functions for dashboard
function exportTopicsAsJSON() {
    fetch('/api/topics')
        .then(response => response.json())
        .then(data => {
            const dataStr = JSON.stringify(data, null, 2);
            const dataBlob = new Blob([dataStr], {type: 'application/json'});
            
            const link = document.createElement('a');
            link.href = URL.createObjectURL(dataBlob);
            link.download = `arxiv_jargon_analysis_${new Date().toISOString().split('T')[0]}.json`;
            link.click();
        })
        .catch(error => {
            showAlert('Error exporting data: ' + error.message, 'danger');
        });
}

function exportTopicsAsCSV() {
    fetch('/api/topics')
        .then(response => response.json())
        .then(data => {
            let csv = 'Topic,Description,Term,Frequency\n';
            
            data.topics.forEach(topic => {
                topic.terms.forEach(term => {
                    csv += `"${topic.name}","${topic.description || ''}","${term.text}",${term.frequency}\n`;
                });
            });
            
            const dataBlob = new Blob([csv], {type: 'text/csv'});
            const link = document.createElement('a');
            link.href = URL.createObjectURL(dataBlob);
            link.download = `arxiv_jargon_analysis_${new Date().toISOString().split('T')[0]}.csv`;
            link.click();
        })
        .catch(error => {
            showAlert('Error exporting data: ' + error.message, 'danger');
        });
}

// Search suggestions and autocomplete
function initializeSearchSuggestions() {
    const searchInput = document.getElementById('query');
    if (!searchInput) return;
    
    const suggestions = [
        'machine learning bias detection',
        'neural network interpretability',
        'transformer architecture',
        'deep learning optimization',
        'natural language processing',
        'computer vision attention',
        'reinforcement learning algorithms',
        'graph neural networks',
        'adversarial machine learning',
        'federated learning privacy'
    ];
    
    // Simple autocomplete functionality
    searchInput.addEventListener('input', function() {
        const value = this.value.toLowerCase();
        if (value.length < 2) return;
        
        const matches = suggestions.filter(s => s.toLowerCase().includes(value));
        // You could implement a dropdown here for suggestions
    });
}

// Initialize search suggestions when page loads
document.addEventListener('DOMContentLoaded', initializeSearchSuggestions);

// Topic management functions
function deleteTopic(topicId, topicName) {
    if (confirm(`Are you sure you want to delete the topic "${topicName}"? This will remove the topic and unassign all its terms.`)) {
        fetch(`/api/topics/${topicId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove the topic card from the UI
                const topicCard = document.getElementById(`topic-card-${topicId}`);
                if (topicCard) {
                    topicCard.style.transition = 'opacity 0.3s ease-out';
                    topicCard.style.opacity = '0';
                    setTimeout(() => {
                        topicCard.remove();
                        showAlert('Topic deleted successfully', 'success');
                        // Refresh the page to show updated data
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    }, 300);
                }
            } else {
                showAlert('Error deleting topic: ' + (data.error || 'Unknown error'), 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('Error deleting topic', 'danger');
        });
    }
}
