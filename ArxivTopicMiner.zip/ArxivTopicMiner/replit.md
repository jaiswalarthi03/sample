# arXiv Jargon Extractor

## Overview

This Flask-based web application extracts and analyzes jargon terms from academic papers retrieved from arXiv using AI-powered analysis through Google's Gemini API. The system provides intelligent clustering of terms into thematic topics and presents them through an interactive web dashboard.

## System Architecture

### Frontend Architecture
- **Framework**: Flask with Jinja2 templating
- **UI Framework**: Bootstrap with dark theme optimized for Replit
- **JavaScript**: Vanilla JS with Chart.js for data visualization
- **Styling**: Custom CSS with Bootstrap overrides for enhanced UX

### Backend Architecture
- **Web Framework**: Flask (Python)
- **Database ORM**: SQLAlchemy with declarative base model
- **API Integration**: arXiv API wrapper and Google Gemini API
- **Service Layer**: Modular services for arXiv search, Gemini processing, and clustering
- **Session Management**: Flask sessions with configurable secret keys

### Database Schema
- **Papers Table**: Stores arXiv paper metadata (arxiv_id, title, summary, authors, etc.)
- **Topics Table**: Stores clustered topic information with descriptions
- **Terms Table**: Stores extracted jargon terms with frequency and context
- **Relationships**: Papers have many Terms, Topics have many Terms (many-to-many through Terms)

## Key Components

### Services Layer
1. **ArxivService**: Handles paper search and retrieval from arXiv API
   - Configurable search parameters (date ranges, categories, result limits)
   - Built-in rate limiting and retry mechanisms
   - Advanced query building with category and date filters

2. **GeminiService**: Manages AI-powered jargon extraction using Google Gemini
   - Structured output using Pydantic models for type safety
   - Rate limiting implementation for API quota management
   - Batch processing for efficient API usage

3. **ClusteringService**: Orchestrates the complete processing pipeline
   - Coordinates between arXiv search and Gemini analysis
   - Manages processing sessions and status tracking
   - Topic clustering and organization

### Web Interface
- **Search Interface**: Advanced search form with category selection and date filtering
- **Results Display**: Interactive paper selection for processing
- **Dashboard**: Visualization of extracted terms, topic clusters, and analytics
- **Processing Status**: Real-time updates during AI analysis

## Data Flow

1. **Search Phase**: User submits search query → ArxivService retrieves papers → Papers stored in database
2. **Selection Phase**: User selects papers for processing → Processing session created
3. **Analysis Phase**: Selected papers sent to GeminiService in batches → Jargon terms extracted with context
4. **Clustering Phase**: Terms grouped into thematic topics → Results stored and visualized
5. **Dashboard Phase**: Interactive visualization of topics, terms, and analytics

## External Dependencies

### APIs
- **arXiv API**: Academic paper retrieval (rate-limited, 1-second delays)
- **Google Gemini API**: AI-powered jargon extraction (10 RPM free tier limit)

### Python Libraries
- **Flask**: Web framework with SQLAlchemy integration
- **arxiv**: Official arXiv API Python wrapper
- **google.genai**: Google Gemini API client
- **Pydantic**: Data validation and structured outputs

### Frontend Dependencies
- **Bootstrap**: UI framework with dark theme
- **Chart.js**: Data visualization library
- **Feather Icons**: Icon set for UI elements

## Deployment Strategy

### Configuration Management
- Environment-based configuration with fallbacks to development defaults
- Separate configuration for API keys, database URLs, and rate limits
- Production-ready settings for session management and security

### Database Configuration
- SQLite for development (file-based database)
- PostgreSQL-ready configuration through environment variables
- Connection pooling and health checks configured
- Automatic table creation on application startup

### Scalability Considerations
- Batch processing for API efficiency
- Rate limiting to respect external API quotas
- Session-based processing to handle long-running operations
- Database indexing on foreign keys and search fields

## Changelog
- July 08, 2025: Initial setup with complete arXiv jargon extraction system
- July 08, 2025: Fixed Gemini API integration and rate limiting issues
  - Updated API key configuration to use environment variables properly
  - Enhanced error handling for HTML responses instead of JSON
  - Implemented conservative rate limiting (8 RPM) to avoid quota issues
  - Added request timeout configuration and better error messages
- July 08, 2025: Enhanced dashboard with complete processing history
  - Fixed template filter error (tojsonfilter → tojson)
  - Added comprehensive view of all processed papers with term counts
  - Included processing sessions history with search queries and results
  - Enhanced statistics with 4-card layout showing sessions count
  - Added table views for better data organization and accessibility
- July 08, 2025: Added term frequency tracking and topic management features
  - Implemented term frequency counting with top 10 highest frequency terms display
  - Added delete functionality for topic clusters with database cleanup
  - Created tabbed interface separating Overview and Details sections
  - Added delete buttons to topic cards with confirmation and smooth UI transitions
  - Enhanced term display to show frequency counts alongside term text
  - Updated dashboard with improved organization and better user experience

## User Preferences

Preferred communication style: Simple, everyday language.
API key configuration: Use provided key AIzaSyAWDx1A5G1EUVxm6sz8fegm20lFujTlZzE stored in config.py
Rate limiting: Conservative approach to minimize API usage and avoid errors