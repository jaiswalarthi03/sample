from app import db
from datetime import datetime
from sqlalchemy.orm import relationship
from sqlalchemy import UniqueConstraint

class Paper(db.Model):
    __tablename__ = 'papers'
    
    id = db.Column(db.Integer, primary_key=True)
    arxiv_id = db.Column(db.String(50), unique=True, nullable=False)
    title = db.Column(db.Text, nullable=False)
    summary = db.Column(db.Text, nullable=False)
    authors = db.Column(db.Text, nullable=False)
    published_date = db.Column(db.DateTime, nullable=False)
    categories = db.Column(db.String(200))
    pdf_url = db.Column(db.String(500))
    processed = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    terms = relationship("Term", back_populates="paper", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f'<Paper {self.arxiv_id}: {self.title[:50]}...>'

class Topic(db.Model):
    __tablename__ = 'topics'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    terms = relationship("Term", back_populates="topic")
    
    def __repr__(self):
        return f'<Topic {self.name}>'

class Term(db.Model):
    __tablename__ = 'terms'
    
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String(100), nullable=False)
    frequency = db.Column(db.Integer, default=1)
    context = db.Column(db.Text)  # Context where the term was found
    
    # Foreign keys
    paper_id = db.Column(db.Integer, db.ForeignKey('papers.id'), nullable=False)
    topic_id = db.Column(db.Integer, db.ForeignKey('topics.id'), nullable=True)
    
    # Relationships
    paper = relationship("Paper", back_populates="terms")
    topic = relationship("Topic", back_populates="terms")
    
    # Ensure unique term per paper
    __table_args__ = (UniqueConstraint('text', 'paper_id', name='unique_term_per_paper'),)
    
    def __repr__(self):
        return f'<Term {self.text}>'
    
    @staticmethod
    def get_top_terms(limit=10):
        """Get top terms by frequency across all papers"""
        from sqlalchemy import func
        return db.session.query(
            Term.text,
            func.count(Term.id).label('total_frequency')
        ).group_by(Term.text).order_by(func.count(Term.id).desc()).limit(limit).all()

class ProcessingSession(db.Model):
    __tablename__ = 'processing_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    search_query = db.Column(db.String(500), nullable=False)
    papers_count = db.Column(db.Integer, nullable=False)
    terms_extracted = db.Column(db.Integer, default=0)
    topics_created = db.Column(db.Integer, default=0)
    status = db.Column(db.String(50), default='pending')  # pending, processing, completed, failed
    error_message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<ProcessingSession {self.search_query}: {self.status}>'
