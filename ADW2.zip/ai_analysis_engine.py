import os
import json
import requests
from config import GEMINI_API_KEY, GEMINI_API_URL, ARCHITECTURAL_STANDARDS, DIAGRAM_TEMPLATES

# API Configuration - Use config.py for URL

def create_analysis_prompt(schema_metadata, analysis_type, sql_query=None, tree_structure=None):
    """
    Creates a prompt for the Gemini AI model based on schema metadata, analysis type, and Tree-of-Table structure.
    Returns a prompt with HTML formatting only (no markdown).
    
    Args:
        schema_metadata (dict): Dictionary containing schema information
        analysis_type (str): Type of analysis to perform
        sql_query (str): Optional SQL query to include in the analysis
        tree_structure (dict): Optional Tree-of-Table hierarchical structure
    
    Returns:
        str: Formatted prompt for the AI model
    """
    schema_info = json.dumps(schema_metadata, indent=2)
    base_prompt = f'''
You are a database schema expert analyzing schema information from a Databricks database. Provide a detailed {analysis_type} analysis of the following database objects:

<h2>Schema Information:</h2>
<pre><code class="language-json">{schema_info}</code></pre>
'''
    if sql_query:
        base_prompt += f'''
<h2>SQL Query for Analysis:</h2>
<pre><code class="language-sql">{sql_query}</code></pre>
'''
    if tree_structure:
        tree_info = json.dumps(tree_structure, indent=2)
        base_prompt += f'''
<h2>Tree-of-Table Hierarchical Structure:</h2>
<pre><code class="language-json">{tree_info}</code></pre>
<p>This hierarchical structure represents the decomposition of large tables into manageable chunks for analysis.</p>
'''
    
    # Add specific instructions based on analysis type
    if analysis_type == "general":
        base_prompt += """
<h2>Please provide a comprehensive schema analysis that includes:</h2>
<ul>
    <li><b>1.</b> Overview of the schema structure</li>
    <li><b>2.</b> Assessment of entity relationships</li>
    <li><b>3.</b> Primary and foreign key analysis</li>
    <li><b>4.</b> Data type assessments</li>
    <li><b>5.</b> Recommendations for schema improvements</li>
</ul>
"""
    elif analysis_type == "performance":
        base_prompt += """
<h2>Please provide a performance-focused analysis that includes:</h2>
<ul>
    <li><b>1.</b> Identification of potential performance bottlenecks</li>
    <li><b>2.</b> Query optimization opportunities</li>
    <li><b>3.</b> Indexing recommendations</li>
    <li><b>4.</b> Partitioning and clustering suggestions</li>
    <li><b>5.</b> Materialized view recommendations</li>
</ul>
"""
    elif analysis_type == "normalization":
        base_prompt += """
<h2>Please provide a normalization analysis that includes:</h2>
<ul>
    <li><b>1.</b> Current normalization level assessment (1NF, 2NF, 3NF, etc.)</li>
    <li><b>2.</b> Data redundancy identification</li>
    <li><b>3.</b> Functional dependency analysis</li>
    <li><b>4.</b> Denormalization considerations</li>
    <li><b>5.</b> Recommendations for improving normalization</li>
</ul>
"""
    elif analysis_type == "relationships":
        base_prompt += """
<h2>Please provide a relationships-focused analysis that includes:</h2>
<ul>
    <li><b>1.</b> Entity relationship mapping</li>
    <li><b>2.</b> Identifying missing relationships</li>
    <li><b>3.</b> Assessment of referential integrity</li>
    <li><b>4.</b> Cardinality analysis</li>
    <li><b>5.</b> Recommendations for relationship improvements</li>
</ul>
"""
    elif analysis_type == "naming":
        base_prompt += """
<h2>Please provide a naming convention analysis that includes:</h2>
<ul>
    <li><b>1.</b> Consistency assessment of naming patterns</li>
    <li><b>2.</b> Table naming convention evaluation</li>
    <li><b>3.</b> Column naming convention evaluation</li>
    <li><b>4.</b> Identifier clarity and meaning</li>
    <li><b>5.</b> Recommendations for naming improvements</li>
</ul>
"""
    elif analysis_type == "standards":
        base_prompt += """
<h2>Please provide a standards compliance analysis that includes:</h2>
<ul>
    <li><b>1.</b> Adherence to industry best practices</li>
    <li><b>2.</b> SQL standard compliance</li>
    <li><b>3.</b> Databricks-specific conventions evaluation</li>
    <li><b>4.</b> Documentation and comment quality</li>
    <li><b>5.</b> Recommendations for improved standards compliance</li>
</ul>
"""
    elif analysis_type == "denormalization":
        base_prompt += """
<h2>Please provide a denormalization analysis that includes:</h2>
<ul>
    <li><b>1.</b> Current normalization level assessment</li>
    <li><b>2.</b> Denormalization opportunities identification</li>
    <li><b>3.</b> Performance vs. storage trade-offs analysis</li>
    <li><b>4.</b> Query pattern analysis for denormalization benefits</li>
    <li><b>5.</b> Recommendations for strategic denormalization</li>
    <li><b>6.</b> Impact on data consistency and maintenance</li>
</ul>
"""
    elif analysis_type == "data_quality":
        base_prompt += create_data_quality_prompt()
    elif analysis_type == "security":
        base_prompt += create_security_prompt()
    elif analysis_type == "data_types":
        base_prompt += create_data_types_prompt()
    elif analysis_type == "partitioning":
        base_prompt += create_partitioning_prompt()
    elif analysis_type == "constraints":
        base_prompt += create_constraints_prompt()
    elif analysis_type == "documentation":
        base_prompt += create_documentation_prompt()
    elif analysis_type == "governance":
        base_prompt += create_governance_prompt()
    elif analysis_type == "pii_detection":
        base_prompt += create_pii_detection_prompt()
    elif analysis_type == "pci_compliance":
        base_prompt += create_pci_compliance_prompt()
    elif analysis_type == "gdpr_compliance":
        base_prompt += create_gdpr_compliance_prompt()
    elif analysis_type == "ml_readiness":
        base_prompt += create_ml_readiness_prompt()
    elif analysis_type == "data_lineage":
        base_prompt += create_data_lineage_prompt()
    elif analysis_type == "cost_optimization":
        base_prompt += create_cost_optimization_prompt()
    elif analysis_type == "data_catalog":
        base_prompt += create_data_catalog_prompt()
    elif analysis_type == "etl_pipeline":
        base_prompt += create_etl_pipeline_prompt()
    elif analysis_type == "data_governance":
        base_prompt += create_data_governance_prompt()
    elif analysis_type == "audit_trail":
        base_prompt += create_audit_trail_prompt()
    elif analysis_type == "data_retention":
        base_prompt += create_data_retention_prompt()
    elif analysis_type == "disaster_recovery":
        base_prompt += create_disaster_recovery_prompt()
    elif analysis_type == "data_migration":
        base_prompt += create_data_migration_prompt()
    
    # Add diagram template if available for this analysis type
    if analysis_type in DIAGRAM_TEMPLATES:
        diagram_info = DIAGRAM_TEMPLATES[analysis_type]
        base_prompt += """

<h2>DIAGRAM REQUIREMENT:</h2>
You MUST include a Mermaid.js diagram in your response to visualize the analysis results.

<h3>Diagram Type:</h3> """ + diagram_info['description'] + """

<h3>Diagram Template (use as starting point, adapt to actual schema):</h3>
<pre><code class="language-mermaid">""" + diagram_info['template'] + """</code></pre>

<h3>CRITICAL DIAGRAM RULES:</h3>
<ul>
    <li>Use EXACT Mermaid.js syntax - no special characters or formatting</li>
    <li>Replace placeholder table names with actual tables from the schema</li>
    <li>Use proper relationship syntax: ||--o{ for one-to-many, ||--|| for one-to-one, }o--o{ for many-to-many</li>
    <li>Include actual column names from the schema</li>
    <li>Show relationships, dependencies, or processes as appropriate for the analysis type</li>
    <li>Place the diagram in a <div class="mermaid-diagram"> block in your HTML response</li>
    <li>DO NOT add any special characters, quotes, or formatting that could break Mermaid rendering</li>
    <li>If multiple diagrams are needed, create them separately</li>
    <li>IMPORTANT: The diagram MUST be rendered as an actual visual diagram, not just text</li>
    <li>Use <br/> for line breaks in node labels to make them more readable</li>
    <li>FORBIDDEN: In ER diagrams, DO NOT use any 'classDef', 'class', 'PRIMARY KEY', or 'FOREIGN KEY' lines. Only use the format: TABLE_NAME { datatype column_name PK/FK ... }</li>
    <li>If you include any line with 'classDef', 'class', 'PRIMARY KEY', or 'FOREIGN KEY' in an ER diagram, your answer will be rejected.</li>
    <li>For flowcharts and other diagrams, use classDef syntax: classDef tableStyle fill:#f9f,stroke:#333,stroke-width:2px</li>
    <li>Use subgraphs to group related processes or data sources</li>
</ul>

<h3>WARNING:</h3>
If you include any forbidden lines in an ER diagram, your answer will be rejected and not used.

<h3>EXAMPLE OF CORRECT DIAGRAM PLACEMENT:</h3>
<pre><code class="language-html">&lt;h2&gt;Visual Diagram&lt;/h2&gt;
&lt;div class="mermaid-diagram"&gt;
erDiagram
    CUSTOMER {
        string id PK
        string name
        string email
    }
    
    ORDER {
        string id PK
        string customer_id FK
        string order_date
    }
    
    CUSTOMER ||--o{ ORDER : "places"
&lt;/div&gt;</code></pre>

<h3>CRITICAL: DO NOT create empty <div class="mermaid-diagram"></div> - it must contain diagram code!</h3>

<h3>MANDATORY: Include at least ONE diagram in your response. The diagram should:</h3>
<ul>
    <li>Be placed in a dedicated section with a clear heading like "## Visual Diagram"</li>
    <li>Use actual table names from the provided schema</li>
    <li>Include proper styling and colors</li>
    <li>Be comprehensive enough to show the key relationships or processes</li>
    <li>Be wrapped in <div class="mermaid-diagram"> tags</li>
    <li>CRITICAL: The <div class="mermaid-diagram"> MUST contain the actual diagram code, not be empty</li>
</ul>

<h3>EXAMPLE OF CORRECT DIAGRAM PLACEMENT:</h3>
<pre><code class="language-html">&lt;h2&gt;Visual Diagram&lt;/h2&gt;
&lt;div class="mermaid-diagram"&gt;
erDiagram
    CUSTOMER {
        string id PK
        string name
        string email
    }
    ORDER {
        string id PK
        string customer_id FK
        string status
    }
    CUSTOMER ||--o{ ORDER : places
    
    classDef tableStyle fill:#f9f,stroke:#333,stroke-width:2px
    class CUSTOMER,ORDER tableStyle
&lt;/div&gt;</code></pre>

<h3>CRITICAL: DO NOT create empty <div class="mermaid-diagram"></div> - it must contain diagram code!</h3>
"""

    # General formatting instructions
    base_prompt += """
<h2>Format your response as HTML with these elements:</h2>
<ul>
    <li>Use <h1>, <h2>, <h3> for headings</li>
    <li>Use <ul>, <ol>, <li> for lists</li>
    <li>Use <table>, <tr>, <th>, <td> for tabular data</li>
    <li>Use <code> and <pre> for SQL examples</li>
    <li>Add emojis for visual appeal (e.g., 📊, 🔍, ✅, ⚠️, 💡)</li>
    <li>Use color coding: <span style="color: red;"> for issues, <span style="color: green;"> for good practices</li>
    <li>Include Mermaid.js diagrams in <div class="mermaid"> blocks as specified above</li>
</ul>

<h2>Make your response informative, specific, and actionable.</h2>
"""
    
    return base_prompt

def create_data_quality_prompt():
    """Create data quality assessment prompt"""
    return """
<h2>Please provide a comprehensive data quality assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Data Completeness Analysis** 📊</li>
    <li><b>2.</b> **Data Accuracy Assessment** ✅</li>
    <li><b>3.</b> **Data Consistency Review** 🔄</li>
    <li><b>4.</b> **Data Timeliness Evaluation** ⏰</li>
    <li><b>5.</b> **Data Lineage Tracking** 🛤️</li>
    <li><b>6.</b> **Data Quality Metrics** 📈</li>
</ul>
<p>Focus on actionable insights and specific recommendations for improving data quality.</p>
"""

def create_security_prompt():
    """Create security and privacy analysis prompt"""
    return """
<h2>Please provide a comprehensive security and privacy analysis that includes:</h2>
<ul>
    <li><b>1.</b> **Data Encryption Assessment** 🔐</li>
    <li><b>2.</b> **Access Control Analysis** 🚪</li>
    <li><b>3.</b> **Audit Trail Evaluation** 📝</li>
    <li><b>4.</b> **Data Masking Assessment** 🎭</li>
    <li><b>5.</b> **Privacy Compliance Review** 🛡️</li>
    <li><b>6.</b> **Security Risk Assessment** ⚠️</li>
</ul>
<p>Focus on security best practices and compliance requirements.</p>
"""

def create_scalability_prompt():
    """Create scalability assessment prompt"""
    return """
<h2>Please provide a comprehensive scalability assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Horizontal Scaling Analysis** ↔️</li>
    <li><b>2.</b> **Vertical Scaling Assessment** ↕️</li>
    <li><b>3.</b> **Data Distribution Strategy** 📊</li>
    <li><b>4.</b> **Performance Scaling** ⚡</li>
    <li><b>5.</b> **Capacity Planning** 📈</li>
    <li><b>6.</b> **Scalability Recommendations** 💡</li>
</ul>
<p>Focus on scalable architecture patterns and growth strategies.</p>
"""

def create_maintainability_prompt():
    """Create maintainability review prompt"""
    return """
<h2>Please provide a comprehensive maintainability review that includes:</h2>
<ul>
    <li><b>1.</b> **Code Quality Assessment** 🧹</li>
    <li><b>2.</b> **Documentation Quality** 📚</li>
    <li><b>3.</b> **Change Management** 🔄</li>
    <li><b>4.</b> **Modularity Analysis** 🧩</li>
    <li><b>5.</b> **Testing Coverage** 🧪</li>
    <li><b>6.</b> **Maintenance Recommendations** 🔧</li>
</ul>
<p>Focus on long-term maintainability and operational efficiency.</p>
"""

def create_reliability_prompt():
    """Create reliability and availability prompt"""
    return """
<h2>Please provide a comprehensive reliability and availability assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Backup and Recovery** 💾</li>
    <li><b>2.</b> **Disaster Recovery Planning** 🚨</li>
    <li><b>3.</b> **High Availability Configuration** ⚡</li>
    <li><b>4.</b> **Error Handling Mechanisms** 🛠️</li>
    <li><b>5.</b> **Monitoring and Alerting** 📊</li>
    <li><b>6.</b> **Reliability Recommendations** 🎯</li>
</ul>
<p>Focus on system resilience and business continuity.</p>
"""

def create_regulatory_compliance_prompt():
    """Create regulatory compliance prompt"""
    return """
<h2>Please provide a comprehensive regulatory compliance assessment that includes:</h2>
<ul>
    <li><b>1.</b> **SOX Compliance** 💼</li>
    <li><b>2.</b> **HIPAA Compliance** 🏥</li>
    <li><b>3.</b> **PCI DSS Compliance** 💳</li>
    <li><b>4.</b> **GDPR Compliance** 🌍</li>
    <li><b>5.</b> **Industry-Specific Regulations** 🏭</li>
    <li><b>6.</b> **Compliance Recommendations** 📋</li>
</ul>
<p>Focus on regulatory requirements and compliance frameworks.</p>
"""

def create_data_governance_prompt():
    """Create data governance framework prompt"""
    return """
<h2>Please provide a comprehensive data governance framework assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Data Ownership and Stewardship** 👥</li>
    <li><b>2.</b> **Data Classification Policies** 🏷️</li>
    <li><b>3.</b> **Data Lifecycle Management** 🔄</li>
    <li><b>4.</b> **Governance Framework** 🏛️</li>
    <li><b>5.</b> **Data Catalog Implementation** 📚</li>
    <li><b>6.</b> **Governance Recommendations** 🎯</li>
</ul>
<p>Focus on governance maturity and framework effectiveness.</p>
"""

def create_integration_prompt():
    """Create integration standards prompt"""
    return """
<h2>Please provide a comprehensive integration standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **API Design and Documentation** 🔌</li>
    <li><b>2.</b> **Data Format Standardization** 📋</li>
    <li><b>3.</b> **Integration Testing** 🧪</li>
    <li><b>4.</b> **Error Handling** ⚠️</li>
    <li><b>5.</b> **Integration Health Monitoring** 📊</li>
    <li><b>6.</b> **Integration Recommendations** 🔧</li>
</ul>
<p>Focus on integration reliability and maintainability.</p>
"""

def create_monitoring_prompt():
    """Create monitoring and observability prompt"""
    return """
<h2>Please provide a comprehensive monitoring and observability assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Performance Metrics Collection** 📈</li>
    <li><b>2.</b> **Error Rate Monitoring** ❌</li>
    <li><b>3.</b> **Resource Utilization Tracking** 💻</li>
    <li><b>4.</b> **Business Metrics Monitoring** 📊</li>
    <li><b>5.</b> **Alert and Notification Systems** 🔔</li>
    <li><b>6.</b> **Monitoring Recommendations** 🎯</li>
</ul>
<p>Focus on comprehensive observability and proactive monitoring.</p>
"""

def create_testing_prompt():
    """Create testing standards prompt"""
    return """
<h2>Please provide a comprehensive testing standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Unit Testing** 🧪</li>
    <li><b>2.</b> **Integration Testing** 🔗</li>
    <li><b>3.</b> **Data Quality Testing** ✅</li>
    <li><b>4.</b> **Regression Testing** 🔄</li>
    <li><b>5.</b> **Test Data Management** 📊</li>
    <li><b>6.</b> **Testing Recommendations** 🎯</li>
</ul>
<p>Focus on comprehensive testing coverage and quality assurance.</p>
"""

def create_documentation_prompt():
    """Creates a prompt for documentation quality analysis."""
    return """
<h2>Please provide a documentation quality analysis that includes:</h2>
<ul>
    <li><b>1.</b> Table comment completeness assessment</li>
    <li><b>2.</b> Column comment quality evaluation</li>
    <li><b>3.</b> Business rule documentation gaps</li>
    <li><b>4.</b> Metadata completeness analysis</li>
    <li><b>5.</b> Documentation standards compliance</li>
    <li><b>6.</b> Recommendations for improving documentation</li>
</ul>
"""

def create_versioning_prompt():
    """Create versioning and change management prompt"""
    return """
<h2>Please provide a comprehensive versioning and change management assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Schema Versioning** 🔄</li>
    <li><b>2.</b> **API Versioning** 🔌</li>
    <li><b>3.</b> **Data Migration** 📦</li>
    <li><b>4.</b> **Rollback Capabilities** ↩️</li>
    <li><b>5.</b> **Change Tracking and Audit** 📊</li>
    <li><b>6.</b> **Versioning Recommendations** 🎯</li>
</ul>
<p>Focus on change management and version control best practices.</p>
"""

def create_cost_optimization_prompt():
    """Create cost optimization prompt"""
    return """
<h2>Please provide a comprehensive cost optimization assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Storage Optimization** 💾</li>
    <li><b>2.</b> **Compute Resource Optimization** 💻</li>
    <li><b>3.</b> **Query Cost Analysis** 💰</li>
    <li><b>4.</b> **Resource Scheduling** ⏰</li>
    <li><b>5.</b> **Cost Monitoring and Alerting** 📊</li>
    <li><b>6.</b> **Cost Optimization Recommendations** 🎯</li>
</ul>
<p>Focus on cost efficiency and resource optimization.</p>
"""

def create_data_modeling_prompt():
    """Create data modeling standards prompt"""
    return """
<h2>Please provide a comprehensive data modeling standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Normalization Level Assessment** 📊</li>
    <li><b>2.</b> **Entity Relationship Modeling** 🔗</li>
    <li><b>3.</b> **Dimensional Modeling Practices** 📐</li>
    <li><b>4.</b> **Data Warehouse Design Principles** 🏗️</li>
    <li><b>5.</b> **Model Documentation Quality** 📝</li>
    <li><b>6.</b> **Modeling Recommendations** 🎯</li>
</ul>
<p>Focus on data modeling best practices and consistency.</p>
"""

def create_data_engineering_prompt():
    """Create data engineering standards prompt"""
    return """
<h2>Please provide a comprehensive data engineering standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **ETL/ELT Process Design** 🔄</li>
    <li><b>2.</b> **Data Pipeline Orchestration** ⚙️</li>
    <li><b>3.</b> **Error Handling and Recovery** ⚠️</li>
    <li><b>4.</b> **Data Transformation Logic** 🔧</li>
    <li><b>5.</b> **Pipeline Monitoring and Alerting** 📊</li>
    <li><b>6.</b> **Engineering Recommendations** 🎯</li>
</ul>
<p>Focus on robust data engineering practices.</p>
"""

def create_machine_learning_prompt():
    """Create machine learning standards prompt"""
    return """
<h2>Please provide a comprehensive machine learning standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Feature Engineering Practices** 🔧</li>
    <li><b>2.</b> **Model Versioning and Tracking** 📊</li>
    <li><b>3.</b> **Model Performance Monitoring** 📈</li>
    <li><b>4.</b> **A/B Testing Capabilities** 🧪</li>
    <li><b>5.</b> **Model Explainability and Interpretability** 🔍</li>
    <li><b>6.</b> **ML Recommendations** 🎯</li>
</ul>
<p>Focus on ML governance and best practices.</p>
"""

def create_data_ops_prompt():
    """Create DataOps standards prompt"""
    return """
<h2>Please provide a comprehensive DataOps standards assessment that includes:</h2>
<ul>
    <li><b>1.</b> **Automated Testing and Deployment** 🤖</li>
    <li><b>2.</b> **Continuous Integration/Continuous Deployment** 🔄</li>
    <li><b>3.</b> **Environment Management** 🌍</li>
    <li><b>4.</b> **Release Management Processes** 📦</li>
    <li><b>5.</b> **Collaboration and Communication Tools** 💬</li>
    <li><b>6.</b> **DataOps Recommendations** 🎯</li>
</ul>
<p>Focus on DataOps maturity and automation.</p>
"""

def create_governance_prompt():
    """Create comprehensive governance analysis prompt using architectural standards"""
    standards_info = ""
    for standard_key, standard_data in ARCHITECTURAL_STANDARDS.items():
        standards_info += f"<h2>{standard_data['name']}</h2>\n"
        standards_info += f"{standard_data['description']}\n"
        standards_info += "<b>Checks:</b>\n"
        for check in standard_data['checks']:
            standards_info += f"- {check}\n"
    
    return f"""
<h2>Please provide a comprehensive data governance and compliance analysis covering all 20+ architectural standards:</h2>

<h3>Architectural Standards to Evaluate:</h3>
{standards_info}

<h3>Analysis Requirements:</h3>

Please provide a comprehensive governance and compliance analysis that includes:

<ul>
    <li><b>1.</b> **Data Quality Assessment** 🔍</li>
    <li><b>2.</b> **Security & Privacy Analysis** 🔒</li>
    <li><b>3.</b> **Performance & Scalability Review** ⚡</li>
    <li><b>4.</b> **Compliance Evaluation** 📋</li>
    <li><b>5.</b> **Data Governance Assessment** 🏛️</li>
    <li><b>6.</b> **Technical Architecture Review** 🏗️</li>
    <li><b>7.</b> **Risk Assessment** ⚠️</li>
    <li><b>8.</b> **Cost Optimization Analysis** 💰</li>
    <li><b>9.</b> **Data Lineage & Catalog Assessment** 📚</li>
    <li><b>10.</b> **Machine Learning & DataOps Standards** 🤖</li>
</ul>

<p>Make your response comprehensive, actionable, and focused on governance and compliance standards.</p>
"""

def create_tree_of_tables_prompt():
    """Create Tree-of-Table specific analysis prompt"""
    return """
<h2>Please provide a Tree-of-Table hierarchical analysis that includes:</h2>

<ul>
    <li><b>1.</b> **Hierarchical Structure Analysis** 🌳</li>
    <li><b>2.</b> **Chunking Strategy Assessment** 📦</li>
    <li><b>3.</b> **Similarity Search Analysis** 🔍</li>
    <li><b>4.</b> **Context Preservation** 🧠</li>
    <li><b>5.</b> **Scalability Analysis** 📈</li>
    <li><b>6.</b> **Integration Assessment** 🔗</li>
    <li><b>7.</b> **Governance Compliance** 📋</li>
</ul>

<p>Focus on the unique aspects of Tree-of-Table methodology and its application to large-scale data analysis.</p>
"""

def generate_analysis(prompt):
    """
    Generate an analysis by sending a prompt to the Google Gemini API.
    
    Args:
        prompt (str): The formatted prompt to send to the API
        
    Returns:
        str: HTML-formatted analysis result
    """
    try:
        print("📤 Sending to AI...")
        # Configuration for the API request
        params = {
            'key': GEMINI_API_KEY,
        }
        
        request_body = {
            "contents": [
                {
                    "parts": [
                        {"text": prompt}
                    ]
                }
            ],
            "generationConfig": {
                "temperature": 0.2,
                "topK": 32,
                "topP": 0.95,
                "maxOutputTokens": 8192,
            }
        }
        
        # Debug logging for Gemini API call
        print(f"🌐 API: {GEMINI_API_URL}")
        
        # For demo purposes, return a sample analysis if no API key
        if not GEMINI_API_KEY:
            return get_sample_analysis()
        
        # Send request to Gemini API
        response = requests.post(
            GEMINI_API_URL, 
            params=params, 
            json=request_body,
            headers={"Content-Type": "application/json"}
        )
        
        # Check if request was successful
        if response.status_code == 200:
            response_json = response.json()
            if 'candidates' in response_json and len(response_json['candidates']) > 0:
                # Gemini 2.0 API response format
                parts = response_json['candidates'][0].get('content', {}).get('parts', [])
                if parts and 'text' in parts[0]:
                    analysis_text = parts[0]['text']
                else:
                    analysis_text = str(parts)
                
                # Clean up the response if needed
                if not analysis_text.strip():
                    return get_sample_analysis()
                
                # Clean up Gemini output formatting - remove ```html and ``` prefixes
                analysis_text = clean_gemini_output(analysis_text)
                
                return analysis_text
            else:
                print(f"No valid response from Gemini API: {response_json}")
                return f"""
                <h1>⚠️ API Error</h1>
                <p>There was an error with the Gemini API response format.</p>
                <p>Using sample analysis instead.</p>
                {get_sample_analysis()}
                """
        else:
            print(f"API Error: {response.status_code} - {response.text}")
            return f"""
            <h1>⚠️ API Error</h1>
            <p>There was an error connecting to the Gemini API:</p>
            <pre>{response.status_code} - {response.text}</pre>
            <p>Using sample analysis instead.</p>
            {get_sample_analysis()}
            """
    
    except Exception as e:
        print(f"Error generating analysis: {str(e)}")
        return f"""
        <h1>⚠️ Error</h1>
        <p>There was an error generating the analysis:</p>
        <pre>{str(e)}</pre>
        <p>Using sample analysis instead.</p>
        {get_sample_analysis()}
        """

def clean_gemini_output(text):
    """
    Clean up Gemini output by removing markdown code block formatting.
    
    Args:
        text (str): Raw Gemini response text
        
    Returns:
        str: Cleaned HTML content
    """
    # Remove ```html prefix
    if text.startswith('```html'):
        text = text[7:]
    
    # Remove ``` suffix
    if text.endswith('```'):
        text = text[:-3]
    
    # Remove any leading/trailing whitespace
    text = text.strip()
    
    # Handle cases where Gemini might add extra formatting
    text = text.replace('```html\n', '')
    text = text.replace('\n```', '')
    
    return text

def get_sample_analysis():
    """Return a sample analysis for demonstration purposes"""
    return """
    <h1>📊 Sample Governance & Compliance Analysis</h1>
    
    <h2>🔍 Data Quality Assessment</h2>
    <ul>
        <li><span style="color: green;">✅</span> Data completeness: 95% - Good coverage across tables</li>
        <li><span style="color: orange;">⚠️</span> Data accuracy: 87% - Some inconsistencies detected</li>
        <li><span style="color: green;">✅</span> Data consistency: 92% - Consistent naming conventions</li>
        <li><span style="color: red;">❌</span> Data timeliness: 78% - Some tables need refresh</li>
    </ul>
    
    <h2>🔒 Security & Privacy Analysis</h2>
    <ul>
        <li><span style="color: red;">❌</span> Missing column-level encryption for sensitive data</li>
        <li><span style="color: orange;">⚠️</span> Row-level security not implemented</li>
        <li><span style="color: green;">✅</span> Access controls properly configured</li>
        <li><span style="color: red;">❌</span> Audit logging needs enhancement</li>
    </ul>
    
    <h2>⚡ Performance & Scalability Review</h2>
    <ul>
        <li><span style="color: green;">✅</span> Partitioning strategy implemented</li>
        <li><span style="color: orange;">⚠️</span> Clustering could be optimized</li>
        <li><span style="color: red;">❌</span> Missing indexes on frequently queried columns</li>
        <li><span style="color: green;">✅</span> Resource utilization within acceptable limits</li>
    </ul>
    
    <h2>📋 Compliance Evaluation</h2>
    <ul>
        <li><span style="color: orange;">⚠️</span> GDPR compliance: PII identification needed</li>
        <li><span style="color: red;">❌</span> SOX compliance: Audit trails insufficient</li>
        <li><span style="color: green;">✅</span> HIPAA compliance: Basic requirements met</li>
        <li><span style="color: orange;">⚠️</span> PCI DSS: Payment data handling needs review</li>
    </ul>
    
    <h2>🏛️ Data Governance Assessment</h2>
    <ul>
        <li><span style="color: green;">✅</span> Data ownership clearly defined</li>
        <li><span style="color: orange;">⚠️</span> Data stewardship roles need clarification</li>
        <li><span style="color: red;">❌</span> Data lifecycle management incomplete</li>
        <li><span style="color: green;">✅</span> Data catalog implementation in progress</li>
    </ul>
    
    <h2>💡 Recommendations</h2>
    <ol>
        <li><strong>Immediate Actions:</strong> Implement column-level encryption for sensitive data</li>
        <li><strong>Short-term:</strong> Enhance audit logging and PII identification</li>
        <li><strong>Medium-term:</strong> Optimize clustering and add missing indexes</li>
        <li><strong>Long-term:</strong> Complete data lifecycle management implementation</li>
    </ol>
    
    <h2>⚠️ Risk Assessment</h2>
    <table border="1">
        <tr>
            <th>Risk</th>
            <th>Severity</th>
            <th>Probability</th>
            <th>Mitigation</th>
        </tr>
        <tr>
            <td>Data Breach</td>
            <td><span style="color: red;">High</span></td>
            <td><span style="color: orange;">Medium</span></td>
            <td>Implement encryption and access controls</td>
        </tr>
        <tr>
            <td>Compliance Violation</td>
            <td><span style="color: red;">High</span></td>
            <td><span style="color: red;">High</span></td>
            <td>Enhance audit trails and PII handling</td>
        </tr>
        <tr>
            <td>Performance Degradation</td>
            <td><span style="color: orange;">Medium</span></td>
            <td><span style="color: orange;">Medium</span></td>
            <td>Optimize indexes and clustering</td>
        </tr>
    </table>
    """

def test_diagram_generation():
    """Test function to generate a sample analysis with diagram"""
    sample_schema = {
        "test_table": {
            "columns": [
                {"name": "id", "type": "string", "is_primary": True},
                {"name": "name", "type": "string"},
                {"name": "category", "type": "string"}
            ],
            "details": {"table_type": "MANAGED"}
        }
    }
    
    prompt = create_analysis_prompt(sample_schema, "data_engineering")
    print("=== GENERATED PROMPT ===")
    print(prompt)
    print("=== END PROMPT ===")
    
    return prompt

def clean_mermaid_code(mermaid_code):
    """
    Removes forbidden lines from Mermaid ER diagrams: classDef, class, PRIMARY KEY, FOREIGN KEY.
    """
    cleaned_lines = []
    for line in mermaid_code.splitlines():
        if any(forbidden in line for forbidden in ['classDef', 'class ', 'PRIMARY KEY', 'FOREIGN KEY']):
            continue
        cleaned_lines.append(line)
    return '\n'.join(cleaned_lines)

def create_data_types_prompt():
    """Creates a prompt for data type optimization analysis."""
    return """
<h2>Please provide a data type optimization analysis that includes:</h2>
<ul>
    <li><b>1.</b> Current data type assessment for each column</li>
    <li><b>2.</b> Storage efficiency analysis and potential savings</li>
    <li><b>3.</b> Performance implications of current data types</li>
    <li><b>4.</b> Recommended data type conversions</li>
    <li><b>5.</b> Type conversion benefits and trade-offs</li>
    <li><b>6.</b> Databricks-specific data type optimizations</li>
</ul>
"""

def create_partitioning_prompt():
    """Creates a prompt for partitioning strategy analysis."""
    return """
<h2>Please provide a partitioning strategy analysis that includes:</h2>
<ul>
    <li><b>1.</b> Table size assessment and partitioning eligibility</li>
    <li><b>2.</b> Identification of potential partition columns</li>
    <li><b>3.</b> Partitioning strategy recommendations (time-based, hash, range)</li>
    <li><b>4.</b> Expected performance improvements from partitioning</li>
    <li><b>5.</b> Clustering considerations for Databricks Delta tables</li>
    <li><b>6.</b> Implementation considerations and trade-offs</li>
</ul>
"""

def create_constraints_prompt():
    """Creates a prompt for constraint analysis."""
    return """
<h2>Please provide a constraint analysis that includes:</h2>
<ul>
    <li><b>1.</b> Primary key assessment and recommendations</li>
    <li><b>2.</b> Foreign key relationship identification</li>
    <li><b>3.</b> Missing constraint opportunities</li>
    <li><b>4.</b> Data integrity rule suggestions</li>
    <li><b>5.</b> Check constraint recommendations</li>
    <li><b>6.</b> Unique constraint analysis</li>
</ul>
"""

def create_data_migration_prompt():
    """Creates a prompt for data migration assessment."""
    return """
<h2>Please provide a data migration assessment that includes:</h2>
<ul>
    <li><b>1.</b> Migration complexity analysis and risk assessment</li>
    <li><b>2.</b> Data mapping and transformation requirements</li>
    <li><b>3.</b> Source and target system compatibility analysis</li>
    <li><b>4.</b> Migration strategy recommendations (big bang, phased, parallel)</li>
    <li><b>5.</b> Resource planning and timeline estimation</li>
    <li><b>6.</b> Validation and testing requirements</li>
</ul>
"""

def create_pii_detection_prompt():
    """Creates a prompt for PII detection analysis."""
    return """
<h2>Please provide a PII detection analysis that includes:</h2>
<ul>
    <li><b>1.</b> Identification of Personally Identifiable Information fields</li>
    <li><b>2.</b> Classification of PII types (personal identifiers, contact info, financial data)</li>
    <li><b>3.</b> Assessment of current privacy controls and protection measures</li>
    <li><b>4.</b> Recommendations for data masking, encryption, and access controls</li>
    <li><b>5.</b> Compliance implications and regulatory requirements</li>
    <li><b>6.</b> Data minimization and retention policy suggestions</li>
</ul>
"""

def create_pci_compliance_prompt():
    """Creates a prompt for PCI/DSS compliance analysis."""
    return """
<h2>Please provide a PCI/DSS compliance analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of cardholder data environment scope</li>
    <li><b>2.</b> Evaluation of PCI DSS 12 requirements compliance</li>
    <li><b>3.</b> Network security and segmentation analysis</li>
    <li><b>4.</b> Data protection and encryption requirements</li>
    <li><b>5.</b> Access control and monitoring recommendations</li>
    <li><b>6.</b> Vulnerability management and security testing needs</li>
</ul>
"""

def create_gdpr_compliance_prompt():
    """Creates a prompt for GDPR compliance analysis."""
    return """
<h2>Please provide a GDPR compliance analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of personal data processing activities</li>
    <li><b>2.</b> Evaluation of lawful basis for data processing</li>
    <li><b>3.</b> Data subject rights implementation analysis</li>
    <li><b>4.</b> Data protection and security measures assessment</li>
    <li><b>5.</b> Data minimization and retention policy evaluation</li>
    <li><b>6.</b> Accountability and documentation requirements</li>
</ul>
"""

def create_ml_readiness_prompt():
    """Creates a prompt for ML data readiness analysis."""
    return """
<h2>Please provide an ML data readiness analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of data quality for machine learning</li>
    <li><b>2.</b> Feature engineering opportunities and data preparation needs</li>
    <li><b>3.</b> Data volume and diversity analysis for ML training</li>
    <li><b>4.</b> Data preprocessing and cleaning requirements</li>
    <li><b>5.</b> Feature selection and dimensionality analysis</li>
    <li><b>6.</b> ML pipeline integration and data flow recommendations</li>
</ul>
"""

def create_data_lineage_prompt():
    """Creates a prompt for data lineage analysis."""
    return """
<h2>Please provide a data lineage analysis that includes:</h2>
<ul>
    <li><b>1.</b> Mapping of data flow from source to target systems</li>
    <li><b>2.</b> Identification of data transformations and business logic</li>
    <li><b>3.</b> Assessment of data dependencies and impact analysis</li>
    <li><b>4.</b> Metadata management and lineage tracking requirements</li>
    <li><b>5.</b> Data quality monitoring and validation checkpoints</li>
    <li><b>6.</b> Lineage visualization and documentation recommendations</li>
</ul>
"""

def create_cost_optimization_prompt():
    """Creates a prompt for cost optimization analysis."""
    return """
<h2>Please provide a cost optimization analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of current storage and compute costs</li>
    <li><b>2.</b> Identification of cost optimization opportunities</li>
    <li><b>3.</b> Storage optimization and archival strategy recommendations</li>
    <li><b>4.</b> Compute resource optimization and scaling strategies</li>
    <li><b>5.</b> Query optimization and performance tuning suggestions</li>
    <li><b>6.</b> Cost monitoring and alerting framework recommendations</li>
</ul>
"""

def create_data_catalog_prompt():
    """Creates a prompt for data catalog analysis."""
    return """
<h2>Please provide a data catalog analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of metadata organization and completeness</li>
    <li><b>2.</b> Evaluation of data discovery and search capabilities</li>
    <li><b>3.</b> Business glossary and data definition analysis</li>
    <li><b>4.</b> Data classification and ownership assessment</li>
    <li><b>5.</b> Usage statistics and data popularity analysis</li>
    <li><b>6.</b> Catalog enhancement and governance recommendations</li>
</ul>
"""

def create_etl_pipeline_prompt():
    """Creates a prompt for ETL pipeline analysis."""
    return """
<h2>Please provide an ETL pipeline analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of current ETL pipeline efficiency and performance</li>
    <li><b>2.</b> Identification of data transformation bottlenecks and optimization opportunities</li>
    <li><b>3.</b> Data quality validation and error handling analysis</li>
    <li><b>4.</b> Parallel processing and incremental loading recommendations</li>
    <li><b>5.</b> Monitoring and alerting framework assessment</li>
    <li><b>6.</b> Pipeline modernization and automation suggestions</li>
</ul>
"""

def create_data_governance_prompt():
    """Creates a prompt for data governance analysis."""
    return """
<h2>Please provide a data governance analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of current data governance policies and standards</li>
    <li><b>2.</b> Evaluation of roles and responsibilities for data management</li>
    <li><b>3.</b> Data lifecycle management and stewardship analysis</li>
    <li><b>4.</b> Compliance monitoring and enforcement mechanisms</li>
    <li><b>5.</b> Data quality and security governance assessment</li>
    <li><b>6.</b> Governance framework enhancement recommendations</li>
</ul>
"""

def create_audit_trail_prompt():
    """Creates a prompt for audit trail analysis."""
    return """
<h2>Please provide an audit trail analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of current audit logging and monitoring capabilities</li>
    <li><b>2.</b> Evaluation of data access tracking and user activity monitoring</li>
    <li><b>3.</b> Change tracking and version control analysis</li>
    <li><b>4.</b> Compliance monitoring and reporting requirements</li>
    <li><b>5.</b> Security event detection and alerting assessment</li>
    <li><b>6.</b> Audit trail enhancement and automation recommendations</li>
</ul>
"""

def create_data_retention_prompt():
    """Creates a prompt for data retention analysis."""
    return """
<h2>Please provide a data retention analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of current data retention policies and practices</li>
    <li><b>2.</b> Evaluation of legal and regulatory retention requirements</li>
    <li><b>3.</b> Data classification and lifecycle management analysis</li>
    <li><b>4.</b> Archival strategy and storage optimization recommendations</li>
    <li><b>5.</b> Automated deletion and compliance verification processes</li>
    <li><b>6.</b> Retention policy enhancement and governance recommendations</li>
</ul>
"""

def create_disaster_recovery_prompt():
    """Creates a prompt for disaster recovery analysis."""
    return """
<h2>Please provide a disaster recovery analysis that includes:</h2>
<ul>
    <li><b>1.</b> Assessment of current backup and recovery procedures</li>
    <li><b>2.</b> Evaluation of Recovery Time Objectives (RTO) and Recovery Point Objectives (RPO)</li>
    <li><b>3.</b> Business continuity planning and critical system identification</li>
    <li><b>4.</b> Failover procedures and disaster recovery testing assessment</li>
    <li><b>5.</b> Data protection and backup strategy recommendations</li>
    <li><b>6.</b> Disaster recovery framework enhancement suggestions</li>
</ul>
"""

# Test the diagram generation
if __name__ == "__main__":
    test_diagram_generation()