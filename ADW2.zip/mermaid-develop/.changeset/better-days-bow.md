---
'mermaid': minor
'@mermaid-js/parser': minor
---

Adding support for the new diagram type nested treemap
