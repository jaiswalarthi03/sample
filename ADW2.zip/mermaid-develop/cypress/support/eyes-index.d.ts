import '@applitools/eyes-cypress';
